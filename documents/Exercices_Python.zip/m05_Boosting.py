#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 5 - Meta-heuristics
#
# The present tutorials covers the use of different meta-heuristics. 
# We will focus on the use of boosting by performing an implementation of 
# the Adaboost algorithm. The tutorial does not cover the implementation of 
# genetic algorithms, but interested students can find some nice 
# online tutorials
# https://www.tutorialspoint.com/genetic_algorithms/index.htm
#
# <https://esling.github.io/atiam-ml-5-boosting/>
# <esling@ircam.fr>
#

# Load all files in sub-directories
from m05_Boosting import weakClassifierError as wce
from m05_Boosting import plotClassifier as pc
from m05_Boosting import plotBoosting as pb
from matplotlib import pyplot as plt
import numpy as np
# Path to the classification dataset
classPath = '00_Datasets/classification';

#%% 0.1 - Import the classification dataset
import importDataset as imp
import computeTransforms as cpt
import computeFeatures as cft
dataStruct = imp.importDataset(classPath, 'classification');
# 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = cpt.computeTransforms(dataStruct);
# 0.3 - Compute a set of temporal and spectral features
dataStruct = cft.computeFeatures(dataStruct);

#%%
# 5.1 - Generating random distributions

nDims = 2
nInputs = 1000
# Generate uniformly distributed data
patterns = np.random.randn(nInputs, nDims) * 0.8;
# Linear separation example
labelsLinear = (patterns[:, 0] < patterns[:, 1]) * 1;
# Non-linear separation example
labels = (patterns[:, 0] ** 2 + patterns[:, 1] ** 2 < 1) * 1;
labels[labels == 0] = -1;
# Plot the data
plt.figure(figsize=(12, 8))
plt.scatter(patterns[labels == -1, 0], patterns[labels == -1, 1], s=20, c='r');
plt.scatter(patterns[labels == 1, 0], patterns[labels == 1, 1], s=20, c='g');

#%%
# 5.1.1 - Implement a single classifier and test it

######################
# YOUR CODE GOES IN 05_Boosting/weakClassifierError.m
######################

dim = np.random.randint(nDims)
t = np.random.randn(1)
sign = np.random.randint(2) - 1;
errSum, errs = wce.weakClassifierError(t, dim, sign, patterns, labels);
# Plot the classifier and corresponding errors
pc.plotClassifier(t, dim, sign, patterns, labels);

#%%
# 5.1.2 - Perform different search algorithms

nClassifiers = 100

# Grid search

######################
# YOUR CODE GOES HERE
######################

# Keep track of besties
bestErrSum = nInputs + 1
bestErrs = []
bestS = -1
bestD = -1
bestT = -1

    ######################
    # YOUR CODE GOES HERE
    ######################
    
pc.plotClassifier(bestT, bestD, bestS, patterns, labels)
    
# Random search
bestErrSum = nInputs + 1
bestErrs = []
bestS = -1
bestD = -1
bestT = -1
for i in range(nClassifiers * 10):
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
pc.plotClassifier(bestT, bestD, bestS, patterns, labels)

# Candidate pool

    ######################
    # YOUR CODE GOES HERE
    ######################

classifierPool = {}
curClassifier = 1

    ######################
    # YOUR CODE GOES HERE
    ######################
    
pc.plotClassifier(bestT, bestD, bestS, patterns, labels)

#%%
# 5.2.1 - Implement the main boosting algorithm

import time

nbIterations = 50
nClassifiers = 100
weights = (np.ones(nInputs)) / nInputs
classifiers = np.zeros((nbIterations, 3))
alpha = np.zeros(nbIterations)
errors = np.zeros(nbIterations)
classTotal = np.zeros(labels.size)
# Iterate boosting
for it in range(nbIterations):
    bestErrSum = nInputs + 1
    bestErrs = []
    bestS = -1
    bestD = -1
    bestT = -1
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    print('Iteration.%d - %d misses - (Weighted error : %f)\n' % (it, np.sum((errorsTotal != labels) * 1), errors[it]))
    pb.plotBoosting(classifiers, patterns, labels, it, weights, alpha)
    time.sleep(0.2)

#%%
# 5.3.1 - Audio application

# First we will construct the data features matrix
# but this time use a very large amount of features
usedFeatures = ['SpectralCentroidMean', 'SpectralFlatnessMean', 'SpectralSkewnessMean', 'SpectralCentroidStd', 'SpectralFlatnessStd', 'SpectralSkewnessStd']
dataMatrix = np.zeros((len(dataStruct["filenames"]), len(usedFeatures)))
for f in range(len(usedFeatures)):
    dataMatrix[:, f] = dataStruct[usedFeatures[f]];
dataMatrix = np.nan_to_num(dataMatrix)
patterns = dataMatrix / np.max(dataMatrix)
nDims = len(usedFeatures)
# Construct a binary vector of outputs (class indicators)
desired = full(sparse(dataStruct.classes, 1:size(patterns, 1), 1))';
nbTrain = desired.shape[0]
# Number of classes to evaluate
nbClasses = len(dataStruct["classNames"])
nbIterations = 50
nClassifiers = 1000
weights = (np.ones((nInputs, 1))) / nInputs
classifiers = np.zeros((nbIterations, 3))
alpha = np.zeros((nbIterations, 1))
errors = np.zeros((nbIterations, 1))

    ######################
    # YOUR CODE GOES HERE
    ######################
