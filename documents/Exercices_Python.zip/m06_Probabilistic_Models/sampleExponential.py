import numpy as np

def sampleExponential(mu, n, m):
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return samples