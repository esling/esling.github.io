import numpy as np

def sampleBeta(a, b, M, N):
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return samples