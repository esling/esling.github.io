import observe as ob
import factorProduct as fp
import marginalizeFactor as mf
reload(mf)

def infer(network, marg_vars, obs_vars, obs_vals):
#
#    This function performs inference on a bayesian network
#    
#    Args:
#        network    : Original network onto which perform inference
#        marg_vars  : Marginalized variables
#        obs_vars   : Observed variables
#        obs_vals   : Observed values
#    
#    Returns:
#        :returns: The new network
#
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return product

