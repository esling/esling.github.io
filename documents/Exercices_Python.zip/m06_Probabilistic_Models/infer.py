from .observe import observe
from .factorProduct import factorProduct
from .marginalizeFactor import marginalizeFactor

def infer(network, marg_vars, obs_vars, obs_vals):
#
#    This function performs inference on a bayesian network
#    
#    Args:
#        network    : Original network onto which perform inference
#        marg_vars  : Marginalized variables
#        obs_vars   : Observed variables
#        obs_vals   : Observed values
#    
#    Returns:
#        :returns: The new network
#
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return product

