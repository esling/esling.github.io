import librosa as librosa
import numpy as np

#
# Main transforms computation function
#
def computeTransforms(dataStruct):
    # Overall settings
    fSize = 1024
    wSize = fSize
    hSize = fSize//4
    refSr = 44100
    # Constant-Q settings
    fMin = librosa.note_to_hz('C1')
    nBins = 60 * 2
    # Number of files
    fullNbFiles = len(dataStruct["filenames"])
    # Create field for each transform
    dataStruct["signal"] = []
    dataStruct["sRate"] = []
    dataStruct["spectrumPower"] = []
    dataStruct["spectrumMel"] = []
    dataStruct["spectrumChroma"] = []
    dataStruct["spectrumCQT"] = []
    print('    - Performing transforms.');
    # Perform an analysis of spectral transform for each
    for f in range(fullNbFiles):
        print('      * %s.' % dataStruct["filenames"][f]);
        sig, sr = librosa.load(dataStruct["filenames"][f], mono=True, offset=0)
        if (sr != refSr):
            sig = librosa.resample(sig, sr, (sr/2))
        dataStruct["signal"].append(sig)
        dataStruct["sRate"].append(sr)
        # Compute the FFT 
        psc = librosa.stft(sig, n_fft=fSize, win_length=wSize, hop_length=hSize, window='blackman')
        powerspec, phasespec = librosa.magphase(psc);
        dataStruct["spectrumPower"].append(powerspec[:(fSize//2), :])
        # Compute the mel spectrogram        
        wMel = librosa.feature.melspectrogram(sig, sr=sr, n_fft=fSize, hop_length=hSize)
        dataStruct["spectrumMel"].append(wMel);
        # Compute the chromagram
        wChroma = librosa.feature.chroma_stft(S=powerspec**2, sr=sr)
        dataStruct["spectrumChroma"].append(wChroma);
        # Compute the Constant-Q transform
        Xcq = librosa.cqt(sig, sr=refSr, n_bins=nBins, fmin=fMin, bins_per_octave=12 * 2)
        dataStruct["spectrumCQT"].append(np.abs(Xcq));
    return dataStruct