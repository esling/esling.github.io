#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 4 - Clustering
#
# The present tutorials covers the notions of clustering. First, we will 
# use existing implementations of hierarchical clustering to understand 
# how any grouping of points can be considered as a clustering. Then, we 
# will implement a simple algorithm for clustering data into a fixed number
# of groups, namely the k-Means algorithm. The goal here is to familiarize 
# with the notions of unsupervised learning. Finally, we will apply both 
# algorithms in order to perform a task of audio summary generation.
#
# <esling@ircam.fr>
#
#     

# Load all files in sub-directories
from m04_Clustering import kmeans as km
from m04_Clustering import spread as sp
from matplotlib import pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
import matplotlib.gridspec as gridspec
import numpy as np
# Path to the classification dataset
classPath = 'm00_Datasets/music-speech'

#%% 0.1 - Import the classification dataset
import importDataset as imp
import computeTransforms as cpt
import computeFeatures as cft
dataStruct = imp.importDataset(classPath, 'music-speech');
# 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = cpt.computeTransforms(dataStruct);
# 0.3 - Compute a set of temporal and spectral features
dataStruct = cft.computeFeatures(dataStruct);

#%%
# 4.1 - Hierarchical clustering
#

songEx = 11
nbClusters = 20
# Extract the Constant-Q
curCQT = dataStruct["spectrumCQT"][songEx];
nbPoints = curCQT.shape[1]
# Perform a smoothed version
smoothTarget = 200
smoothWins = np.floor(nbPoints / smoothTarget) * 2
smoothCQT = np.zeros((smoothTarget, curCQT.shape[0]))
# Prepare set of windows
firstWin = smoothWins / 2
lastWin = nbPoints - (smoothWins / 2)
winSet = np.round(np.linspace(firstWin, lastWin, smoothTarget))
winStarts = (winSet - firstWin)
winEnds = winStarts + (smoothWins)
# Go through the points
for t in range(smoothTarget):
    winCQT = curCQT[:, int(winStarts[t]):int(winEnds[t])]
    smoothCQT[t, :] = np.mean(winCQT, axis=1)

######################
# YOUR CODE GOES HERE
######################
    
######################
# Solution:

######################
    
# Plot a stylish dendrogram
fig = plt.figure(figsize=(12,8))
gs1 = gridspec.GridSpec(3, 1, height_ratios=[3, 1, 2])
gs1.update(wspace=0.025, hspace=0.01)
plt.subplot(gs1[0])

#
# Here plot the dendrogram
#

ax = plt.gca()
ax.axis('off')
plt.subplot(gs1[1])
ax = plt.gca()
ax.axis('off')
for i in range(len(Rdict["ivl"])):
    plt.plot([i, Rdict["ivl"][i]], [1, 0])
plt.autoscale(enable=True, axis='x', tight=True)
plt.subplot(gs1[2])
plt.imshow(np.flipud(smoothCQT.transpose()), aspect='auto')

#%%
# 4.2 - K-Means clustering
#

# First (small-dense) group of gaussian data
mu = [2,2]
sigma = [[0.1,0],[0,0.1]]
r = np.random.multivariate_normal(mu,sigma,size=400)
# Second (large-sparse) group of gaussian data
mu = [6,2]
sigma = [[2,0],[0,2]]
r2 = np.random.multivariate_normal(mu,sigma,size=100)

#################
# YOUR CODE GOES in 04_Clustering/kmeans.m
#################
reload(km)
reload(sp)
# Compute clustering labels (for 2 groups)
labels = km.kmeans(np.concatenate((r, r2)).transpose(), 2)
labels[0:100] = 0
# Rely on labels to plot data
plt.figure(figsize=(12, 8))
plt.scatter(r[:, 0], r[:, 1], s=200, marker='s', c=[0, 0.5, 0])
plt.scatter(r2[:, 0], r2[:, 1], s=200, marker='*', c=[0, 0.5, 0.5])

sp.spread(np.concatenate((r, r2)).transpose(), labels)

# Compute clustering labels (for 2 groups)
labels = km.kmeans(np.concatenate((r, r2)), 6)
# Rely on labels to plot data
plt.figure()
plt.scatter(r[:, 0], r[:, 1], s=120, marker='s', c=[0, 0.5, 0])
plt.scatter(r2[:, 0], r2[:, 1], s=120, marker='*', c=[0, 0.5, 0.5])
sp.spread(np.concatenate((r, r2)).transpose(), labels)

#%%
# 4.2 - Apply the clustering on audio data
#
usedFeatures = ['SpectralCentroidMean', 'SpectralFlatnessMean', 'SpectralSlopeMean'];
dataMatrix = np.zeros((len(dataStruct["filenames"]), len(usedFeatures)))
for f in range(len(usedFeatures)):
    dataMatrix[:, f] = dataStruct[usedFeatures[f]];
dataMatrix = np.nan_to_num(dataMatrix)
dataMatrix = dataMatrix / np.max(dataMatrix)

#################
# YOUR CODE GOES HERE
#################

# Compute clustering labels (for 2 groups)
labels = km.kmeans(dataMatrix, 2);
# Rely on labels to plot data
sp.spread(dataMatrix, labels)

#%%
# 4.3 - Apply kMeans on the thumbnailing problem (Q.1)
#

#################
# YOUR CODE GOES HERE
#################

# Compute clustering labels (for 2 groups)
labels = km.kmeans(dataMatrix, 2);
# Rely on labels to plot data
sp.spread(dataMatrix, labels);
