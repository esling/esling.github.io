import numpy as np

def weakClassifierError(t, dim, sign, data, labels, weights=None):
    # Handle uniform weights case
    if weights is None:
        weights = np.ones((data.shape[0], 1))
    # Compute the predictions
    errorSum = 0;
    errors = [];
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return errorSum, errors

