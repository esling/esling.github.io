from matplotlib import pyplot as plt
from .weakClassifierError import weakClassifierError
import numpy as np

def plotClassifier(t, dim, sign, patterns, labels, h=1):
    plt.figure(figsize=(12, 8))
    plt.scatter(patterns[labels == -1, 0], patterns[labels == -1, 1], s=20, c='r');
    plt.scatter(patterns[labels == 1, 0], patterns[labels == 1, 1], s=20, c='g');
    errSum, errors = weakClassifierError(t, dim, sign, patterns, labels);
    # Plot the classifier and corresponding errors
    if (dim == 1):
        plt.plot([t, t], [np.min(patterns[:, 1]), np.max(patterns[:, 1])], ls='--', linewidth=2, c='b');
    else:
        plt.plot([np.min(patterns[:, 0]), np.max(patterns[:, 0])], [t, t], ls='--', linewidth=2, c='b');
    plt.title('Errors : %d' % int(errSum)); 
    
