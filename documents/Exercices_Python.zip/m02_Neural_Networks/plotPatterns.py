import numpy as np
from matplotlib import pyplot as plt
#
# Plots the training patterns defined by Patterns and Desired.
#
# P -   NELTS x NPATS matrix of input patterns (column vectors).
#       The first two values in each pattern are used 
#       as the coordinates of the point to be plotted.
#
# D -   NUNITS x NPATS matrix of desired binary output patterns.
#       The first 2 bits of the output pattern determine the
#       class of the point: o, +, *, or x.
#
def plotPatterns(P,D):
    nPats = P.shape[1]
    nUnits = D.shape[0]
    if nUnits < 2:
        D = np.concatenate(D, np.zeros(1,nPats)) 
    # Create the figure
    fig = plt.figure()
    ax = plt.gca()
    # Calculate the bounds for the plot and cause axes to be drawn.
    xmin = np.min(P[0, :])
    xmax = np.max(P[0, :])
    xb = (xmax - xmin) * 0.2
    ymin = np.min(P[1, :])
    ymax = np.max(P[1, :])
    yb = (ymax-ymin) * 0.2
    ax.set(xlim=[xmin-xb, xmax+xb], ylim=[ymin-yb, ymax+yb])
    plt.title('Input Classification')
    plt.xlabel('x1')
    plt.ylabel('x2')
    # classVal = 1 + D[1,:] + 2 * D[2,:];
    colors = [[1, 0, 0], [0, 0.5, 0], [0, 0, 1], [0, 1, 0]]
    symbols = 'o*+x';
    Dcopy = D[:]
    #Dcopy[Dcopy == 0] = 1
    for i in range(nPats):
        c = Dcopy[i]
        ax.scatter(P[0,i], P[1,i], marker=symbols[c], c=colors[c], s=30, linewidths=2)
    ax.legend()
    ax.grid(True)
    return fig
