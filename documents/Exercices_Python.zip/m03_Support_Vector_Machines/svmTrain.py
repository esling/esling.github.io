import numpy as np

def svmTrain(X, Y, C, kernel, tol=1e-3, maxIter=5):
#SVMTRAIN Trains an SVM classifier using a simplified version of the SMO 
# X       : m x n matrix of m training examples (with n-dimensional features).
# Y       : column vector of class identifiers
# C       : standard SVM regularization parameter
# tol     : tolerance value used for determining equality of floating point numbers. 
# maxIter : number of iterations over the dataset before the algorithm stops.

    # Data parameters
    m, n = X.shape
    
    # Map 0 to -1
    Y[Y == 0] = -1
    
    # Variables
    alphas = np.zeros((m, 1))
    b = 0
    E = np.zeros((m, 1))
    passes = 0
    eta = 0
    L = 0
    H = 0
    
    # Pre-compute the Kernel Matrix since our dataset is small
    # (in practice, optimized SVM packages that handle large datasets
    #  gracefully will _not_ do this)
    # 
    if kernel == 'linear':
        ######################
        # Code for the linear kernel
        ######################
        
        print('Selecting linear kernel')
    elif kernel == 'gaussian':
        ######################
        # Code for the gaussian kernel
        ######################
        
        print('Selecting gaussian kernel')
    elif kernel == 'polynomial':
        ######################
        # Code for the polynomial kernel
        ######################
        print('Selecting polynomial kernel')
    elif kernel == 'sigmoid':
        ######################
        # Code for the sigmoid kernel
        ######################
        print('Selecting sigmoid kernel')
    else:
        ######################
        # Code for eventual other kernels
        ######################
        print('Selecting other kernel')
    # Train
    print('Training ...')
    while passes < maxIter:
        # Check that some alphas changed
        num_changed_alphas = 0;
        # Iterative over all alpha_i
        for i in range(m):
                
            ######################
            # YOUR CODE GOES HERE
            # => Perform one pass of the SMO algorithm for each alpha_i
            ######################
            
        if (num_changed_alphas == 0):
            passes = passes + 1
        else: 
            passes = 0
    print(' Done !');
    # Save the model
    idx = (alphas > 0).transpose()[0];
    print(idx)
    model = {} 
    model["X"] = X[idx, :]
    print(model["X"])
    model["y"] = Y[idx]
    model["kernel"] = kernel
    model["b"] = b
    model["alphas"] = alphas[idx]
    model["w"] = np.dot((alphas * Y).transpose(), X).transpose()
    return model
