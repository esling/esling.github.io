import numpy as np
import operator

def discriminantFunction(x_vec, mu_vec, cov_mat):
# Calculates the value of the discriminant function for a dx1 dimensional
# sample given the covariance matrix and mean vector.
#
#   x_vec: A dx1 dimensional numpy array representing the sample.
#   cov_mat: numpy array of the covariance matrix.
#   mu_vec: dx1 dimensional numpy array of the sample mean.
#
#   Returns a float value g as result of the discriminant function.

    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return float(g)