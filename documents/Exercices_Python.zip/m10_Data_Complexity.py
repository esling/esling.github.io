#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 10 - Data Complexity
#
# <https://esling.github.io/ [...]>
# <esling@ircam.fr>
#

# Load all files in sub-directories
from matplotlib import pyplot as plt
import numpy as np
# Path to the classification dataset
classPath = 'm00_Datasets/classification'

#%% 0.1 - Import the classification dataset
import importDataset as imp
import computeTransforms as cpt
import computeFeatures as cft
dataStruct = imp.importDataset(classPath, 'classification')
# 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = cpt.computeTransforms(dataStruct)
# 0.3 - Compute a set of temporal and spectral features
dataStruct = cft.computeFeatures(dataStruct)
 
#%%
# 10.0 - Generate two overlapping distributions

nbPatterns = 400
# Generate random patterns for class 1
mu1 = np.array([0,0])
cov1 = np.array([[42,30],[30,42]])
x1samples = np.random.multivariate_normal(mu1, cov1, size=nbPatterns)
# Generate random patterns for class 2
mu2 = np.array([16,16])
cov2 = np.array([[21,14],[14,21]])
x2samples = np.random.multivariate_normal(mu2, cov2, size=nbPatterns)

# Prepare concatenated versions of class properties
muVals = {}; 
muVals[0] = np.array([mu1]).transpose() 
muVals[1] = np.array([mu2]).transpose() 
covVals = {}
covVals[0] = cov1
covVals[1] = cov2
# Plot the corresponding data
plt.figure(figsize=(12, 8))
plt.scatter(x1samples[:, 0], x1samples[:, 1], s=40, marker='o', c=[0, 0.8, 0], edgecolors=[0, 0.4, 0])
plt.scatter(x2samples[:, 0], x2samples[:, 1], s=40, marker='s', c=[0, 0, 0.8], edgecolors=[0, 0, 0.4])
h = pge.plotGaussianEllipsoid(mu1, cov1, 2); #set(h, 'Color', [0.2, 0.2, 0.2], 'LineWidth', 3, 'LineStyle', '--')
h = pge.plotGaussianEllipsoid(mu2, cov2, 2); #set(h, 'Color', [0.2, 0.2, 0.2], 'LineWidth', 3, 'LineStyle', '--')
plt.title('Training Dataset')
plt.ylabel('x_2')
plt.xlabel('x_1')

# Mix all samples together
x = np.concatenate((x1samples, x2samples));

#%%
# 10.1 - Compute the PCA for the Gaussian distribution

# Performing a zero-mean transform
avg = np.mean(x, axis=0);
x = x - avg;

######################
# YOUR CODE GOES HERE
######################

plt.figure(figsize=(12, 8))
plt.scatter(xZCAwhite[1:nbPatterns,0], xZCAwhite[1:nbPatterns,1], s=40, marker='o', c=[0, 0.8, 0], edgecolors=[0, 0.4, 0])
plt.scatter(xZCAwhite[(nbPatterns+1):,0], xZCAwhite[(nbPatterns+1):, 1], s=40, marker='s', c=[0, 0, 0.8], edgecolors=[0, 0, 0.4]);
plt.title('PCA transformed data')
plt.ylabel('x_2')
plt.xlabel('x_1')

#%%
# 10.2 - Cross-validation

holdoutTrain = []
holdoutValid = []
validationPercent = .1
nbExamples = len(dataStruct["classes"]);
# Holdout method

    ######################
    # YOUR CODE GOES HERE
    ######################
    
# Stratification method
stratificationTrain = []
stratificationValid = []

    ######################
    # YOUR CODE GOES HERE
    ######################

# Count the class instances for each approach
classBalance = np.zeros((4, len(dataStruct["classNames"])));
for i in range(len(dataStruct["classNames"])):
    classBalance[0, i] = np.sum(dataStruct["classes"][holdoutTrain] == i);
    classBalance[1, i] = np.sum(dataStruct["classes"][holdoutValid] == i);
    classBalance[2, i] = np.sum(dataStruct["classes"][stratificationTrain] == i);
    classBalance[3, i] = np.sum(dataStruct["classes"][stratificationValid] == i);
# Normalize the counts (for better readability)
for i in range(4):
    classBalance[i, :] = classBalance[i, :] / np.sum(classBalance[i, :])
# Plot the class balance between different validation approaches
#plt.bar(classBalance);
#plt.title('Class balance - ' + str(validationPercent * 100) + '# ');
#set(gca, 'XTickLabel', {'Hold_{train}', 'Hold_{valid}', 'Strat_{train}', 'Strat_{valid}'}); 

# Re-implement a previous classification algorithm

    ######################
    # YOUR CODE GOES HERE
    ######################

# Evaluate variance, bias and optimism bias
    
    ######################
    # YOUR CODE GOES HERE
    ######################

##
# 10.3 - Model selection

nEvaluations = 100;

# Grid search

    ######################
    # YOUR CODE GOES HERE
    ######################

# Keep track of besties
bestErrSum = 1;
bestErrs = [];
bestS = -1; bestD = -1; bestT = -1; 

    ######################
    # YOUR CODE GOES HERE
    ######################
    
# Random search
bestErrSum = nInputs + 1;
bestErrs = [];
bestS = -1; bestD = -1; bestT = -1; 
 
    ######################
    # YOUR CODE GOES HERE
    ######################
   

# Candidate pool

    ######################
    # YOUR CODE GOES HERE
    ######################

classifierPool = {}; 
curClassifier = 1;

    ######################
    # YOUR CODE GOES HERE
    ######################
    

##
# 10.4 - Cross-validation

    ######################
    # YOUR CODE GOES HERE
    ######################
