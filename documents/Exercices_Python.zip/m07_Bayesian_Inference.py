#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 7 - Bayesian inference
#
# <https://esling.github.io/ [...]>
# <esling@ircam.fr>
#

# Load all files in sub-directories
from m07_Bayesian_Inference import classifyData as cd
from m07_Bayesian_Inference import discriminantFunction as df
from m07_Bayesian_Inference import mleCovariance as mc
from m07_Bayesian_Inference import plotGaussianEllipsoid as pge
from matplotlib import pyplot as plt
import numpy as np

#%%
# 7.0 - Generate data with known parameters

nbPatterns = 100
# Generate random patterns for class 1
mu1 = np.array([0,0])
cov1 = np.array([[1,0],[0,1]])
# Generate random patterns for class 2
mu2 = np.array([9,0])
cov2 = np.array([[3,0],[0,3]])
# Generate random patterns for class 3
mu3 = np.array([6,6])
cov3 = np.array([[7,0],[0,7]])

    ######################
    # YOUR CODE GOES HERE
    ######################

# Prepare concatenated versions of class properties
muVals = {}; 
muVals[0] = np.array([mu1]).transpose() 
muVals[1] = np.array([mu2]).transpose() 
muVals[2] = np.array([mu3]).transpose()
covVals = {}
covVals[0] = cov1
covVals[1] = cov2
covVals[2] = cov3
# Plot the corresponding data
plt.figure(figsize=(12, 8))
plt.scatter(x1samples[:, 0], x1samples[:, 1], s=40, marker='o', c=[0, 0.8, 0], edgecolors=[0, 0.4, 0])
plt.scatter(x2samples[:, 0], x2samples[:, 1], s=40, marker='s', c=[0, 0, 0.8], edgecolors=[0, 0, 0.4])
plt.scatter(x3samples[:, 0], x3samples[:, 1], s=40, marker='^', c=[0.8, 0, 0], edgecolors=[0.4, 0, 0])
h = pge.plotGaussianEllipsoid(mu1, cov1, 2); #set(h, 'Color', [0.2, 0.2, 0.2], 'LineWidth', 3, 'LineStyle', '--')
h = pge.plotGaussianEllipsoid(mu2, cov2, 2); #set(h, 'Color', [0.2, 0.2, 0.2], 'LineWidth', 3, 'LineStyle', '--')
h = pge.plotGaussianEllipsoid(mu3, cov3, 2); #set(h, 'Color', [0.2, 0.2, 0.2], 'LineWidth', 3, 'LineStyle', '--')
plt.title('Training Dataset')
plt.ylabel('x_2')
plt.xlabel('x_1')
    
#%%
# 7.1 - Discriminant function and classification

########################################################
# YOUR CODE GOES IN 
# - 07_Bayesian_Inference/discriminantFunction.m
# - 07_Bayesian_Inference/classifyData.m
########################################################
x1classes = np.zeros((nbPatterns, 1))
confMatrix = np.zeros((3, 3))
for i in range(nbPatterns):
    x, g = cd.classifyData(x1samples[i, :], df.discriminantFunction, muVals, covVals);
    x1classes[i] = g;
    confMatrix[0, g] = confMatrix[0, g] + 1;
x2classes = np.zeros((nbPatterns, 1))
for i in range(nbPatterns):
    x, g = cd.classifyData(x2samples[i, :], df.discriminantFunction, muVals, covVals);
    x2classes[i] = g;
    confMatrix[1, g] = confMatrix[1, g] + 1;
x3classes = np.zeros((nbPatterns, 1))
for i in range(nbPatterns):
    x, g = cd.classifyData(x3samples[i, :], df.discriminantFunction, muVals, covVals);
    x3classes[i] = g;
    confMatrix[2, g] = confMatrix[2, g] + 1;

print('%16s \t %s \t %s \t %s\n' % (' ', 'class 1', 'class 2', 'class 3'));
print('%16s \t %f \t %f \t %f\n' % ('class 1', confMatrix[0, 0], confMatrix[0, 1], confMatrix[0, 2]));
print('%16s \t %f \t %f \t %f\n' % ('class 2', confMatrix[1, 0], confMatrix[1, 1], confMatrix[1, 2]));
print('%16s \t %f \t %f \t %f\n' % ('class 3', confMatrix[2, 0], confMatrix[2, 1], confMatrix[2, 2]));
 
#%%
# 7.2 - Compute estimators


########################################################
# YOUR CODE GOES HERE (Perform mu estimates)
########################################################

# muEst1 = ?
# muEst2 = ?
# muEst3 = ?

print('%16s \t %s \t %s \t %s \t %s \t %s \t %s' % ('', 'mu1_1   ', 'mu1_2  ', 'mu2_1  ', 'mu2_2  ', 'mu3_1  ', 'mu3_2  '));
print('%16s \t %f \t %f \t %f \t %f \t %f \t %f' % ('MLE', muEst1[0], muEst1[1], muEst2[0], muEst2[1], muEst3[0], muEst3[1]));
print('%16s \t %f \t %f \t %f \t %f \t %f \t %f' % ('Truth', mu1[0], mu1[1], mu2[0], mu2[1], mu3[0], mu3[1]));

########################################################
# YOUR CODE GOES IN 07_Bayesian_Inference/mleCovariance.m
########################################################

reload(mc)

covEst1 = mc.mleCovariance(x1samples, np.array([muEst1]).transpose());
covEst2 = mc.mleCovariance(x2samples, np.array([muEst2]).transpose());
covEst3 = mc.mleCovariance(x3samples, np.array([muEst3]).transpose());

print('%16s \t %s \t %s \t %s \t %s \t %s \t %s' % ('', 'cov1_1   ', 'cov1_2  ', 'cov2_1  ', 'cov2_2  ', 'cov3_1  ', 'cov3_2  '));
print('%16s \t %f \t %f \t %f \t %f \t %f \t %f' % ('MLE', covEst1[0, 0], covEst1[1, 0], covEst2[0, 0], covEst2[1, 0], covEst3[0, 0], covEst3[1, 0]));
print('%16s \t %f \t %f \t %f \t %f \t %f \t %f' % ('Truth', cov1[0, 0], cov1[1, 0], cov2[0, 0], cov2[1, 0], cov3[0, 0], cov3[1, 0]));

muEstimates = {}; 
muEstimates[0] = np.array([muEst1]).transpose()  
muEstimates[1] = np.array([muEst2]).transpose()  
muEstimates[2] = np.array([muEst3]).transpose() 
covEstimates = {}; 
covEstimates[0] = covEst1; 
covEstimates[1] = covEst2; 
covEstimates[2] = covEst3;

# Plot the corresponding data
plt.figure(figsize=(12, 8))
plt.scatter(x1samples[:,0], x1samples[:,1], s=40, marker='o', c=[0, 0.8, 0], edgecolors=[0, 0.4, 0]);
plt.scatter(x2samples[:,0], x2samples[:,1], s=40, marker='s', c=[0, 0, 0.8], edgecolors=[0, 0, 0.4]);
plt.scatter(x3samples[:,0], x3samples[:,1], s=40, marker='^', c=[0.8, 0, 0], edgecolors=[0.4, 0, 0]);
h = pge.plotGaussianEllipsoid(mu1, cov1, 2); #set(h, 'Color', [0.2, 0.2, 0.2], 'LineWidth', 3, 'LineStyle', '--');
h = pge.plotGaussianEllipsoid(mu2, cov2, 2); #set(h, 'Color', [0.2, 0.2, 0.2], 'LineWidth', 3, 'LineStyle', '--');
h = pge.plotGaussianEllipsoid(mu3, cov3, 2); #set(h, 'Color', [0.2, 0.2, 0.2], 'LineWidth', 3, 'LineStyle', '--');
h = pge.plotGaussianEllipsoid(muEst1, covEst1, 2); #set(h, 'Color', [1.0, 0.8, 0.1], 'LineWidth', 3, 'LineStyle', '-.');
h = pge.plotGaussianEllipsoid(muEst2, covEst2, 2); #set(h, 'Color', [1.0, 0.8, 0.1], 'LineWidth', 3, 'LineStyle', '-.');
h = pge.plotGaussianEllipsoid(muEst3, covEst3, 2); #set(h, 'Color', [1.0, 0.8, 0.1], 'LineWidth', 3, 'LineStyle', '-.');
plt.title('Comparing estimated MLE Gaussians');


#%%
# 7.2 - Classify based on estimated values

x1classes = np.zeros((nbPatterns, 1))
confMatrix = np.zeros((3, 3))
for i in range(nbPatterns):
    x, g = cd.classifyData(x1samples[i, :], df.discriminantFunction, muEstimates, covEstimates);
    x1classes[i] = g;
    confMatrix[0, g] = confMatrix[0, g] + 1;
x2classes = np.zeros((nbPatterns, 1))
for i in range(nbPatterns):
    x, g = cd.classifyData(x2samples[i, :], df.discriminantFunction, muEstimates, covEstimates);
    x2classes[i] = g;
    confMatrix[1, g] = confMatrix[1, g] + 1;
x3classes = np.zeros((nbPatterns, 1))
for i in range(nbPatterns):
    x, g = cd.classifyData(x3samples[i, :], df.discriminantFunction, muEstimates, covEstimates);
    x3classes[i] = g;
    confMatrix[2, g] = confMatrix[2, g] + 1;

print('%16s \t %s \t %s \t %s\n' % (' ', 'class 1', 'class 2', 'class 3'));
print('%16s \t %f \t %f \t %f\n' % ('class 1', confMatrix[0, 0], confMatrix[0, 1], confMatrix[0, 2]));
print('%16s \t %f \t %f \t %f\n' % ('class 2', confMatrix[1, 0], confMatrix[1, 1], confMatrix[1, 2]));
print('%16s \t %f \t %f \t %f\n' % ('class 3', confMatrix[2, 0], confMatrix[2, 1], confMatrix[2, 2]));

#%%
# 7.5 - Audio source separation

