import numpy as np
import os as os

#
# Main function for importing a dataset
#
def importDataset(classPath, typeD):
    # Type of files admitted
    wavExt = ['wav', 'wave']
    audioExt = wavExt + ['mp3', 'au', 'aiff', 'ogg']
    if (typeD == "classification"):
        # Listing of classes in the classification problem
        classesPaths = []
        # List classes first
        for item in os.listdir(classPath):
            if os.path.isdir(os.path.join(classPath, item)):
                classesPaths.append(item)
        # Set of classes data
        classData = {}
        # Number of classes
        nbClasses = len(classesPaths)
        # Names of the classes
        classData["name"] = []
        # Number of files
        classData["nbFiles"] = np.zeros((len(classesPaths)))
        # Filenames for each class
        classData["filenames"] = []
        # Keep track of the full number of files
        fullNbFiles = 0
        print('    - Importing dataset %s.\n' % classPath)
        # Parse through all the classes
        for c in range(nbClasses):
            classData["name"].append(classesPaths[c])
            # Files for each class
            classFiles = [];
            for item in os.listdir(classPath + '/' + classesPaths[c]):
                if (os.path.splitext(item)[1][1:] in audioExt):
                    classFiles.append(item)
            classData["nbFiles"][c] = len(classFiles)
            curFiles = []
            for f in range(len(classFiles)):
                curFiles.append(classPath + '/' + classesPaths[c] + '/' + classFiles[f])
            classData["filenames"].append(curFiles)
            fullNbFiles = fullNbFiles + classData["nbFiles"][c]
        # Linearize into one flat structure
        filenames = []
        classes = [];
        curStart = 1;
        for c in range(nbClasses):
            nbFiles = classData["nbFiles"][c];
            curFiles = classData["filenames"][c];
            filenames = filenames + curFiles;
            classes = classes + np.ndarray.tolist(np.repeat(c, nbFiles));
            curStart = curStart + nbFiles;
        dataStruct = {};
        dataStruct["filenames"] = filenames;
        dataStruct["classes"] = np.array(classes);
        dataStruct["classNames"] = classData["name"];
    elif typeD == 'music-speech':
        # Keep track of the full number of files
        fullNbFiles = 0;
        print('    - Importing dataset %s.\n' % classPath);
        classFiles = [];
        labFiles = [];
        # Parse through the audio files
        for item in os.listdir(classPath + '/music/'):
            if (os.path.splitext(item)[1][1:] in audioExt):
                classFiles.append(classPath + '/music/' + item);
                fPath = os.path.splitext(item)[0]
                labFiles.append(classPath + '/labels/' + fPath + '.lab');
        dataStruct = {};
        dataStruct["filenames"] = classFiles;
        dataStruct["labfiles"] = labFiles;
    else:
        raise Error('Unknown dataset type ' + typeD);
    return dataStruct

