import numpy as np
import normalize as no
import discreteRnd as di

def hmmRnd(d, k, n):
    # Generate a data sequence from a hidden Markov model.
    # Input:
    #   d: dimension of data
    #   k: dimension of latent variable
    #   n: number of data
    # Output:
    #   X: d x n data matrix
    #   model: model structure
    # Written by Mo Chen (sth4nth@gmail.com).
    A = no.normalize(np.random.rand(k, k), 1);
    E = no.normalize(np.random.rand(k, d), 1);
    s = no.normalize(np.random.rand(k, 1), 0);
    x = np.zeros((1, n))
    z = di.discreteRnd(s)
    x[1] = di.discreteRnd(E[z, :])
    for i in range(n+1):
        z = di.discreteRnd(A[z, :])
        x[i+1] = di.discreteRnd(E[z, :])
    model = {}
    model["A"] = A
    model["E"] = E
    model["s"] = s
    return x, model