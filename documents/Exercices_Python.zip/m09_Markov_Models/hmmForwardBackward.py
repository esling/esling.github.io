import numpy as np
import normalize as no

def hmmForwardBackward(E, A, s):
    # Implmentation function HMM smoothing alogrithm.
    # Unlike the method described in the slides, the alpha returned is the normalized version: gamma(t)=p(z_t|x_{1:T})
    # Computing unnormalized version gamma(t)=p(z_t,x_{1:T}) is numerical unstable, which grows exponential fast to infinity.
    # Input:
    #   M: k x n emission data matrix M=E*X
    #   A: k x k transition matrix
    #   s: k x 1 start prior probability
    # Output:
    #   gamma: k x n matrix of posterior gamma(t)=p(z_t,x_{1:T})
    #   alpha: k x n matrix of posterior alpha(t)=p(z_t|x_{1:T})
    #   beta: k x n matrix of posterior beta(t)=gamma(t)/alpha(t)
    #   c: loglikelihood
    # Written by Mo Chen (sth4nth@gmail.com).
    K, T = E.shape
    At = A.transpose()
    c = np.zeros(T) # normalization constant
    alpha = np.zeros((K, T))

    ######################
    # YOUR CODE GOES HERE
    ######################

    return gamma, alpha, beta, c