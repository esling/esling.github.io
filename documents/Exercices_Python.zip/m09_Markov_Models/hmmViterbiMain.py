import numpy as np
from .hmmViterbi import hmmViterbi

def hmmViterbiMain(x, model):
# Viterbi algorithm calculated in log scale to improve numerical stability.
# This is a wrapper function which transform input and call underlying algorithm
# Input:
#   x: 1 x n integer vector which is the sequence of observations
#   model:  model structure
# Output:
#   z: 1 x n latent state
# Written by Mo Chen (sth4nth@gmail.com).
    A = model["A"]
    E = model["E"]
    s = model["s"]
    d = model["d"]
    
    def oneHot(x, m):
        res = np.zeros((m, x.shape[0]))
        for i in range(x.shape[0]):
            res[int(x[i]), i] = 1;
        return res
    
    X = oneHot(x[0], d)
    M = np.dot(E, X);
    z, p = hmmViterbi(M, A, s)
    return z, p
