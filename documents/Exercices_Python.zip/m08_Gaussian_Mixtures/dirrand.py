import numpy as np

 #####################################################
# Sample from Dirichlet distribution
# function X = dirrand(a,N)
#
# Inputs: a - parameters of Dirichlet distribution
#         N - number of samples
# Output: X - Nxd matrix of Dirichlet samples
def dirrand(a,N):
    return np.random.dirichlet(a, size=(N, 1))