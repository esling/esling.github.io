import numpy as np

def expectedValue(x, mu1, mu2):
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return vals

