import numpy as np

def emGMMFit(X,k,Cv):
    ## EM for GMMs
    # [M,C,P,iters] = EM_GMM(X,k)
    #
    # Inputs: X - data (points x dims)
    #         k - # of gaussians
    # Outputs: M - cell array of means at each iteration
    #          C - cell array of covars at each iteration
    #          P - cell array of posteriors at each iteration
    #          i - iterations to convergence

    N = X.shape[0]
    d = X.shape[1]
    A = np.zeros((N,k)) # posteriors
    # initialize
    Cx = np.sqrtm(np.cov(X));
    m = (np.sum(X, 1) / N ) + np.dot(np.random.randn(k,d), Cx);
    w = np.ones((1, k)) / k # mixing weights
    if Cv: 
        Ca = np.repeat(Cx, [1,1,k]); # full cov
    else:
        Ca = np.ones((k,d)) # diagonal cov
    
    # save params from each iteration
    M = {} #cell(1,50);
    C = {} #cell(1,50);
    P = {} #cell(1,50);
    
    M[1] = m;
    if Cv:
      C[1] = Ca;
    else:
      C[1] = np.zeros((d,d,k))
      for j in range(k):
        C[1][:,:,j] = np.diag(Ca[j,:]);
    P[1] = np.ones((N,k)) / k;
    
    # iterate
    ll = -np.inf;
    for i in range(49):
        ll_old = ll;
      
        # -- E step --
        ######################
        # YOUR CODE GOES HERE
        ######################
      
        # -- M step --
        ######################
        # YOUR CODE GOES HERE
        ######################
        
        
        # -- save means, covars, posteriors --
        M[i] = m
        if Cv:
            C[i] = Ca;
        else:
            C[i] = np.zeros((d,d,k))
            for j in range(k):
                C[i][:, :, j] = np.diag(Ca[j, :]);
        P[i] = p;
      
        # -- test convergence --
        ll = np.sum(As);
        if np.abs((ll - ll_old) / ll_old) < np.power(10, -4):
            break
            
    return M,C,P,i