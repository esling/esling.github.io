import numpy as np

## ########################################################
# Log-sum-exp for sumation in the log domain
# function y = logsum(x,d)
#
# Inputs: x - matrix or vector
#         d - dimension to sum over
# Output: y - logsum output
def logsum(x,d):
    m = np.max(x, axis=d);
    y = np.log(np.sum(np.exp(x - m), axis=d)) + m;
    return y