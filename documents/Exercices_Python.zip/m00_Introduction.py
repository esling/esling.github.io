# ---------------
# ATIAM - Music machine learning tutorial
#
# Part 0 - Introduction
# Import data, pre-process and compute features
#
# In this tutorial, we will cover basic Music Information Retrieval (MIR)
# interactions, in which we process a dataset of sound files and try to
# observe the properties of their various spectral features
#
# <https://esling.github.io/atiam-ml-0-intro/>
# <esling@ircam.fr>
#

#%% Import useful modules
#import m00_Features
#import m00_Introduction
#import m00_Preprocessing
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import gridspec
from mpl_toolkits.mplot3d import Axes3D
#%% Path to the classification dataset
classPath = 'm00_Datasets/classification';

#%%
import importDataset as imp
# 0.1 - Import the classification dataset
dataStruct = imp.importDataset(classPath, 'classification');

#%% Q-0.1.2 - Count function to print the number of examples

######################
# YOUR CODE GOES HERE
######################

#%%
# 0.2 - Pre-process the audio to obtain spectral transforms 
# (may take around a minute)
import computeTransforms as cpt
dataStruct = cpt.computeTransforms(dataStruct);

#%% Q-0.2.2 - Plot the various transforms 

######################
# YOUR CODE GOES HERE
######################
        
#%%
# 0.3 - Compute a set of temporal and spectral features
# (may take around 1-2 minutes)
import computeFeatures as cft
dataStruct = cft.computeFeatures(dataStruct);

#%% Q-0.3.2 - Plot the various features 

######################
# YOUR CODE GOES HERE
######################

#%% Q-0.3.4 - Observe the distribution of classes for different features

plt.figure(figsize=(12,8))
# Create a vector of random colors for each class
colorVect = np.zeros((3, len(dataStruct["classNames"])));
for c in range(len(dataStruct["classNames"])):
    colorVect[:,c] = np.random.rand(3);

######################
# YOUR CODE GOES HERE
######################