import numpy as np

def kmeans(X, k):
    # X: d x n data matrix
    # k: number of seeds

    ######################
    # Solution

    ######################
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return label
