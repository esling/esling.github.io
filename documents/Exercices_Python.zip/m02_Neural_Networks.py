#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 2 - Neural Networks
#
# In this tutorial, we will cover a more advanced classification algorithm
# through the use of neural networks. The tutorial starts by performing
# a simple single neuron discrimination of two random distributions.
# Then, we will study the typical XOR problem by using a more advanced
# 2-layer perceptron. Finally, we generalize the use of neural networks in
# order to perform classification on our set of audio classification
# dataset.
#
# <esling@ircam.fr>
#

# Load all files in sub-directories
from m02_Neural_Networks import plotPatterns as pltP
from m02_Neural_Networks import plotBoundary as pltB
import numpy as np
import time
# Path to the classification dataset
classPath = '00_Datasets/classification';

#%% 0.1 - Import the classification dataset
import importDataset as imp
import computeTransforms as cpt
import computeFeatures as cft
dataStruct = imp.importDataset(classPath, 'classification');
# 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = cpt.computeTransforms(dataStruct);
# 0.3 - Compute a set of temporal and spectral features
dataStruct = cft.computeFeatures(dataStruct);

#%%
# 2.1 - Single neuron discrimination of two random distributions
# Number of points to generate
nPats = 30 + np.floor(np.random.rand() * 30);
# Generate 2-dimensional random points
patterns = np.random.rand(2, int(nPats)) * 2 - 1;
# Slope of separating line
slope = np.log(np.random.rand() * 10);
yint = np.random.rand() * 2 - 1;
# Create the indexes for a two-class problem
desired = (patterns[1,:] - patterns[0,:] * slope - yint > 0) * 1;
# Plot the corresponding pattern
fig = pltP.plotPatterns(patterns,desired);
# Inputs to use
inputs = patterns;
# Initialize the weights
weights = np.random.randn(1, 2);
bias = np.random.randn(1, 1)
# Learning rate
eta = 0.05;
# Weight decay
lambdaW = 0.1
# Update loop
for i in range(50):
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    print('%2d.  weights = %f, %f, %f' % (i, bias[0, 0], weights[0, 0], weights[0, 1]))
    pltB.plotBoundary(np.concatenate((bias, weights), axis=1), i, '--', fig)
    time.sleep(0.2)
pltB.plotBoundary(np.concatenate((bias, weights), axis=1), i, '-', fig);

#%% Version integrating the bias (optional)

# Inputs to use
inputs = np.concatenate((np.ones((1, int(nPats))), patterns));
# Initialize the weights
weights = np.random.randn(1, 3);
# Learning rate
eta = 0.05;
# Weight decay
lambdaW = 0.1
# Plot the corresponding pattern
fig = pltP.plotPatterns(patterns,desired);
# Update loop
for i in range(50):
  # Compute the classification
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    print('%2d.  weights = %f, %f, %f' % (i, weights[0, 0], weights[0, 1], weights[0, 2]))
    pltB.plotBoundary(weights, i, '--', fig)
    time.sleep(0.1)
pltB.plotBoundary(weights, i, '-', fig);

#%%
# 2.2 - 2-layer neural network classification for solving the XOR problem

#load xorPats.dat
#load xorAns.dat
patterns = np.array([[-1, -1],[-1,  1],[1, -1],[1,  1]]).transpose() # Input patterns
desired = np.array([0, 1, 1, 0])                       # Corresponding classes
# Initialize based on their sizes
nInputs = patterns.shape[0]
nOutputs = 1
nPat = patterns.shape[1]
# First plot the patterns
fig = pltP.plotPatterns(patterns, desired);
#%% Learning parameters
nHiddens = 2           # Number of hidden units
learnRate = 0.08       # Learning rate parameter
momentum = 0.5         # Momentum parameter
# Overall input patterns
inputs = patterns
# Weights of first and second layer
weights1 = np.random.randn(nHiddens, nInputs) - 0.5      # 1st layer weights
weights2 = np.random.randn(nOutputs, nHiddens) - 0.5     # 2nd layer weights
bias1 = np.random.randn(nHiddens, 1) - 0.5               # 1st layer biases
bias2 = np.random.randn(nOutputs, 1) - 0.5               # 2nd layer biases
TSS_Limit = 0.02                                           # Sum-squared error limit
# Previous gradients (for momentum)
deltaW1 = 0
deltaW2 = 0
deltaB1 = 0
deltaB2 = 0
eta = 0.05
TSS = 1
# Iterate for a fixed number of iterations
for epoch in range(200):
  
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    print('Epoch %3d:  Error = %f' % (epoch, TSS));
    if TSS < TSS_Limit:
        break
    if (epoch - 1 % 20)==0:
        pltB.plotBoundary(np.concatenate((bias1, weights1), axis=1), epoch, '--', fig)

pltB.plotBoundary(np.concatenate((bias1, weights1), axis=1), epoch, '-', fig)

#%%
# 2.3 - 3-layer neural network for audio classification
#

# First we will construct the data features matrix
usedFeatures = ['SpectralCentroidMean', 'LoudnessMean', 'SpectralContrastMean']
dataMatrix = np.zeros((len(dataStruct["filenames"]), len(usedFeatures)))
for f in range(len(usedFeatures)):
    dataMatrix[:, f] = dataStruct[usedFeatures[f]];
dataMatrix = np.nan_to_num(dataMatrix)
patterns = dataMatrix / np.max(dataMatrix)
# Construct a binary vector of outputs (class indicators)
n_values = np.max(dataStruct["classes"]) + 1
#desired = np.eye(n_values)[dataStruct["classes"]]
nbTrain = desired.shape[0]
patterns = np.transpose(patterns)
desired = dataStruct["classes"]#np.transpose(desired)
# First plot the patterns
pltP.plotPatterns(patterns,desired);
# Initialize based on their sizes
nInputs = patterns.shape[0]
nOutputs = desired.shape[0]
nPats = patterns.shape[1]
# First plot the patterns
# Learning parameters
nHiddens = 100         # Number of hidden units
learnRate = 0.08       # Learning rate parameter
momentum = 0.8         # Momentum parameter
# Overall input patterns
inputs = patterns
# Weights of first and second layer
weights1 = np.random.randn(nHiddens, nInputs)       # 1st layer weights
weights2 = np.random.randn(nHiddens, nHiddens)      # 2nd layer weights
weightsSoft = np.random.randn(nOutputs, nHiddens)   # Softmax layer weights
bias1 = np.random.randn(nHiddens, 1)                # 1st layer biases
bias2 = np.random.randn(nHiddens, 1)                # 2nd layer biases
TSS_Limit = 0.02                                   # Sum-squared error limit
# Previous gradients (for momentum)
deltaSoft = 0
deltaW1 = 0
deltaW2 = 0
deltaB1 = 0
deltaB2 = 0
eta = 0.0008
# Function for computing the Sigmoid activation
def sigmoid(x):
    return 1 / (1 + np.exp(-x))
def dsigmoid(a):
    return a * (1.0 - a)
# Function for computing the ReLU activation
def relu(x):
    return np.max(0, x)
def drelu(x):
    return 1 / (1 + np.exp(-x))
# Function for computing the Tanh activation
def tanh(x):
    return np.tanh(x);
def dtanh(x): 
    return np.cosh(x) ^ -2
# Iterate for a fixed number of iterations
for epoch in range(500):
  
    ######################
    # YOUR CODE GOES HERE
    ######################
    
  print('Epoch %3d:  Error = %f\n' % epoch, TSS);
  if TSS < TSS_Limit:
      break
plotBoundary(np.concatenate(bias1, weights1), epoch, '-');

#%%
# 2.4 - Using Keras to do models (3-layer network)
#

#%% Sequential version
import keras
from keras.models import Sequential
from keras.layers import Dense, Activation
# Create a sequential model
model = Sequential()
  
    ######################
    # YOUR CODE GOES HERE
    ######################

model.fit(data, labels)

#%% Functional version
from keras.layers import Input, Dense
from keras.models import Model
# Layers defined as nngraph
inputs = Input(shape=(784,))
  
    ######################
    # YOUR CODE GOES HERE
    ######################
