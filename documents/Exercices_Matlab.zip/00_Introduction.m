% ---------------
% ATIAM - Music machine learning tutorial
%
% Part 0 - Introduction
% Import data, pre-process and compute features
%
% In this tutorial, we will cover basic Music Information Retrieval (MIR)
% interactions, in which we process a dataset of sound files and try to
% observe the properties of their various spectral features
%
% <https://esling.github.io/atiam-ml-0-intro/>
% <esling@ircam.fr>
%

% Load all files in sub-directories
addpath(genpath('00_Datasets/'));
addpath(genpath('00_Features/'));
addpath(genpath('00_Introduction/'));
addpath(genpath('00_Preprocessing/'));
% Path to the classification dataset
classPath = '00_Datasets/classification';

%%
% 0.1 - Import the classification dataset
dataStruct = importDataset(classPath, 'classification');

%% Q-0.1.2 - Count function to print the number of examples

%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES HERE
%%%%%%%%%%%%%%%%%%%%%%

%%
% 0.2 - Pre-process the audio to obtain spectral transforms 
% (may take around a minute)
dataStruct = computeTransforms(dataStruct);

%% Q-0.2.2 - Plot the various transforms 

%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES HERE
%%%%%%%%%%%%%%%%%%%%%%

%%
% 0.3 - Compute a set of temporal and spectral features
% (may take around 1-2 minutes)
dataStruct = computeFeatures(dataStruct);

%% Q-0.3.2 - Plot the various features 

%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES HERE
%%%%%%%%%%%%%%%%%%%%%%

%% Q-0.3.4 - Observe the distribution of classes for different features

figure; hold on;
colorVect = zeros(3, length(dataStruct.classNames));
for c = 1:length(dataStruct.classNames)
    colorVect(:, c) = rand(3, 1);
end

%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES HERE
%%%%%%%%%%%%%%%%%%%%%%

hold off;