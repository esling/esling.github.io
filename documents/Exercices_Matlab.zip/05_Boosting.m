% ---------------
% ATIAM - Music machine learning tutorial
%
% Part 5 - Meta-heuristics
%
% The present tutorials covers the use of different meta-heuristics. 
% We will focus on the use of boosting by performing an implementation of 
% the Adaboost algorithm. The tutorial does not cover the implementation of 
% genetic algorithms, but interested students can find some nice 
% online tutorials
% https://www.tutorialspoint.com/genetic_algorithms/index.htm
%
% <https://esling.github.io/atiam-ml-5-boosting/>
% <esling@ircam.fr>
%

% Load all files in sub-directories
addpath(genpath('00_Datasets/'));
addpath(genpath('00_Features/'));
addpath(genpath('00_Introduction/'));
addpath(genpath('00_Preprocessing/'));
addpath(genpath('05_Boosting/'));
% Path to the classification dataset
classPath = '00_Datasets/classification';

% 0.1 - Import the classification dataset
dataStruct = importDataset(classPath, 'classification');
% 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = computeTransforms(dataStruct);
% 0.3 - Compute a set of temporal and spectral features
dataStruct = computeFeatures(dataStruct);

%%
% 5.1 - Generating random distributions

nDims = 2;
nInputs = 1000;
type = 'uniform';
% Generate uniformly distributed data
patterns = randn(nInputs, nDims) * 0.8;
% Linear separation example
labelsLinear = double(patterns(:, 1) < patterns(:, 2));
% Non-linear separation example
labels = double(patterns(:, 1) .^ 2 + patterns(:, 2) .^ 2 < 1);
labels(labels == 0) = -1;
%labels(labels == 0) = -1;
% Plot the data
figure; whitebg(gcf,[1 1 1])
hold on;
scatter(patterns(labels == -1, 1), patterns(labels == -1, 2), 10, 'r');
scatter(patterns(labels == 1, 1), patterns(labels == 1, 2), 10, 'g');

%%
% 5.1.1 - Implement a single classifier and test it

%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 05_Boosting/weakClassifierError.m
%%%%%%%%%%%%%%%%%%%%%%

dim = randi(nDims);
t = randn(1);
sign = randi(2) - 1;
[errSum, errs] = weakClassifierError(t, dim, sign, patterns, labels);
% Plot the classifier and corresponding errors
plotClassifier(t, dim, sign, patterns, labels);

%%
% 5.1.2 - Perform different search algorithms

nClassifiers = 100;

% Grid search

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

% Keep track of besties
bestErrSum = nInputs + 1;
bestErrs = [];
bestS = -1; bestD = -1; bestT = -1; 

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
plotClassifier(bestT, bestD, bestS, patterns, labels);
    
% Random search
bestErrSum = nInputs + 1;
bestErrs = [];
bestS = -1; bestD = -1; bestT = -1; 
for i = 1:(nClassifiers * 10)
    
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
end
plotClassifier(bestT, bestD, bestS, patterns, labels);

% Candidate pool

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

classifierPool = {}; 
curClassifier = 1;

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
plotClassifier(bestT, bestD, bestS, patterns, labels);

%%
% 5.2.1 - Implement the main boosting algorithm

nbIterations = 50;
nClassifiers = 1000;
weights = (ones(nInputs, 1)) ./ nInputs;
classifiers = zeros(nbIterations, 3);
alpha = zeros(nbIterations, 1);
errors = zeros(nbIterations, 1);
% Iterate boosting
for it = 1:nbIterations;
    bestErrSum = nInputs + 1;
    bestErrs = []; bestID = -1;
    bestS = -1; bestD = -1; bestT = -1;
    
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
    fprintf('Iteration.%d - %d misses - (Weighted error : %f)\n', it, misshits(it), errors(it));
    plotBoosting(classifiers, patterns, labels, it, weights, alpha);
    pause;
end

%%
% 5.3.1 - Audio application

% First we will construct the data features matrix
% but this time use a very large amount of features
usedFeatures = {'SpectralCentroidMean', 'SpectralFlatnessMean', 'SpectralSkewnessMean', 'SpectralFlatnessMean', 'SpectralSpreadMean', ...
    'SpectralCentroidStd', 'SpectralFlatnessStd', 'SpectralSkewnessStd', 'SpectralFlatnessStd', 'SpectralSpreadStd'};
dataMatrix = zeros(length(dataStruct.filenames), length(usedFeatures));
for f = 1:length(usedFeatures)
    dataMatrix(:, f) = dataStruct.(usedFeatures{f});
end
% Number of dimensions
nDims = length(usedFeatures);
dataMatrix(isnan(dataMatrix)) = 0;
patterns = dataMatrix ./ repmat(max(dataMatrix), size(dataMatrix, 1), 1);
% Construct a binary vector of outputs (class indicators)
desired = full(sparse(dataStruct.classes, 1:size(patterns, 1), 1))';
disp(size(desired));
nbTrain = size(desired, 1);
patterns = patterns';
desired = desired';
% Number of classes to evaluate
nbClasses = length(dataStruct.classNames);
nbIterations = 50;
nClassifiers = 1000;
weights = (ones(nInputs, 1)) ./ nInputs;
classifiers = zeros(nbIterations, 3);
alpha = zeros(nbIterations, 1);
errors = zeros(nbIterations, 1);

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
