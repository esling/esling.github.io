function dataStruct = computeTransforms(dataStruct)
% Overall settings
fSize = 1024;
wSize = fSize;
hSize = ceil(fSize/4);
refSr = 44100;
% Constant-Q settings
binOct = 24;
fMin = 27.5;
fMax = 10000;
gamma = 20;
% Number of files
fullNbFiles = length(dataStruct.filenames);
% Create field for each transform
dataStruct.signal = cell(fullNbFiles, 1);
dataStruct.sRate = cell(fullNbFiles, 1);
dataStruct.spectrumPower = cell(fullNbFiles, 1);
dataStruct.spectrumBark = cell(fullNbFiles, 1);
dataStruct.spectrumMel = cell(fullNbFiles, 1);
dataStruct.spectrumChroma = cell(fullNbFiles, 1);
dataStruct.spectrumCepstrum = cell(fullNbFiles, 1);
fprintf('    - Performing transforms.\n');
% Perform an analysis of spectral transform for each
for f = 1:fullNbFiles
    fprintf('      * %s.\n', dataStruct.filenames{f});
    [sig, sr] = audioread(dataStruct.filenames{f});
    dataStruct.signal{f} = sig;
    dataStruct.sRate{f} = sr;
    if (f == 1 || sr ~= refSr)
        % Compute the Bark matrix
        wBark = fft2barkmx((fSize/2), sr);
        % Compute the Chroma matrix
        wChroma = fft2chromamx(fSize, 12, sr);
        wChroma = wChroma(:, 1:fSize/2);
        % Compute the Mel matrix
        wMel = fft2melmx((fSize/2), sr, 40, 1, 133.33, 6855.5, 0);
    end
    psc = stft(sig, fSize, wSize, hSize, sr);
    powerspec = abs(psc);
    dataStruct.spectrumPower{f} = powerspec(1:(fSize/2), :);
    dataStruct.spectrumBark{f} = wBark * dataStruct.spectrumPower{f};
    dataStruct.spectrumMel{f} = wMel * dataStruct.spectrumPower{f};
    dataStruct.spectrumChroma{f} = wChroma * dataStruct.spectrumPower{f};
    dataStruct.spectrumCepstrum{f} = spec2cep(dataStruct.spectrumPower{f});
    % Compute the Constant-Q transform
    Xcq = cqt(sig, binOct, sr, fMin, fMax, 'rasterize', 'full', 'gamma', gamma);
    dataStruct.spectrumConstantQ{f} = abs(Xcq.c);
end