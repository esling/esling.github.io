%% ---------------
% ATIAM - Music machine learning tutorial
%
% Part 3 - Support Vector Machines
%
% In this tutorial, we will cover a more advanced classification algorithm
% through the use of Support Vector Machines. The goal is to gain an 
% intuition of how SVMs works and how to use Gaussian kernel with SVMs to 
% find out the decision doundary.
%
% <esling@ircam.fr>
%
%     gaussianKernel.m & linearKernel.m
%     example3parameters.m
%     svmTrain.m
%     svmPredict.m
%     DecsionBoundary.m
%     DecisionBoundaryLinear.m
%     plotData.m
%     

% Load all files in sub-directories
addpath(genpath('00_Datasets/'));
addpath(genpath('00_Features/'));
addpath(genpath('00_Introduction/'));
addpath(genpath('00_Preprocessing/'));
addpath(genpath('03_Support_Vector_Machines/'));
% Path to the classification dataset
classPath = '00_Datasets/classification';

% 0.1 - Import the classification dataset
dataStruct = importDataset(classPath, 'classification');
% 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = computeTransforms(dataStruct);
% 0.3 - Compute a set of temporal and spectral features
dataStruct = computeFeatures(dataStruct);
 
%%
% 3.1.1 - Computing the prediction of a random SVM

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 03_Support_Vector_Machines/svmPredict.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Loading and Visualizing training dataset.
fprintf('Loading and Visualizing Data ...\n')
% Loading dataset from example1.mat (X and y) are in the environment
load('example1.mat');
% Plot training data
whitebg(gcf,[1 1 1]);
plotData(X, y);
title('Traning Dataset');
% Creating a fake (random) model
model = struct;
model.X;            % Values of _suppert vectors_ in input data
model.y;            % Classes labels of _support vectors_
model.kernel;       % Type of kernel
model.b;            % Value of threshold
model.alphas;       % Value of alphas
model.w;            % Value of vectors
% Plot the result
figure;
whitebg(gcf,[1 1 1]);
% Visualize the boundary (this function calls svmPredict)
visualizeBoundaryLinear(X, y, model);
title('Decision Boundary');

%% 
% 3.1.2 - Training a SVM on a linear separation problem

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 03_Support_Vector_Machines/svmTrain.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Re-plot the training data
whitebg(gcf,[1 1 1]);
plotData(X, y);
title('Traning Dataset');
% Training Linear SVM 
fprintf('\nTraining Linear SVM ...\n')
% Parameters of the training
C = 1;                  % C regularization value
tolerance = 1e-3        % Tolerance value for thresholds
nbIterations = 20;      % Number of iterations
kernel = 'linear';      % Type of kernel
% Perform the training (try to fiddle the previous values to see effect).
model = svmTrain(X, y, C, kernel, tolerance, nbIterations);
% Plot the result
figure;
whitebg(gcf,[1 1 1]);
visualizeBoundaryLinear(X, y, model);
title('Decision Boundary');
 
%% 
% 3.2.1 - Training a SVM with Gaussian kernel on non-linear problem

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 
% - 03_Support_Vector_Machines/svmPredict.m
% - 03_Support_Vector_Machines/svmTrain.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Loading the non-linear dataset
fprintf('Loading and Visualizing Data ...\n')
load('example2.mat'); 
% Plot the data
figure,
whitebg(gcf,[1 1 1]);
plotData(X, y);
title('Traning Dataset');
% Parameters of the training
C = 1;                  % C regularization value
tolerance = 1e-3        % Tolerance value for thresholds
nbIterations = 20;      % Number of iterations
kernel = 'gaussian';    % Type of kernel
sigma = 0.1;            % Variance of Gaussian kernel
% Train the SVM with a Gaussian (RBF) kernel
model= svmTrain(X, y, C, 'gaussian', tolerance, nbIterations); 
% Plot the result
figure,
whitebg(gcf,[1 1 1]);
visualizeBoundary(X, y, model);
title('Decision boundary with RBF kernel');

%%
% 3.3.1 - Training a SVM with multiple kernels

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 
% - 03_Support_Vector_Machines/svmPredict.m
% - 03_Support_Vector_Machines/svmTrain.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Loading the non-linear dataset
fprintf('Loading and Visualizing Data ...\n')
load('example2.mat'); 
% Plot the data
figure,
whitebg(gcf,[1 1 1]);
plotData(X, y);
title('Traning Dataset');

% Polynomial kernel learning
C = 1;                  % C regularization value
tolerance = 1e-3        % Tolerance value for thresholds
nbIterations = 20;      % Number of iterations
kernel = 'polynomial';  % Type of kernel
sigma = 0.1;            % Variance of Gaussian kernel
% Train the SVM with a Gaussian (RBF) kernel
model= svmTrain(X, y, C, @(x1, x2) gaussianKernel(x1, x2, sigma)); 
% Plot the result
figure,
whitebg(gcf,[1 1 1]);
visualizeBoundary(X, y, model);
title('Decision boundary with polynomial kernel');

% Sigmoid kernel learning
C = 1;                  % C regularization value
tolerance = 1e-3        % Tolerance value for thresholds
nbIterations = 20;      % Number of iterations
kernel = 'sigmoid';     % Type of kernel
sigma = 0.1;            % Variance of Gaussian kernel
% Train the SVM with a Gaussian (RBF) kernel
model= svmTrain(X, y, C, @(x1, x2) gaussianKernel(x1, x2, sigma)); 
% Plot the result
figure,
whitebg(gcf,[1 1 1]);
visualizeBoundary(X, y, model);
title('Decision boundary with polynomial kernel');

%% 
% 3.4.1 - Multi-class audio application

% First we will construct the data features matrix
usedFeatures = {'SpectralCentroidMean', 'SpectralFlatnessMean', 'SpectralSkewnessMean'};
dataMatrix = zeros(length(dataStruct.filenames), length(usedFeatures));
for f = 1:length(usedFeatures)
    dataMatrix(:, f) = dataStruct.(usedFeatures{f});
end
dataMatrix(isnan(dataMatrix)) = 0;
patterns = dataMatrix ./ repmat(max(dataMatrix), size(dataMatrix, 1), 1);
% Construct a binary vector of outputs (class indicators)
desired = full(sparse(dataStruct.classes, 1:size(patterns, 1), 1))';
disp(size(desired));
nbTrain = size(desired, 1);
patterns = patterns';
desired = desired';
% Number of classes to evaluate
nbClasses = length(dataStruct.classNames);
for i = 1:length(nbClasses)
    
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
    % Define a binary classification problem for the current class
    % Define the parameters of the SVM
    % Train the SVM
    % Plot the results
    
end

%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES HERE
%%%%%%%%%%%%%%%%%%%%%%

% Evaluate the overall classification accuracy of your model
% Change the parameters of the training procedure and re-evaluate

