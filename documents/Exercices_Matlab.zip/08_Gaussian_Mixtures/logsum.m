%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Log-sum-exp for sumation in the log domain
% function y = logsum(x,d)
%
% Inputs: x - matrix or vector
%         d - dimension to sum over
% Output: y - logsum output
function y = logsum(x,d)
m = max(x,[],d);
y = log(sum(exp(bsxfun(@minus,x,m)),d)) + m;