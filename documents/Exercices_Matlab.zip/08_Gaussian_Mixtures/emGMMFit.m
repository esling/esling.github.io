function [M,C,P,i] = emGMMFit(X,k,Cv)
%% EM for GMMs
% [M,C,P,iters] = EM_GMM(X,k)
%
% Inputs: X - data (points x dims)
%         k - # of gaussians
% Outputs: M - cell array of means at each iteration
%          C - cell array of covars at each iteration
%          P - cell array of posteriors at each iteration
%          i - iterations to convergence

[N,d] = size(X);
A = zeros(N,k); % posteriors

% initialize
Cx = sqrtm(cov(X));
m = bsxfun(@plus,sum(X,1)/N,randn(k,d)*Cx);
w = ones(1,k)/k; % mixing weights
if Cv; Ca = repmat(Cx,[1,1,k]); % full cov
else   Ca = ones(k,d); % diagonal cov
end

% save params from each iteration
M = cell(1,50);
C = cell(1,50);
P = cell(1,50);

M{1} = m;
if Cv
  C{1} = Ca;
else
  C{1} = zeros(d,d,k);
  for j=1:k
    C{1}(:,:,j) = diag(Ca(j,:));
  end
end
P{1} = ones(N,k)/k;

% iterate
ll = -Inf;
for i=2:50
  ll_old = ll;
  
  % -- E step --
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
  
  % -- M step --
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
  
  % -- save means, covars, posteriors --
  M{i} = m;
  if Cv
    C{i} = Ca;
  else
    C{i} = zeros(d,d,k);
    for j=1:k
      C{i}(:,:,j) = diag(Ca(j,:));
    end
  end
  P{i} = p;
  
  % -- test convergence --
  ll = sum(As);
  if abs((ll-ll_old)/ll_old) < 10^-4
    break
  end
end