% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sample from Dirichlet distribution
% function X = dirrand(a,N)
%
% Inputs: a - parameters of Dirichlet distribution
%         N - number of samples
% Output: X - Nxd matrix of Dirichlet samples
function X = dirrand(a,N)
X = gamrnd(repmat(a,N,1),1);
X = bsxfun(@rdivide,X,sum(X,2));