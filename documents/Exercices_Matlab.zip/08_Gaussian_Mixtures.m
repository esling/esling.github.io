% ---------------
% ATIAM - Music machine learning tutorial
%
% Part 8 - Gaussian Mixtures
%
% <https://esling.github.io/ [...]>
% <esling@ircam.fr>
%

% Load all files in sub-directories
addpath(genpath('00_Datasets/'));
addpath(genpath('00_Features/'));
addpath(genpath('00_Introduction/'));
addpath(genpath('00_Preprocessing/'));
addpath(genpath('07_Bayesian_Inference/'));
addpath(genpath('08_Gaussian_Mixtures/'));
% Path to the classification dataset
classPath = '00_Datasets/classification';
% Import the classification set
dataStruct = importDataset(classPath, 'classification');

%%
% 8.1 - Generate data with known parameters

nbPatterns = 2000;
% Generate 200 random patterns for class 1
mu1 = 4.2; 
sigma1 = 1;
x1samples = random('Normal', mu1, sigma1, nbPatterns, 1);
% Generate 200 random patterns for class 2
mu2 = 6.8; 
sigma2 = 1;
x2samples = random('Normal', mu2, sigma2, nbPatterns, 1);
% Plot the corresponding data
nbBins = 50;
X1 = min(x1samples):.1:max(x1samples);
y1 = normpdf(X1, mu1, sigma1) * (nbPatterns / nbBins) * max(x1samples);
X2 = min(x2samples):.1:max(x2samples);
y2 = normpdf(X2, mu2, sigma2) * (nbPatterns / nbBins) * max(x1samples);
% Display both
figure; hold on
histogram(x1samples, nbBins);
histogram(x2samples, nbBins);
plot(X1,y1,'LineStyle','--','Color','r','LineWidth',2);
plot(X2,y2,'LineStyle','-.','Color','g','LineWidth',2);
legend({'Samples c.1', 'Samples c.2', 'PDF c.1', 'PDF c.2'});
hold off;
title('Training Dataset');
hold off;

%%
% 8.2 - Generate data with known parameters

% Create a mixed set of samples (to not know their origin)
fullSamples = [x1samples; x2samples]
nbSamples = size(fullSamples, 1);
fullSamples = fullSamples(randsample(nbSamples, nbSamples));

nbIterations = 20;
mu1guess = rand(1,1) * 100;
mu2guess = rand(1,1) * 100;
likelihoods = zeros(nbIterations, 1);
mus = zeros(nbIterations, 2);
h = figure;
for i = 1:nbIterations 
    
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES in 08_Gaussian_Mixtures/expectedValue.m
    %%%%%%%%%%%%%%%%%%%%%%
    % Expected value of Z-variable
	tau = expectedValue(fullSamples, mu1guess, mu2guess);
    
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
    % Save incomplete likelihood value (should be monotone)
    % Compute new MLE estimates of mus
    % Save the current guessed values;
    mus(i, 1) = mu1guess;
    mus(i, 2) = mu2guess;
    % Plot the corresponding guesses
    nbBins = 50;
    Xs = min(fullSamples):.1:max(fullSamples);
    y1guess = normpdf(Xs, mu1, 1) * (nbPatterns / nbBins) * max(x1samples);
    y2guess = normpdf(Xs, mu2, 1) * (nbPatterns / nbBins) * max(x2samples);
    % Display both 
    plot(Xs,y1guess,'LineStyle','--','Color','r','LineWidth',2); 
    hold on;
    plot(Xs,y2guess,'LineStyle','-.','Color','g','LineWidth',2);
    plot(X1,y1 .* 0.9,'LineStyle','--','Color','k','LineWidth',2);
    plot(X2,y2 .* 0.9,'LineStyle','-.','Color','k','LineWidth',2);
    legend({'Samples c.1', 'Samples c.2', 'PDF c.1', 'PDF c.2'});
    hold off;
    title('Training Dataset');
    pause(0.5);
end

%%
% 8.3 - 3-dimensionnal GMM

emGMM3D();

%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES in 08_Gaussian_Mixtures/emGMMFit.m
%%%%%%%%%%%%%%%%%%%%%%

