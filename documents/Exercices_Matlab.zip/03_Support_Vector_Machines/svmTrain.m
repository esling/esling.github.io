function [model] = svmTrain(X, Y, C, kernel, tol, maxIter)
%SVMTRAIN Trains an SVM classifier using a simplified version of the SMO 
% X       : m x n matrix of m training examples (with n-dimensional features).
% Y       : column vector of class identifiers
% C       : standard SVM regularization parameter
% tol     : tolerance value used for determining equality of floating point numbers. 
% maxIter : number of iterations over the dataset before the algorithm stops.

if ~exist('tol', 'var') || isempty(tol)
    tol = 1e-3;
end

if ~exist('max_passes', 'var') || isempty(maxIter)
    maxIter = 5;
end

% Data parameters
m = size(X, 1);
n = size(X, 2);

% Map 0 to -1
Y(Y==0) = -1;

% Variables
alphas = zeros(m, 1);
b = 0;
E = zeros(m, 1);
passes = 0;
eta = 0;
L = 0;
H = 0;

% Pre-compute the Kernel Matrix since our dataset is small
% (in practice, optimized SVM packages that handle large datasets
%  gracefully will _not_ do this)
% 
if strcmp(kernel, 'linear')
    %%%%%%%%%%%%%%%%%%%%%%
    % Code for the linear kernel
    %%%%%%%%%%%%%%%%%%%%%%
elseif strcmp(kernel, 'gaussian')
    %%%%%%%%%%%%%%%%%%%%%%
    % Code for the gaussian kernel
    %%%%%%%%%%%%%%%%%%%%%%
elseif strcmp(kernel, 'polynomial')
    %%%%%%%%%%%%%%%%%%%%%%
    % Code for the polynomial kernel
    %%%%%%%%%%%%%%%%%%%%%%
elseif strcmp(kernel, 'sigmoid')
    %%%%%%%%%%%%%%%%%%%%%%
    % Code for the sigmoid kernel
    %%%%%%%%%%%%%%%%%%%%%%
else
    %%%%%%%%%%%%%%%%%%%%%%
    % Code for eventual other kernels
    %%%%%%%%%%%%%%%%%%%%%%
end
% Train
fprintf('\nTraining ...');
while passes < maxIter,
    % Check that some alphas changed
    num_changed_alphas = 0;
    % Iterative over all alpha_i
    for i = 1:m,
            
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    % => Perform one pass of the SMO algorithm for each alpha_i
    %%%%%%%%%%%%%%%%%%%%%%
    
    end
    if (num_changed_alphas == 0), passes = passes + 1; else passes = 0; end
end
fprintf(' Done! \n\n');
% Save the model
idx = alphas > 0;
model.X= X(idx,:);
model.y= Y(idx);
model.kernel = kernel;
model.b= b;
model.alphas= alphas(idx);
model.w = ((alphas.*Y)'*X)';
end
