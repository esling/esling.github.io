%
% function [probas, winnerClass] = knnClassify(dataStruct, testSample, k, normalize, useL1dist);
% 
% This function is used for classifying an uknown sample using the kNN
% algorithm, in its multi-class form.
%
% Arguments :
% - dataStruct  : the data structure
% - testSample  : the input sample id to be classified
% - k           : the k (number of neighbors) parameter
% - distType    : type of distance ['Euclidean', 'Manhattan', 'Cosine'] (optional)
% - normalize   : use class priors to weight results (optional)
%
% Returns :
% - probas      : an array that contains the classification probabilities for each class
% - winnerClass : the label of the winner class
%
function [probas, winnerClass] = knnClassify(dataStruct, testSample, usedFeatures, k, distType, normalize)
% Put default values to arguments
if (nargin < 4), k = 1; end
if (nargin < 5), distType = 'Euclidean'; end
if (nargin < 6), normalize = 0; end
% Keep the number of classes
numOfClasses = length(dataStruct.classNames);
% Initialization of class properties
numOfDims = zeros(1, numOfClasses);
numOfTrainSamples = zeros(1, numOfClasses);
classFeats = cell(1, numOfClasses);
% Create a data matrix with the features of all data
dataMatrix = zeros(length(dataStruct.filenames), length(usedFeatures));
for f = 1:length(usedFeatures)
    dataMatrix(:, f) = dataStruct.(usedFeatures{f});
end
dataMatrix(isnan(dataMatrix)) = 0;
dataMatrix = dataMatrix ./ repmat(max(dataMatrix), size(dataMatrix, 1), 1);
% Retrieve the features of the test samples
testFeatures = dataMatrix(testSample, :);
% dist{i} will the vector of distance of the testing sample to all the samples of i-th class
dist = cell(numOfClasses,1);
% We create a vector of "inf" distances for each class and a cell of features
for i = 1:numOfClasses
    % Retrieve the class points
    curPoints = find(dataStruct.classes == i);
    % Eventually remove the current sample
    curPoints(curPoints == testSample) = [];
    numOfTrainSamples(i) = length(curPoints);
    numOfDims(i) = length(usedFeatures);
    % Fill the dist cell with "inf" values
    dist{i} = inf * ones(max(numOfTrainSamples), 1);
    % Keep the cell of class features
    classFeats{i} = dataMatrix(curPoints, :);
    classFeats{i}(isnan(classFeats{i})) = 0.0;
end
% Compute the distance vectors for each class
for i = 1:numOfClasses
    
    %%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    % Q 1.2.1
    % Q 1.2.4 (switch distType)
    %%%%%%%%%%%%%%%%%
    
end
kAll = zeros(numOfClasses, 1);
% Compute the mean distance value for k neighbors
for j = 1:k
    
    %%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    % Q 1.2.1
    %%%%%%%%%%%%%%%%%
    
end
% Normalize the class probabilities

    %%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    % Q 1.2.6
    %%%%%%%%%%%%%%%%%
    
% Retrieve the winning class

    %%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    % Q 1.2.1
    %%%%%%%%%%%%%%%%%
