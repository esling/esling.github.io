function plotClassifier(t, dim, sign, patterns, labels, h)
if (nargin < 6), h = 1; end
if (h) figure; end
whitebg(gcf,[1 1 1])
hold on;
scatter(patterns(labels == -1, 1), patterns(labels == -1, 2), 10, 'r');
scatter(patterns(labels == 1, 1), patterns(labels == 1, 2), 10, 'g');
errSum = weakClassifierError(t, dim, sign, patterns, labels);
% Plot the classifier and corresponding errors
if (dim == 1)
    line([t, t], [min(patterns(:, 2)), max(patterns(:, 2))], 'LineStyle', '--', 'LineWidth', 2, 'Color', 'b');
else
    line([min(patterns(:, 1)), max(patterns(:, 1))], [t, t], 'LineStyle', '--', 'LineWidth', 2, 'Color', 'b');
end
title(sprintf('Errors : %d', errSum)); 
if (h), hold off; end
end

