function plotBoosting(classifiers, patterns, labels, it, weights, alpha)
figure;hold on;
whitebg(gcf,[1 1 1]);
scatter(patterns(labels == -1, 1), patterns(labels == -1, 2), 10, 'r');
scatter(patterns(labels == 1, 1), patterns(labels == 1, 2), 10, 'g');
tempSum = zeros(size(labels, 1), 1);
for i = 1:it
    [errSum, errors] = weakClassifierError(classifiers(i, 1), classifiers(i, 2), classifiers(i, 3), patterns, labels, weights);
    % Plot the classifier and corresponding errors
    if (classifiers(i, 2) == 1)
        line([classifiers(i, 1), classifiers(i, 1)], [min(patterns(:, 2)), max(patterns(:, 2))], 'LineStyle', '--', 'LineWidth', 2, 'Color', 'b');
    else
        line([min(patterns(:, 1)), max(patterns(:, 1))], [classifiers(i, 1), classifiers(i, 1)], 'LineStyle', '--', 'LineWidth', 2, 'Color', 'b');
    end
    %scatter(patterns((errors == 1), 1), patterns((errors == 1), 2), 10 + (2 * i), 'k');
    th = classifiers(i, 1); 
    dim = classifiers(i, 2); 
	sig = classifiers(i, 3);
	if (sig == 1), temp = double(patterns(:, dim) >= th); else temp = double(patterns(:, dim) < th); end
	temp(temp == 0) = -1;
	tempSum = (tempSum + alpha(i) * temp);
	final_label = double(tempSum > 0);
    final_label(final_label == 0) = -1;
    misses = sum(double(final_label ~= labels)) / size(patterns, 1);
end
disp([labels final_label]);
scatter(patterns(final_label ~= labels, 1), patterns(final_label ~= labels, 2), 20, 'k');%, 'LineWidth', 3);
%for i = 1:size(patterns, 1)
%    text(patterns(i, 1), patterns(i, 2), sprintf('%d / %f / %f', final_label(i), tempSum(i), weights(i)));
%end
title(sprintf('Errors : %d', misses)); 
hold off;
end

