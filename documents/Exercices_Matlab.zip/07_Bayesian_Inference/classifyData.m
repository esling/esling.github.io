function [maxVal, maxId] = classifyData(x_vec, g, mu_vecs, cov_mats)
%    Classifies an input sample into 1 out of 3 classes determined by
%    maximizing the discriminant function g_i().
    
%    Keyword arguments:
%        x_vec: A dx1 dimensional numpy array representing the sample.
%        g: The discriminant function.
%        mu_vecs: A list of mean vectors as input for g.
%        cov_mats: A list of covariance matrices as input for g.
%    
%    Returns the max probability and class id.

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
end

