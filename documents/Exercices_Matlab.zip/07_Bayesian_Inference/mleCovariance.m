function covEst = mleCovariance(xSamples, muEst)

%    Calculates the Maximum Likelihood Estimate for the covariance matrix.
%    
%    Keyword Arguments:
%        x_samples: np.array of the samples for 1 class, n x d dimensional 
%        mu_est: np.array of the mean MLE, d x 1 dimensional
%        
%    Returns the MLE for the covariance matrix as d x d numpy array.
    
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
end

