  function samples = sampleExponential(mu, n, m)

end

