function [ product ] = infer(network, margVars, obsVars, obsVals)
%
%    This function performs inference on a bayesian network
%    
%    Args:
%        network    : Original network onto which perform inference
%        marg_vars  : Marginalized variables
%        obs_vars   : Observed variables
%        obs_vals   : Observed values
%    
%    Returns:
%        :returns: The new network
%
    
end

