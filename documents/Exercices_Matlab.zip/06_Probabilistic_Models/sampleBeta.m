function samples = sampleBeta(a, b, M, N)



end

