% ---------------
% ATIAM - Music machine learning tutorial
%
% Part 10 - Data Complexity
%
% <https://esling.github.io/ [...]>
% <esling@ircam.fr>
%

% Load all files in sub-directories
addpath(genpath('00_Datasets/'));
addpath(genpath('00_Features/'));
addpath(genpath('00_Introduction/'));
addpath(genpath('00_Preprocessing/'));
addpath(genpath('10_Data_Complexity/'));
% Path to the classification dataset
classPath = '00_Datasets/classification';
% Import the classification dataset
dataStruct = importDataset(classPath, 'classification');

%%
% 10.0 - Generate two overlapping distributions
dataStruct = importDataset(classPath, 'classification');

nbPatterns = 400;
% Generate random patterns for class 1
mu1 = [0,0]; 
cov1 = [42,30;30,42];
x1samples = mvnrnd(mu1,cov1,nbPatterns);
% Generate random patterns for class 2
mu2 = [16,16]; 
cov2 = [21,14;14,21];
x2samples = mvnrnd(mu2,cov2,nbPatterns);
% Prepare concatenated versions of class properties
muVals = {}; muVals{1} = mu1; muVals{2} = mu2;
covVals = {}; covVals{1} = cov1; covVals{2} = cov2;
% Plot the corresponding data
figure; hold on;
scatter(x1samples(:,1), x1samples(:,2), 40, 'g', 'Marker', 'o', 'MarkerFaceColor', [0 0.8 0], 'MarkerEdgeColor', [0 0.4 0]);
scatter(x2samples(:,1), x2samples(:,2), 40, 'b', 'Marker', 's', 'MarkerFaceColor', [0 0 0.8], 'MarkerEdgeColor', [0 0 0.4]);
h = plotGaussianEllipsoid(mu1, cov1, 2); set(h, 'Color', [0.2 0.2 0.2], 'LineWidth', 3, 'LineStyle', '--');
h = plotGaussianEllipsoid(mu2, cov2, 2); set(h, 'Color', [0.2 0.2 0.2], 'LineWidth', 3, 'LineStyle', '--');
title('Training Dataset');
ylabel('x_2');
xlabel('x_1');
hold off;

% Mix all samples together
x = [x1samples ; x2samples];

%%
% 10.1 - Compute the PCA for the Gaussian distribution

% Performing a zero-mean transform
avg = mean(x, 1);
x = x - repmat(avg, size(x, 1), 1);

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

figure; hold on;
scatter(xZCAwhite(1:nbPatterns,1), xZCAwhite(1:nbPatterns,2), 40, 'g', 'Marker', 'o', 'MarkerFaceColor', [0 0.8 0], 'MarkerEdgeColor', [0 0.4 0]);
scatter(xZCAwhite((nbPatterns+1):end,1), xZCAwhite((nbPatterns+1):end,2), 40, 'b', 'Marker', 's', 'MarkerFaceColor', [0 0 0.8], 'MarkerEdgeColor', [0 0 0.4]);
title('PCA transformed data');
ylabel('x_2');
xlabel('x_1');
hold off;

%%
% 10.2 - Cross-validation

holdoutTrain = [];
holdoutValid = [];
validationPercent = .1;
nbExamples = length(dataStruct.classes);
% Holdout method

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
% Stratification method
stratificationTrain = [];
stratificationValid = [];

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

% Count the class instances for each approach
classBalance = zeros(4, length(dataStruct.classNames));
for i = 1:length(dataStruct.classNames)
    classBalance(1, i) = sum(dataStruct.classes(holdoutTrain) == i);
    classBalance(2, i) = sum(dataStruct.classes(holdoutValid) == i);
    classBalance(3, i) = sum(dataStruct.classes(stratificationTrain) == i);
    classBalance(4, i) = sum(dataStruct.classes(stratificationValid) == i);
end
% Normalize the counts (for better readability)
for i = 1:4, classBalance(i, :) = classBalance(i, :) ./ sum(classBalance(i, :)); end
% Plot the class balance between different validation approaches
bar(classBalance,'stacked');
title(['Class balance - ' num2str(validationPercent * 100) '% ']);
set(gca, 'XTickLabel', {'Hold_{train}', 'Hold_{valid}', 'Strat_{train}', 'Strat_{valid}'}); 

% Re-implement a previous classification algorithm

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

% Evaluate variance, bias and optimism bias
    
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

%%
% 10.3 - Model selection

nEvaluations = 100;

% Grid search

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

% Keep track of besties
bestErrSum = 1;
bestErrs = [];
bestS = -1; bestD = -1; bestT = -1; 

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
% Random search
bestErrSum = nInputs + 1;
bestErrs = [];
bestS = -1; bestD = -1; bestT = -1; 
 
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
   

% Candidate pool

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

classifierPool = {}; 
curClassifier = 1;

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    

%%
% 10.4 - Cross-validation

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
