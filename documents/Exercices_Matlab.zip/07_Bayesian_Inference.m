% ---------------
% ATIAM - Music machine learning tutorial
%
% Part 7 - Bayesian inference
%
% <https://esling.github.io/ [...]>
% <esling@ircam.fr>
%

% Load all files in sub-directories
addpath(genpath('00_Datasets/'));
addpath(genpath('00_Features/'));
addpath(genpath('00_Introduction/'));
addpath(genpath('00_Preprocessing/'));
addpath(genpath('07_Bayesian_Inference/'));
% Path to the classification dataset
classPath = '00_Datasets/classification';
% Import the classification set
dataStruct = importDataset(classPath, 'classification');

%%
% 7.0 - Generate data with known parameters

nbPatterns = 100;
% Generate random patterns for class 1
mu1 = [0,0]; 
cov1 = [3,0;0,3];
% Generate random patterns for class 2
mu2 = [9,0]; 
cov2 = [3,0;0,3];
% Generate random patterns for class 3
mu3 = [6,6]; 
cov3 = [4,0;0,4];

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

% Prepare concatenated versions of class properties
muVals = {}; muVals{1} = mu1; muVals{2} = mu2; muVals{3} = mu3;
covVals = {}; covVals{1} = cov1; covVals{2} = cov2; covVals{3} = cov3;
% Plot the corresponding data
figure; hold on;
scatter(x1samples(:,1), x1samples(:,2), 40, 'g', 'Marker', 'o', 'MarkerFaceColor', [0 0.8 0], 'MarkerEdgeColor', [0 0.4 0]);
scatter(x2samples(:,1), x2samples(:,2), 40, 'b', 'Marker', 's', 'MarkerFaceColor', [0 0 0.8], 'MarkerEdgeColor', [0 0 0.4]);
scatter(x3samples(:,1), x3samples(:,2), 40, 'r', 'Marker', '^', 'MarkerFaceColor', [0.8 0 0], 'MarkerEdgeColor', [0.4 0 0]);
h = plotGaussianEllipsoid(mu1, cov1, 2); set(h, 'Color', [0.2 0.2 0.2], 'LineWidth', 3, 'LineStyle', '--');
h = plotGaussianEllipsoid(mu2, cov2, 2); set(h, 'Color', [0.2 0.2 0.2], 'LineWidth', 3, 'LineStyle', '--');
h = plotGaussianEllipsoid(mu3, cov3, 2); set(h, 'Color', [0.2 0.2 0.2], 'LineWidth', 3, 'LineStyle', '--');
title('Training Dataset');
ylabel('x_2');
xlabel('x_1');
hold off;
    
%%
% 7.1 - Discriminant function and classification

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 
% - 07_Bayesian_Inference/discriminantFunction.m
% - 07_Bayesian_Inference/classifyData.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x1classes = zeros(nbPatterns, 1);
confMatrix = zeros(3, 3);
for i = 1:nbPatterns
    [~, g] = classifyData(x1samples(i, :), @discriminantFunction, muVals, covVals);
    x1classes(i) = g;
    confMatrix(1, g) = confMatrix(1, g) + 1;
end
x2classes = zeros(nbPatterns, 1);
for i = 1:nbPatterns
    [~, g] = classifyData(x2samples(i, :), @discriminantFunction, muVals, covVals);
    x2classes(i) = g;
    confMatrix(2, g) = confMatrix(2, g) + 1;
end
x3classes = zeros(nbPatterns, 1);
for i = 1:nbPatterns
    [~, g] = classifyData(x3samples(i, :), @discriminantFunction, muVals, covVals);
    x3classes(i) = g;
    confMatrix(3, g) = confMatrix(3, g) + 1;
end

fprintf('%16s \t %s \t %s \t %s\n', ' ', 'class 1', 'class 2', 'class 3');
fprintf('%16s \t %f \t %f \t %f\n', 'class 1', confMatrix(1, 1), confMatrix(1, 2), confMatrix(1, 3));
fprintf('%16s \t %f \t %f \t %f\n', 'class 1', confMatrix(2, 1), confMatrix(2, 2), confMatrix(2, 3));
fprintf('%16s \t %f \t %f \t %f\n', 'class 1', confMatrix(3, 1), confMatrix(3, 2), confMatrix(3, 3));
 
%%
% 7.2 - Compute estimators


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES HERE (Perform mu estimates)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% muEst1 = ?
% muEst2 = ?
% muEst3 = ?

fprintf('%16s \t %s \t %s \t %s \t %s \t %s \t %s\n', '', 'mu1_1   ', 'mu1_2  ', 'mu2_1  ', 'mu2_2  ', 'mu3_1  ', 'mu3_2  ');
fprintf('%16s \t %f \t %f \t %f \t %f \t %f \t %f\n', 'MLE', muEst1(1), muEst1(2), muEst2(1), muEst2(2), muEst3(1), muEst3(2));
fprintf('%16s \t %f \t %f \t %f \t %f \t %f \t %f\n', 'Truth', mu1(1), mu1(2), mu2(1), mu2(2), mu3(1), mu3(2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 07_Bayesian_Inference/mleCovariance.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

covEst1 = mleCovariance(x1samples, muEst1);
covEst2 = mleCovariance(x2samples, muEst2);
covEst3 = mleCovariance(x3samples, muEst3);

fprintf('%16s \t %s \t %s \t %s \t %s \t %s \t %s\n', '', 'cov1_1   ', 'cov1_2  ', 'cov2_1  ', 'cov2_2  ', 'cov3_1  ', 'cov3_2  ');
fprintf('%16s \t %f \t %f \t %f \t %f \t %f \t %f\n', 'MLE', covEst1(1), covEst1(2), covEst2(1), covEst2(2), covEst3(1), covEst3(2));
fprintf('%16s \t %f \t %f \t %f \t %f \t %f \t %f\n', 'Truth', cov1(1), cov1(2), cov2(1), cov2(2), cov3(1), cov3(2));

muEstimates = {}; muEstimates{1} = muEst1; muEstimates{2} = muEst2 ; muEstimates{3} = muEst3;
covEstimates = {}; covEstimates{1} = covEst1; covEstimates{2} = covEst2; covEstimates{3} = covEst3;

% Plot the corresponding data
figure; hold on;
scatter(x1samples(:,1), x1samples(:,2), 40, 'g', 'Marker', 'o', 'MarkerFaceColor', [0 0.8 0], 'MarkerEdgeColor', [0 0.4 0]);
scatter(x2samples(:,1), x2samples(:,2), 40, 'b', 'Marker', 's', 'MarkerFaceColor', [0 0 0.8], 'MarkerEdgeColor', [0 0 0.4]);
scatter(x3samples(:,1), x3samples(:,2), 40, 'r', 'Marker', '^', 'MarkerFaceColor', [0.8 0 0], 'MarkerEdgeColor', [0.4 0 0]);
h = plotGaussianEllipsoid(mu1, cov1, 2); set(h, 'Color', [0.2 0.2 0.2], 'LineWidth', 3, 'LineStyle', '--');
h = plotGaussianEllipsoid(mu2, cov2, 2); set(h, 'Color', [0.2 0.2 0.2], 'LineWidth', 3, 'LineStyle', '--');
h = plotGaussianEllipsoid(mu3, cov3, 2); set(h, 'Color', [0.2 0.2 0.2], 'LineWidth', 3, 'LineStyle', '--');
h = plotGaussianEllipsoid(muEst1, covEst1, 2); set(h, 'Color', [1.0 0.8 0.1], 'LineWidth', 3, 'LineStyle', '-.');
h = plotGaussianEllipsoid(muEst2, covEst2, 2); set(h, 'Color', [1.0 0.8 0.1], 'LineWidth', 3, 'LineStyle', '-.');
h = plotGaussianEllipsoid(muEst3, covEst3, 2); set(h, 'Color', [1.0 0.8 0.1], 'LineWidth', 3, 'LineStyle', '-.');
title('Comparing estimated MLE Gaussians');
hold off;

%%
% 7.2 - Classify based on estimated values

x1classes = zeros(nbPatterns, 1);
confMatrix = zeros(3, 3);
for i = 1:nbPatterns
    [~, g] = classifyData(x1samples(i, :), @discriminantFunction, muEstimates, covEstimates);
    x1classes(i) = g;
    confMatrix(1, g) = confMatrix(1, g) + 1;
end
x2classes = zeros(nbPatterns, 1);
for i = 1:nbPatterns
    [~, g] = classifyData(x2samples(i, :), @discriminantFunction, muEstimates, covEstimates);
    x2classes(i) = g;
    confMatrix(2, g) = confMatrix(2, g) + 1;
end
x3classes = zeros(nbPatterns, 1);
for i = 1:nbPatterns
    [~, g] = classifyData(x3samples(i, :), @discriminantFunction, muEstimates, covEstimates);
    x3classes(i) = g;
    confMatrix(3, g) = confMatrix(3, g) + 1;
end

fprintf('%16s \t %s \t %s \t %s\n', ' ', 'class 1', 'class 2', 'class 3');
fprintf('%16s \t %f \t %f \t %f\n', 'class 1', confMatrix(1, 1), confMatrix(1, 2), confMatrix(1, 3));
fprintf('%16s \t %f \t %f \t %f\n', 'class 1', confMatrix(2, 1), confMatrix(2, 2), confMatrix(2, 3));
fprintf('%16s \t %f \t %f \t %f\n', 'class 1', confMatrix(3, 1), confMatrix(3, 2), confMatrix(3, 3));

%%
% 7.5 - Audio source separation

