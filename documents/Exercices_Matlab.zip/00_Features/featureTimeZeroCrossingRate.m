% ======================================================================
%> @brief computes the zero crossing rate from a time domain signal
%> called by ::ComputeFeature
%>
%> @param x: audio signal
%> @param iBlockLength: block length in samples
%> @param iHopLength: hop length in samples
%> @param f_s: sample rate of audio data (unused)
%>
%> @retval vzc zero crossing rate
%> @retval t time stamp
% ======================================================================
function [vzc] = featureTimeZeroCrossingRate(x)
    % allocate memory
    vzc1             = zeros(1,size(x,1));
    i=0;
    for (n = 1:size(x,1))
        i=i+1;
        % compute the zero crossing rate
        vzc1(n)      = 0.5*mean(abs(diff(sign(x(i,:)))));
    end
    vrms =  Featuretimerootmeansquare(x);
    vzc2=vzc1.*vrms;
    vzc=sum(vzc2)./sum(vrms);
end
function [vrms] = Featuretimerootmeansquare(x)
    % allocate memory
    vrms            = zeros(1,size(x,1));
    i=0;
    for (n = 1:size(x,1))
        i=i+1;
        % calculate the rms
        vrms(n)     = sqrt(mean(x(i,:).^2));
    end
end