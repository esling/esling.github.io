% ======================================================================
%> @brief computes the RMS of a time domain signal
%> called by ::ComputeFeature
%>
%> @param x: audio signal
%> @param iBlockLength: block length in samples
%> @param iHopLength: hop length in samples
%> @param f_s: sample rate of audio data (unused)
%>
%> @retval vrms root mean square
%> @retval t time stamp
% ======================================================================
function [f] = featureTimeRms(x)

    % allocate memory
    vrms            = zeros(1,size(x,1));
    i=0;
    for (n = 1:size(x,1))
        i=i+1;
        % calculate the rms
        vrms(n)     = sqrt(mean(x(i,:).^2));
    end
 
    % convert to dB
    epsilon         = 1e-5; %-100dB
    
    vrms(vrms < epsilon)    = epsilon;
    vrms                    = 20*log10(vrms);
    vrms1 =  Featuretimerootmeansquare(x);
   f2=vrms.*vrms1;
   
   f=sum(f2)./sum(vrms1);
end
function [vrms] = Featuretimerootmeansquare(x)
    % allocate memory
    vrms            = zeros(1,size(x,1));
    i=0;
    for (n = 1:size(x,1))
        i=i+1;
       % calculate the rms
        vrms(n)     = sqrt(mean(x(i,:).^2));
    end
end