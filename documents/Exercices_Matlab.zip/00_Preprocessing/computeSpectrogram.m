function A=computeSpectrogram(a, sr, fig)

%% compute spectrogram
fftlen = 2048;
fftwin=fftlen/2;
ffthop = fftlen/4;
A = specgram(a,fftlen,sr,fftwin,(fftwin-ffthop));

figure(fig);
imagesc(abs(A));
axis('xy')
title('Spectrogram');
xlabel('Time (frames)');
ylabel('Frequency (bins)');
colorbar;