

% get the number of free parameters
[data, parameterNames, parameterSizes] = singerSimilarity();
nbParameters = length(parameterNames);

%parameterSizes(2:end)=[-1 0 -1 -1];

parameterSizes(1:end-2)=[-2 -1 -1 -1 -1 -1 -1];
% parameterSizes(1:end-2)=[-5 0 0 0 0 0 0];

variants = getVariants(parameterSizes);

fprintf('Running: \n    ')
for k=1:size(variants, 2)
    r(k) = singerSimilarity(variants(:, k), 0, data);
    fprintf('\b\b\b%3d', ceil(k/size(variants, 2)*100));
 end
fprintf('\nDone! \n')

[v i] = sort(r);

for k=1:size(variants, 2)
for l=1:length(parameterNames)
    fprintf('%s=%d, ', parameterNames{l}, variants(l, i(k)));
end
fprintf('Ranking precision: %1.4f\n', v(k));
end