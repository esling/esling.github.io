function [r] =rankEval(M)
% [r] =rankEval(M) compute the 3-precision metric given a distance matrix M
%
%   Mathieu Lagrange lagrange at ircam dot fr

%ground truth
gt = repmat(1:10, 4, 1); gt =gt(:);

% number of neigbors to consider
nb=3;

% get the indexes of the elements sorting by increasing distance
[~, I] = sort(M);

% count the number of neigbors that have the gt label as the request
pos = gt(I(2:nb+1, :))==repmat(gt, 1, nb)';

% normalize to get a measure between 0 and 1
r = sum(pos(:))/(size(pos, 1)*size(pos, 2));
