function d = computeSpec(dataPath, fSize, wSize, hSize)
%   computeSpec iterates over the singer Dataset and computes corresponding
%   spectral representations
%
%   Mathieu Lagrange lagrange at ircam dot fr

if nargin<1, dataPath = '../singerDb/'; end
if nargin<2, fSize = 512; end
if nargin<3, wSize = fSize; end
if nargin<4, hSize = ceil(fSize/4); end

files=dir(dataPath);

j=1;
for k=1:length(files)
    if files(k).name(end) == 'v' % select only wav files
        [a, afs] = wavread([dataPath files(k).name]);
        [dataPath files(k).name]
        % spectrum
        % pspectrum = powspec(a, afs, .25);
        psc = stft(a, fSize, wSize, hSize, afs);
        pspectrum = abs(psc);
        
        if files(k).name(end-4) == 'c' % music case
            d(j).name = files(k).name;
            d(j).fs = afs;
            d(j).specM = pspectrum;
        else % voice case
            d(j).specV = pspectrum;          
            j=j+1;
        end
    end
end