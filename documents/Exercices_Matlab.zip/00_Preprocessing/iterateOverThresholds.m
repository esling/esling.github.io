

% get the number of free parameters
[data, parameterNames, parameterSizes] = singerSimilarity();
nbParameters = length(parameterNames);

% setting variants
parameterSizes(2:end)=[-1 0 -1 -1];

parameterSizes=[-2 -1 0 -1 -1];

variants = getVariants(parameterSizes);

nbTh=100;
grid = (0:1/nbTh:1);

fprintf('Running: \n    ')
for k=1:size(variants, 2)
    for l=1:length(grid)
        r(k, l) = singerSimilarity(variants(:, k), grid(l), data);
   fprintf('\b\b\b%3d', ceil(l/length(grid)*100));
     end
    fprintf('\b\b\b%3d', ceil(k/size(variants, 2)*100));
    
end
fprintf('\nDone! \n')

plot(grid, r')
legend(num2str((1:10)'))
