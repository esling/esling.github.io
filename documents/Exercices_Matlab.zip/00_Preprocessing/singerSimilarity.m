function [r, parameterNames, parameterSizes] = singerSimilarity(variant, th, data)
%   [r, parameterNames, parameterSizes] = singerSimilarity(variant, th, data)
%   attempt to find songs performed by the same singer.
%   With no input, the function computes and outputs the spectral
%   representation, the names of the different parameters as well as their
%   cardinality.
%   If a variant is given as input, this variant is evaluated over the
%   dataset data. the input parameter th is considered only in the case of
%   separation. r is then the ranking performance of the variant.
%
%   Mathieu Lagrange lagrange at ircam dot fr

rootPath = '~/data/teaching/atiam10/';
parameterNames = {'observation', 'mel', 'decibel', 'dct', 'dynamic', 'delta', 'variance', 'normalized'};
parameterSizes = [2, 2, 2, 2, 2, 2, 2, 2];

if nargin<1, r = computeSpec([rootPath 'singerDb/']); return; end

%% compute features
for k=1:length(data) % for each entry
       
    f(k, :)=fk;
end


%% compute distances
p = myDist(f);

%% rank evaluation
r = rankEval(p);




