function v = getVariants(nb)
%   getVariants(nb) outputs an enumeration of the different variants that
%   needs to be evaluated. nb is a vector of integers, where each
%   positive integer is the number of variants to be tested and each zero
%   or negative integer is the variant to be tested.
%   For example, getVariants([3 -1 0 2]) returns
%
%      0     0     1     1     2     2
%      1     1     1     1     1     1
%      0     0     0     0     0     0
%      0     1     0     1     0     1
%
%   Mathieu Lagrange lagrange at ircam dot fr


if nargin<1, nb=[3 -1 0 2]; end

if length(nb)>1
    pv = getVariants(nb(2:end));
    v=[];
    if nb(1)>1
        it = 0:nb(1)-1;
    else
        it = -nb(1);
    end
    for k=it
        v = [v [k*ones(1, size(pv, 2)); pv]];
    end
else
    if nb>1
        v= 0:nb-1;
    else
        v = -nb;
    end
end