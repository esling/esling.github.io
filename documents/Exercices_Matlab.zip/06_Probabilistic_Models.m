% ---------------
% ATIAM - Music machine learning tutorial
%
% Part 6 - Probabilistic models
%
% <https://esling.github.io/ [...]>
% <esling@ircam.fr>
%

% Load all files in sub-directories
addpath(genpath('00_Datasets/'));
addpath(genpath('00_Features/'));
addpath(genpath('00_Introduction/'));
addpath(genpath('00_Preprocessing/'));
addpath(genpath('06_Probabilistic_Models/'));
% Path to the classification dataset
classPath = '00_Datasets/classification';

%%
% 1.1 - Import the classification dataset
dataStruct = importDataset(classPath, 'classification');

%%
% 6.1 - Sampling from different distributions

nbSamples = 500;
nbBins = 50;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 06_Probabilistic_Models/sampleExponential.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Exponential distribution
mu = .5;
samples = random('Exponential', mu, nbSamples, 1);
samplesEx = sampleExponential(mu, nbSamples, 1);
% Compute the PDF
X = 0:.01:max(samples);
y1 = exppdf(X,mu) * (nbSamples / nbBins) * max(samples);
% Display both
figure; 
subplot(2,1,1);
hold on
histogram(samples, 50);
plot(X,y1,'LineStyle','--','Color','r','LineWidth',2)
legend({'Samples', 'Exponential PDF'},'Location','NorthEast');
hold off;
subplot(2,1,2);
hold on
histogram(samplesEx, 50);
plot(X,y1,'LineStyle','--','Color','r','LineWidth',2)
legend({'Samples', 'Exponential PDF'},'Location','NorthEast');
hold off;

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 06_Probabilistic_Models/sampleBeta.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Beta distribution
a = 0.6;
b = 1.5;
samples = random('Beta', a, b, nbSamples, 1);
samplesBeta = sampleBeta(a, b, nbSamples, 1);
% Compute the PDF
X = 0:.01:1;
y1 = betapdf(X,a,b) * (nbSamples / nbBins) * max(samples);
% Display both
figure; 
subplot(2,1,1);
hold on
histogram(samples, 50);
plot(X,y1,'LineStyle','--','Color','r','LineWidth',2)
legend({'Samples', 'Beta PDF'},'Location','NorthEast');
hold off;
subplot(2,1,2);
hold on
histogram(samplesBeta, 50);
plot(X,y1,'LineStyle','--','Color','r','LineWidth',2)
legend({'Samples', 'Beta PDF'},'Location','NorthEast');
hold off;

%%
% 6.2 - Bayesian network

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE GOES IN 
% - 06_Probabilistic_Models/factorProduct.m
% - 06_Probabilistic_Models/infer.m
% - 06_Probabilistic_Models/marginalizeFactor.m
% - 06_Probabilistic_Models/observe.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Define the network (through its different probability tables)
chol = createCpt({'s', 'c'}, [.8, .2, .4, .6], {[1, 0], [1, 0]})
smoke = createCpt({'s'}, [.15, .85], {[1, 0]})
bp = createCpt({'e', 's', 'b'}, [.45, .55, .05, .95, .95, .05, .55, .45], {[1, 0], [1, 0], [1, 0]})
exercise = createCpt({'e'}, [.4, .6], {[1, 0]})
attack = createCpt({'b', 'a'}, [.75, .25, .05, .95], {[1, 0], [1, 0]})
heart_net = {exercise, smoke, chol, bp, attack};

smokeInfer = (infer(heart_net, {'c', 'b', 'e', 's'}, {'s'}, [1]));
attackInfer = (infer(heart_net, {'c', 'a', 'e', 's'}, {'a'}, [1]));
bloodInfer = (infer(heart_net, {'c', 'a', 'b', 'e'}, {'b'}, [1]));
bloodInfer2 = (infer(heart_net, {'c', 'a', 'b', 's'}, {'b'}, [1]));
bloodExercice = (infer(heart_net, {'c', 'a', 'b', 'e'}, {'b', 'e'}, [1, 1]));
bloodInfer3 = (infer(heart_net, {'c', 'a', 'b'}, {'b'}, [1]));

disp('Smoker :');
disp(smokeInfer);
disp(smokeInfer.probabilities);

disp('Attack :');
disp(attackInfer);
disp(attackInfer.probabilities);

disp('Blood :');
disp(bloodInfer);
disp(bloodInfer.probabilities);

disp('Blood :');
disp(bloodInfer2);
disp(bloodInfer2.probabilities);

disp('Exercise :');
disp(bloodExercice);
disp(bloodExercice.probabilities);

disp('Blood :');
disp(bloodInfer3);
disp(bloodInfer3.probabilities);

%%
% 6.3 - Audio application of Bayesian networks

% 
% This exercise is an open style application of Bayesian networks
% - Try to find a fit audio application
% - Establish your model and prior probabilities
% - Model this network based on your assumptions
% - Perform inference on the network
%