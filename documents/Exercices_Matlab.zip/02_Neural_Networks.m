%% ---------------
% ATIAM - Music machine learning tutorial
%
% Part 2 - Neural Networks
%
% In this tutorial, we will cover a more advanced classification algorithm
% through the use of neural networks. The tutorial starts by performing
% a simple single neuron discrimination of two random distributions.
% Then, we will study the typical XOR problem by using a more advanced
% 2-layer perceptron. Finally, we generalize the use of neural networks in
% order to perform classification on our set of audio classification
% dataset.
%
% <esling@ircam.fr>
%

% Load all files in sub-directories
addpath(genpath('00_Datasets/'));
addpath(genpath('00_Features/'));
addpath(genpath('00_Introduction/'));
addpath(genpath('00_Preprocessing/'));
addpath(genpath('02_Neural_Networks/'));
% Path to the classification dataset
classPath = '00_Datasets/classification';

% 0.1 - Import the classification dataset
dataStruct = importDataset(classPath, 'classification');
% 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = computeTransforms(dataStruct);
% 0.3 - Compute a set of temporal and spectral features
dataStruct = computeFeatures(dataStruct);


%%
% 2.1 - Single neuron discrimination of two random distributions

% Number of points to generate
nPats = 30+floor(rand(1)*30);
% Generate 2-dimensional random points
patterns = rand(2,nPats)*2-1;
% Slope of separating line
slope = log(rand(1)*10);
yint = rand(1) * 2 - 1;
% Create the indexes for a two-class problem
desired = patterns(2,:) - patterns(1,:) * slope - yint > 0;
% Plot the corresponding pattern
plotPatterns(patterns,desired);
% Inputs to use
inputs = [patterns];
% Initialize the weights
weights = rand(1, 2);
bias = rand(1, 1)
% Learning rate
eta = 0.01;
% Weight decay
lambda = 0.1
% Update loop
for i = 1:50
  % Compute the classification
  
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
  
  fprintf('%2d.  weights = ',i);
  disp([bias weights]);
  plotBoundary([bias weights],i,'--')
  pause(0.2)
end
plotBoundary([bias weights],i,'-');

%% Version integrating the bias (optional)

% Inputs to use
inputs = [ones(1,nPats); patterns];
% Initialize the weights
weights = zeros(1, 3);
% Learning rate
eta = 0.01;
% Weight decay
lambda = 0.1
% Plot the corresponding pattern
plotPatterns(patterns,desired);
% Update loop
for i = 1:50
  % Compute the classification
  
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
  
  fprintf('%2d.  weights = ',i);
  disp(weights);
  plotBoundary(weights,i,'--')
  pause(0.2)
end
plotBoundary(weights,i,'-')

%%
% 2.2 - 2-layer neural network classification for solving the XOR problem

load xorPats.dat
load xorAns.dat
patterns = xorPats';    % Input patterns
desired = xorAns';      % Corresponding classes
% Initialize based on their sizes
[nInputs, nPats] = size(patterns);
[nOutputs, ~] = size(desired);
% First plot the patterns
plotPatterns(patterns,desired);
% Learning parameters
nHiddens = 2;           % Number of hidden units
learnRate = 0.08;       % Learning rate parameter
momentum = 0.5;         % Momentum parameter
% Overall input patterns
inputs = patterns;
% Weights of first and second layer
weights1 = rand(nHiddens, nInputs) - 0.5;   % 1st layer weights
weights2 = rand(nOutputs, nHiddens) - 0.5;  % 2nd layer weights
bias1 = rand(nHiddens, 1) - 0.5;               % 1st layer biases
bias2 = rand(nOutputs, 1) - 0.5;               % 2nd layer biases
TSS_Limit = 0.02;                           % Sum-squared error limit
% Previous gradients (for momentum)
deltaW1 = 0;
deltaW2 = 0;
deltaB1 = 0;
deltaB2 = 0;
eta = 0.05;
% Iterate for a fixed number of iterations
for epoch = 1:200
  
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
  fprintf('Epoch %3d:  Error = %f\n',epoch,TSS);
  if TSS < TSS_Limit, break, end
  if rem(epoch-1,20)==0, plotBoundary([bias1 weights1],epoch,'--'), end
end
plotBoundary([bias1 weights1],epoch,'-');

%%
% 2.3 - 3-layer neural network for audio classification
%

% First we will construct the data features matrix
usedFeatures = {'SpectralCentroidMean', 'SpectralFlatnessMean', 'SpectralSkewnessMean'};
dataMatrix = zeros(length(dataStruct.filenames), length(usedFeatures));
for f = 1:length(usedFeatures)
    dataMatrix(:, f) = dataStruct.(usedFeatures{f});
end
dataMatrix(isnan(dataMatrix)) = 0;
patterns = dataMatrix ./ repmat(max(dataMatrix), size(dataMatrix, 1), 1);
% Construct a binary vector of outputs (class indicators)
desired = full(sparse(dataStruct.classes, 1:size(patterns, 1), 1))';
disp(size(desired));
nbTrain = size(desired, 1);
patterns = patterns';
desired = desired';
% First plot the patterns
plotPatterns(patterns,desired);
% Initialize based on their sizes
[nInputs,nPats] = size(patterns);
[nOutputs,nPats] = size(desired);
% First plot the patterns
% Learning parameters
nHiddens = 100;           % Number of hidden units
learnRate = 0.08;       % Learning rate parameter
momentum = 0.8;         % Momentum parameter
% Overall input patterns
inputs = patterns;
% Weights of first and second layer
weights1 = rand(nHiddens, nInputs);       % 1st layer weights
weights2 = rand(nHiddens, nHiddens);      % 2nd layer weights
weightsSoft = rand(nOutputs, nHiddens);   % Softmax layer weights
bias1 = rand(nHiddens, 1);                % 1st layer biases
bias2 = rand(nHiddens, 1);                % 2nd layer biases
TSS_Limit = 0.02;                               % Sum-squared error limit
% Previous gradients (for momentum)
deltaSoft = 0;
deltaW1 = 0;
deltaW2 = 0;
deltaB1 = 0;
deltaB2 = 0;
eta = 0.0008;
% Function for computing the Sigmoid activation
relu = @(x) 1 ./ (1 + exp(-x));
drelu = @(a) a .* (1.0 - a);
% Function for computing the ReLU activation
relu = @(x) max(0, x);
drelu = @(x) 1 ./ (1 + exp(-x));
% Function for computing the Tanh activation
relu = @(x) tanh(x);
drelu = @(x) cosh(x).^-2;
% Iterate for a fixed number of iterations
for epoch = 1:500
  
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
  fprintf('Epoch %3d:  Error = %f\n',epoch,TSS);
  if TSS < TSS_Limit, break, end
end
plotBoundary([bias1 weights1],epoch,'-');
