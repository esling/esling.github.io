function [label, energy] =  kmeans(X, k)
% X: d x n data matrix
% k: number of seeds

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%

end