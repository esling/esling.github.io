function dataStruct = computeFeatures(dataStruct)
% FFT Size
fSize = 1024;
% Number of files
nbFiles = length(dataStruct.filenames);
% Set of spectral features we will compute
dataStruct.featuresSpectral = {'SpectralCentroid','SpectralCrest', ...
    'SpectralDecrease','SpectralFlatness','SpectralKurtosis', ...
    'SpectralRolloff','SpectralSkewness','SpectralSlope','SpectralSpread'};
% Initialize structure for spectral features
for f = 1:length(dataStruct.featuresSpectral)
    dataStruct.(dataStruct.featuresSpectral{f}) = zeros(nbFiles, 128);
    dataStruct.([dataStruct.featuresSpectral{f} 'Mean']) = zeros(nbFiles, 1);
    dataStruct.([dataStruct.featuresSpectral{f} 'Std']) = zeros(nbFiles, 1);
end
% Set the cell of MFCC features
dataStruct.MFCC = cell(nbFiles, 1);
fprintf('    - Performing features.\n');
% Computing the set of features
for file = 1:nbFiles
    fprintf('      * %s.\n', dataStruct.filenames{file});
    curSignal = dataStruct.signal{file};
    curSRate = dataStruct.sRate{file};
    curSpec = dataStruct.spectrumPower{file};
    for f = 1:length(dataStruct.featuresSpectral)
        featVal = zeros(1, size(curSpec, 2));
        for v = 1:length(featVal)
            eval(['featVal(v) = feature' dataStruct.featuresSpectral{f} '(curSpec(:, v), curSRate);']);
        end
        featVal(isnan(featVal)) = mean(featVal(~isnan(featVal)));
        dataStruct.(dataStruct.featuresSpectral{f})(file, :) = resample(featVal, 128, length(featVal));
        dataStruct.([dataStruct.featuresSpectral{f} 'Mean'])(file) = mean(featVal);
        dataStruct.([dataStruct.featuresSpectral{f} 'Std'])(file) = std(featVal);
    end
    curMFCC = featureMFCC(curSignal, curSRate, fSize);
    dataStruct.MFCC{file} = curMFCC;
    dataStruct.MFCCMean{file} = mean(curMFCC);
    dataStruct.MFCCStd{file} = std(curMFCC);
end
end

