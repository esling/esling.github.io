%% ---------------
% ATIAM - Music machine learning tutorial
%
% Part 4 - Clustering
%
% The present tutorials covers the notions of clustering. First, we will 
% use existing implementations of hierarchical clustering to understand 
% how any grouping of points can be considered as a clustering. Then, we 
% will implement a simple algorithm for clustering data into a fixed number
% of groups, namely the k-Means algorithm. The goal here is to familiarize 
% with the notions of unsupervised learning. Finally, we will apply both 
% algorithms in order to perform a task of audio summary generation.
%
% <esling@ircam.fr>
%
%     

% Load all files in sub-directories
addpath(genpath('00_Datasets/'));
addpath(genpath('00_Features/'));
addpath(genpath('00_Introduction/'));
addpath(genpath('00_Preprocessing/'));
addpath(genpath('04_Clustering/'));
% Path to the classification dataset
classPath = '00_Datasets/music-speech';

% 0.1 - Import the classification dataset
dataStruct = importDataset(classPath, 'music-speech');
% 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = computeTransforms(dataStruct);
% 0.3 - Compute a set of temporal and spectral features
dataStruct = computeFeatures(dataStruct);

%%
% 4.1 - Hierarchical clustering
%

songEx = 11;
nbClusters = 20;
% Extract the Constant-Q
curCQT = dataStruct.spectrumConstantQ{songEx};
nbPoints = size(curCQT, 2);
% Perform a smoothed version
smoothTarget = 500;
smoothWins = floor(nbPoints / smoothTarget) * 2;
smoothCQT = zeros(smoothTarget, size(curCQT, 1));
% Prepare set of windows
firstWin = smoothWins / 2;
lastWin = nbPoints - (smoothWins / 2);
winSet = round(linspace(firstWin, lastWin, smoothTarget));
winStarts = (winSet - firstWin) + 1;
winEnds = winStarts + (smoothWins - 1);
% Go through the points
for t = 1:smoothTarget
    winCQT = curCQT(:, winStarts(t):winEnds(t)); 
    smoothCQT(t, :) = mean(winCQT, 2);
end

    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
    
% Plot a stylish dendrogram
ha = tightSubplot(2, 1, [.05 .1],[.1 .1],[.1 .1]);
axes(ha(1));
H = dendrogram(Z, smoothTarget, 'ColorThreshold', 'default', 'Reorder', 1:smoothTarget);
set(H, 'LineWidth', 2);
set(ha(1), 'XTick', []);
axes(ha(2));
colors = jet(nbClusters);
imagesc(flipud(smoothCQT'));
for i = 1:smoothTarget, rectangle('Position',[i,0,i+1,20],'FaceColor', colors(c(i), :), 'EdgeColor', colors(c(i), :)); end
%hold off;
whitebg(gcf, [1 1 1]);

%%
% 4.2 - K-Means clustering
%

% First (small-dense) group of gaussian data
mu = [2,2]; sigma = [0.1,0;0,0.1];
r = mvnrnd(mu,sigma,400);
% Second (large-sparse) group of gaussian data
mu = [6,2]; sigma = [2,0;0,2];
r2 = mvnrnd(mu,sigma,100);

%%%%%%%%%%%%%%%%%
% YOUR CODE GOES in 04_Clustering/kmeans.m
%%%%%%%%%%%%%%%%%

% Compute clustering labels (for 2 groups)
labels = kmeans([r; r2]', 2);
% Rely on labels to plot data
figure;
hold on;
scatter(r(:, 1), r(:, 2), 200, 's', 'MarkerEdgeColor', [0 0.5 0]);
scatter(r2(:, 1), r2(:, 2), 200, '*', 'MarkerEdgeColor', [0 0.5 0.5]);

spread([r; r2]', labels);

% Compute clustering labels (for 2 groups)
labels = kmeans([r; r2]', 6);
% Rely on labels to plot data
figure;
hold on;
scatter(r(:, 1), r(:, 2), 120, 's', 'MarkerEdgeColor', [0 0.5 0]);
scatter(r2(:, 1), r2(:, 2), 120, '*', 'MarkerEdgeColor', [0 0.5 0.5]);
spread([r; r2]', labels);

%%
% 4.2 - Apply the clustering on audio data
%
usedFeatures = {'SpectralCentroidMean', 'SpectralFlatnessMean', 'SpectralSkewnessMean'};
dataMatrix = zeros(length(dataStruct.filenames), length(usedFeatures));
for f = 1:length(usedFeatures)
    dataMatrix(:, f) = dataStruct.(usedFeatures{f});
end
dataMatrix(isnan(dataMatrix)) = 0;
dataMatrix = dataMatrix ./ repmat(max(dataMatrix), size(dataMatrix, 1), 1);

%%%%%%%%%%%%%%%%%
% YOUR CODE GOES HERE
%%%%%%%%%%%%%%%%%

% Compute clustering labels (for 2 groups)
labels = kmeans(dataMatrix', 2);
% Rely on labels to plot data
spread(dataMatrix', labels)

%%
% 4.3 - Apply kMeans on the thumbnailing problem (Q.1)
%

%%%%%%%%%%%%%%%%%
% YOUR CODE GOES HERE
%%%%%%%%%%%%%%%%%

% Compute clustering labels (for 2 groups)
labels = kmeans(dataMatrix', 2);
% Rely on labels to plot data
spread(dataMatrix', labels);
