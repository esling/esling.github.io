%
% 3D Perceptron least mean square with random training set.
%

%%
% Calculate and plot the training set.
%
nPats = 10+floor(rand(1)*30);
Patterns = rand(2,nPats)*2-1;
slope = log(rand(1)*10);
yint = rand(1)*2-1;
Desired = Patterns(2,:) - Patterns(1,:) * slope - yint  > 0;
plotPats3D(Patterns,Desired)
Inputs = [ones(1,nPats); Patterns];
Weights = rand(1, 3) .* 0.00001;
LearnRate = 0.01;
oldTSS=Inf;

for i = 1:100

  plotBoundarySurface(Weights)

  Result = Weights * Inputs;
  TSS = sum((Desired -Result).^2);
  if abs(TSS-oldTSS) < .001, break, else oldTSS=TSS; end
  fprintf('%2d.  TSS=%7.4f,    Weights =',i,TSS);
  disp(Weights);

  Weights = Weights + LearnRate * (Desired-Result) * Inputs';
  pause(0.1)

end
