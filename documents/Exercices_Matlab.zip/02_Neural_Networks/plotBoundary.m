%
% Plot classification boundary based on weight matrix W.
%
function plotBoundary(W,iter,style)
nUnits = size(W,1);
colors = jet;
temp = axis;
xrange = temp(1:2);
for i = 1:nUnits
    if size(style)==1
        color = [0 0 0];
    else
        color = colors(1+rem(3*iter+9,size(colors,1)),:);
    end
    plot(xrange,(-W(i,2)*xrange-W(i,1))/W(i,3),'LineStyle',style,'Color',color,'LineWidth', 1.5);
end
drawnow
