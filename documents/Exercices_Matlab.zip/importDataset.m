function dataStruct = importDataset(classPath, type)
switch type
    case 'classification'
        % Listing of classes in the classification problem
        tmpPaths = dir(classPath);
        classesPaths = {};
        for f = 1:length(tmpPaths)
            if (tmpPaths(f).name(1) ~= '.'), classesPaths{end+1} = tmpPaths(f).name; end
        end
        % Set of classes data
        classData = struct;
        % Number of classes
        nbClasses = length(classesPaths);
        % Names of the classes
        classData.name = cell(length(classesPaths), 1);
        % Number of files
        classData.nbFiles = zeros(length(classesPaths), 1);
        % Filenames for each class
        classData.filenames = cell(length(classesPaths), 1);
        % Keep track of the full number of files
        fullNbFiles = 0;
        fprintf('    - Importing dataset %s.\n', classPath);
        % Parse through all the classes
        for c = 1:length(classesPaths)
            classData.name{c} = classesPaths{c};
            tmpPaths = dir([classPath '/' classesPaths{c}]);
            classFiles = [];
            for f = 1:length(tmpPaths)
                if (tmpPaths(f).name(1) ~= '.' && (~isempty(regexp(tmpPaths(f).name, 'wav', 'once')))), classFiles{end+1} = tmpPaths(f).name; end
            end
            classData.nbFiles(c) = length(classFiles);
            curFiles = cell(classData.nbFiles(c), 1);
            for f = 1:length(classFiles)
                curFiles{f} = [classPath '/' classesPaths{c} '/' classFiles{f}];
            end
            classData.filenames{c} = curFiles;
            fullNbFiles = fullNbFiles + classData.nbFiles(c);
        end
        % Linearize into one flat structure
        filenames = cell(fullNbFiles, 1);
        classes = zeros(fullNbFiles, 1);
        curStart = 1;
        for c = 1:nbClasses
            nbFiles = classData.nbFiles(c);
            curFiles = classData.filenames{c};
            filenames(curStart:(curStart+(nbFiles-1))) = curFiles;
            classes(curStart:(curStart+(nbFiles-1))) = repmat(c, nbFiles, 1);
            curStart = curStart + nbFiles;
        end
        dataStruct = struct;
        dataStruct.filenames = filenames;
        dataStruct.classes = classes;
        dataStruct.classNames = classData.name;
    case 'music-speech'
        % Keep track of the full number of files
        fullNbFiles = 0;
        fprintf('    - Importing dataset %s.\n', classPath);
        % Parse through the audio files
        tmpPaths = dir([classPath '/music/']);
        classFiles = [];
        labFiles = [];
        for f = 1:length(tmpPaths)
            if (tmpPaths(f).name(1) ~= '.' && (~isempty(regexp(tmpPaths(f).name, 'wav', 'once'))))  
                classFiles{end+1} = [classPath '/music/' tmpPaths(f).name]; 
                [fPath, fNa] = fileparts(tmpPaths(f).name);
                labFiles{end+1} = [classPath '/labels/' fNa '.lab'];
                disp(tmpPaths(f).name);
                disp([classPath '/music/' tmpPaths(f).name]); 
                disp([classPath '/labels/' fNa '.lab']);
            end
        end
        disp(labFiles);
        dataStruct = struct;
        dataStruct.filenames = classFiles;
        dataStruct.labfiles = labFiles;
    otherwise
        error(['Unknown dataset type ' type]);
end
end

