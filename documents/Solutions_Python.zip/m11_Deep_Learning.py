#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 11 - Deep Learning
#
# In this tutorial, we will cover the basics of deep learning algorithms by
# relying on the implementation of sparse auto-encoders
#
# This code is adapted from Stanford's UFLJ Tutorial
#
# <esling@ircam.fr>
#

# Load all files in sub-directories
from m03_Support_Vector_Machines import *
from matplotlib import pyplot as plt
import numpy as np
# Path to the classification dataset
classPath = '00_Datasets/classification'

#%% 0.1 - Import the classification dataset
import importDataset as imp
import computeTransforms as cpt
import computeFeatures as cft
dataStruct = imp.importDataset(classPath, 'classification')
# 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = cpt.computeTransforms(dataStruct)
# 0.3 - Compute a set of temporal and spectral features
dataStruct = cft.computeFeatures(dataStruct)

# STEP 0: Here we provide the relevant parameters values.
winSize = 4                                             # size of temporal window
nbBins = dataStruct["spectrumConstantQ"][1].shape[0]    # size of cQ bins
visibleSize = winSize * nbBins                          # number of input units 
hiddenSize = 1024                                       # number of hidden units 
sparsityParam = 0.1                                     # desired average activation of the hidden units.
lambdaW = 3e-3                                          # weight decay parameter       
beta = 3                                                # weight of sparsity penalty term       

#%% 
# Q.11.1 - Implement sample windows
#
####################
# => Your code goes in the sampleSpectrums function
####################
#
#  After implementing sampleSpectrum, the display_network command should
#  display a random sample of 10 spectral window patches from the dataset
patches = sampleSpectrums(dataStruct["spectrumConstantQ"], winSize, nbBins)
# Display examples of extracted spectral windows
display_network(patches[:,randi(size(patches,2),10,1)],nbBins,winSize);
#  Obtain random parameters theta
theta = initializeParameters(hiddenSize, visibleSize);

#%%
# Q.11.2 - Implement sparseAutoencoderCost
#
#  Implement all of the components (squared error cost, weight decay term,
#  sparsity penalty) step-by-step using the following steps:
#   - Implement forward propagation and error term of the cost function.
#   - Implement backpropagation to compute derivatives.
#   - Add in the weight decay term.
#   - Add in the sparsity penalty term.
#  Feel free to change the training settings when debugging your
#  code.  (For example, reducing the training set size or 
#  number of hidden units may make your code run faster)
#
####################
# => Your code goes in the sparseAutoencoderCost function
####################
#
cost, grad = sparseAutoencoderCost(theta, visibleSize, hiddenSize, lambdaW, sparsityParam, beta, patches);

#%% 
# Q.11.2 - Training your sparse autoencoder with minFunc (L-BFGS).
#
# => THIS STEP MIGHT TAKE A VERY LONG TIME, SO LIMIT SIZES OF BOTH THE
# TRAINING SET AND EVENTUALLY NUMBER OF HIDDEN UNITS
#

#  Randomly initialize the parameters
theta = initializeParameters(hiddenSize, visibleSize);
#  Use minFunc to minimize the function
options.Method = 'lbfgs'; # Here, we use L-BFGS to optimize our cost. 
options.display = 'on';
# Launch the optimization
opttheta, cost = minFunc( @(p) sparseAutoencoderCost(p, visibleSize, hiddenSize, lambdaW, sparsityParam, beta, patches), theta, options);

#%% 
# Q.11.2 - Visualization 
#
W1 = reshape(opttheta(1:hiddenSize*visibleSize), hiddenSize, visibleSize);
display_network(W1',nbBins,winSize);

#%%
#
# Second part of the deep learning tutorial
#
# Here we will try to implement a stacked version of the auto-encoders,
# while adding a log softmax classifier layer on top of the previous
# encoding layers.
#
numClasses = len(dataStruct["classNames"]);
hiddenSizeL1 = 200    # Layer 1 Hidden Size
hiddenSizeL2 = 200    # Layer 2 Hidden Size
sparsityParam = 0.1   # Sparsity parameter 
lambdaW = 3e-3        # weight decay parameter       
beta = 3              # weight of sparsity penalty term       

#%% 
# Q.11.4 - Step 1: Train the first sparse autoencoder
# If you've correctly implemented sparseAutoencoderCost.m, you don't need
# to change anything here.

# Randomly initialize the parameters
sae1Theta = initializeParameters(hiddenSizeL1, inputSize)
# Set hyper-parameters of the optimization
options.Method = 'lbfgs'   # Still use L-BFGS to optimize the gradient
options.maxIter = 400      # Maximum number of iterations of L-BFGS to run 
options.display = 'on'     # Perform display of iterations
# Optimize the function
sae1OptTheta, cost = minFunc( @(p) sparseAutoencoderCost(p, inputSize, hiddenSizeL1, lambdaW, sparsityParam, beta, trainData), sae1Theta, options);

#%% 
# Q.11.4 - Step 2: Train the second sparse autoencoder
# If you've correctly implemented sparseAutoencoderCost.m, you don't need
# to change anything here.

# First forward the activation to the first autoencoder (layer)
sae1Features = feedForwardAutoencoder(sae1OptTheta, hiddenSizeL1, inputSize, trainData);
# Randomly initialize the parameters
sae2Theta = initializeParameters(hiddenSizeL2, hiddenSizeL1);
# We will use the same hyper-parameters for optimization
options.Method = 'lbfgs';   # Still use L-BFGS to optimize the gradient
options.maxIter = 400;      # Maximum number of iterations of L-BFGS to run 
options.display = 'on';     # Perform display of iterations
# Optimize the function
sae2OptTheta, cost = minFunc( @(p) sparseAutoencoderCost(p, hiddenSizeL1, hiddenSizeL2, lambdaW, sparsityParam, beta, sae1Features), sae2Theta, options);

#%% 
# Q.11.3 - Step 3: Train the softmax classifier
#  This trains the sparse autoencoder on the second autoencoder features.
# ####################
# => Your code goes in the stackedAECost function
# ####################

[sae2Features] = feedForwardAutoencoder(sae2OptTheta, hiddenSizeL2, hiddenSizeL1, sae1Features);
#  Randomly initialize the parameters
saeSoftmaxTheta = 0.005 * randn(hiddenSizeL2 * numClasses, 1);
# Parameters of optimization
lambda = 1e-4;
options.maxIter = 100;
# Check the training function
softmaxModel = softmaxTrain(hiddenSizeL2, numClasses, lambda, sae2Features, trainLabels, options);
# Retrieve the parameters
saeSoftmaxOptTheta = softmaxModel.optTheta(:);
# Initialize the stack using the parameters learned
stack = cell(2,1);
stack{1}.w = reshape(sae1OptTheta(1:hiddenSizeL1*inputSize), hiddenSizeL1, inputSize);
stack{1}.b = sae1OptTheta(2*hiddenSizeL1*inputSize+1:2*hiddenSizeL1*inputSize+hiddenSizeL1);
stack{2}.w = reshape(sae2OptTheta(1:hiddenSizeL2*hiddenSizeL1), hiddenSizeL2, hiddenSizeL1);
stack{2}.b = sae2OptTheta(2*hiddenSizeL2*hiddenSizeL1+1:2*hiddenSizeL2*hiddenSizeL1+hiddenSizeL2);
# Initialize the parameters for the deep model
[stackparams, netconfig] = stack2params(stack);
stackedAETheta = [ saeSoftmaxOptTheta ; stackparams ];
# Perform the actual minimization on the softmax layer
[stackedAEOptTheta, cost] = minFunc( @(p) stackedAECost(p, inputSize, hiddenSizeL1, numClasses, netconfig, lambda, trainData, trainLabels), stackedAETheta, options);

# ## 
# # Q.6.5 -  Test 
# #  You will need to complete the code in stackedAEPredict.m
# #
# # ####################
# # => Your code goes in the stackedAEPredict function
# # ####################
# #
# # Test the model without finetuning

## 
# Q.11.4 - Include a convolutional operator

#  Train the autoencoder on sub-parts of the input

# ####################
# # YOUR CODE GOES HERE
# ####################

#  Use the autoencoder weights as convolution kernels

# ####################
# # YOUR CODE GOES HERE
# ####################

#  Train the autoencoder based on convolved features

# ####################
# # YOUR CODE GOES HERE
# ####################
