import numpy as np
import operator

def classifyData(x_vec, g, mu_vecs, cov_mats):
#    Classifies an input sample into 1 out of 3 classes determined by
#    maximizing the discriminant function g_i().
    
#    Keyword arguments:
#        x_vec: A dx1 dimensional numpy array representing the sample.
#        g: The discriminant function.
#        mu_vecs: A list of mean vectors as input for g.
#        cov_mats: A list of covariance matrices as input for g.
#    
#    Returns the max probability and class id.

    ######################
    # YOUR CODE GOES HERE
    ######################
    
    ######################
    # Solution
    
    assert(len(mu_vecs) == len(cov_mats)), 'Number of mu_vecs and cov_mats must be equal.'
    
    g_vals = []
    for i in range(len(mu_vecs)):
        m,c = mu_vecs[i], cov_mats[i] 
        g_vals.append(g(x_vec, mu_vec=m, cov_mat=c))
    
    max_index, max_value = max(enumerate(g_vals), key=operator.itemgetter(1))
    return (max_value, max_index)

    ######################
    
    return maxVal, maxId

