import numpy as np

def mleCovariance(xSamples, muEst):
#    Calculates the Maximum Likelihood Estimate for the covariance matrix.
#    
#    Keyword Arguments:
#        x_samples: np.array of the samples for 1 class, n x d dimensional 
#        mu_est: np.array of the mean MLE, d x 1 dimensional
#        
#    Returns the MLE for the covariance matrix as d x d numpy array.
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    ######################
    # Solution

    cov_est = np.zeros((2,2))
    for x_vec in xSamples:
        x_vec = x_vec.reshape(2,1)
        assert(x_vec.shape == muEst.shape), 'mean and x vector hmust be of equal shape'
        cov_est += (x_vec - muEst).dot((x_vec - muEst).T)
    return cov_est / len(xSamples)

    ######################
    
    return covEst