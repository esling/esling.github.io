# ---------------
# ATIAM - Music machine learning tutorial
#
# Part 6 - Probabilistic models
#
# <https://esling.github.io/ [...]>
# <esling@ircam.fr>
#

# Load all files in sub-directories
from m06_Probabilistic_Models import sampleExponential as se
from m06_Probabilistic_Models import sampleBeta as sb
from m06_Probabilistic_Models import createCpt as cc
from m06_Probabilistic_Models import factorProduct as fp
from m06_Probabilistic_Models import marginalize as ma
from m06_Probabilistic_Models import marginalizeFactors as mf
from m06_Probabilistic_Models import observe as ob
from m06_Probabilistic_Models import infer as inf
reload(cc)
from matplotlib import pyplot as plt
from scipy.stats import expon
from scipy.stats import beta
import numpy as np

#%%
# 6.1 - Sampling from different distributions

nbSamples = 500
nbBins = 50

########################################################
# YOUR CODE GOES IN 06_Probabilistic_Models/sampleExponential.m
########################################################

# Exponential distribution
mu = .5
samples = np.random.exponential(mu, nbSamples)
samplesEx = se.sampleExponential(mu, nbSamples, 1)
# Compute the PDF
X = np.linspace(0, np.max(samples), np.max(samples) * 100)
y1 = expon.pdf(X) * (nbSamples / nbBins) * (np.max(samples) * 1.5)
# Display both
plt.figure(figsize=(12, 8))
plt.subplot(2,1,1)
plt.hist(samples, 50, label='Samples')
plt.plot(X,y1,ls='--',c='r',linewidth=2, label='Exponential PDF')
plt.legend(loc=1)
plt.subplot(2,1,2)
plt.hist(samplesEx.transpose(), 50, label='Samples')
plt.plot(X,y1,ls='--',c='r',linewidth=2, label='Exponential PDF')
plt.legend(loc=1)

#%%
########################################################
# YOUR CODE GOES IN 06_Probabilistic_Models/sampleBeta.m
########################################################

# Beta distribution
a = 0.6
b = 1.5
samples = np.random.beta(a, b, nbSamples)
samplesBeta = sb.sampleBeta(a, b, nbSamples, 1)
# Compute the PDF
X = np.linspace(0, 1, 100)
y1 = beta.pdf(X, a, b) * (nbSamples / nbBins) * (np.max(samples) * 1.5)
# Display both
plt.figure(figsize=(12, 8))
plt.subplot(2,1,1)
plt.hist(samples, 50, label='Samples')
plt.plot(X,y1,ls='--',c='r',linewidth=2, label='Beta PDF')
plt.legend(loc=1)
plt.subplot(2,1,2)
plt.hist(samplesBeta, 50, label='Samples')
plt.plot(X,y1,ls='--',c='r',linewidth=2, label='Beta PDF')
plt.legend(loc=1)

#%%
# 6.2 - Bayesian network

########################################################
# YOUR CODE GOES IN 
# - 06_Probabilistic_Models/factorProduct.m
# - 06_Probabilistic_Models/infer.m
# - 06_Probabilistic_Models/marginalizeFactor.m
# - 06_Probabilistic_Models/observe.m
########################################################

# Define the network (through its different probability tables)
chol = cc.createCpt(["s", "c"], [.8, .2, .4, .6], [(1, 0), (1, 0)])
smoke = cc.createCpt(["s"], [.15, .85], [(1, 0)])
bp = cc.createCpt(["e", "s", "b"], 
                [.45, .55, .05, .95, .95, .05, .55, .45], 
                [(1, 0), (1, 0), (1, 0)])
exercise = cc.createCpt(["e"], [.4, .6], [(1, 0)])
attack = cc.createCpt(["b", "a"], [.75, .25, .05, .95], [(1, 0), (1, 0)])
heart_net = [exercise, smoke, chol, bp, attack]

smokeInfer = inf.infer(heart_net, ["c", "b", "e", "s"], ["s"], [1])
attackInfer = inf.infer(heart_net, ["c", "a", "e", "s"], ["a"], [1])
bloodInfer = inf.infer(heart_net, ["c", "a", "b"], ["b"], [1])
bloodInfer2 = inf.infer(heart_net, ["c", "a", "b", "s"], ["b"], [1])
bloodExercice = inf.infer(heart_net, ["c", "a", "b", "e"], ["b", "e"], [1, 1])
bloodInfer3 = inf.infer(heart_net, ["c", "a", "b"], ["b"], [1])

print('Smoker :')
print(smokeInfer)
print(smokeInfer["probabilities"])

print('Attack :')
print(attackInfer)
print(attackInfer["probabilities"])

print('Blood :')
print(bloodInfer)
print(bloodInfer["probabilities"])

print('Blood :')
print(bloodInfer2)
print(bloodInfer2["probabilities"])

print('Exercise :')
print(bloodExercice)
print(bloodExercice["probabilities"])

print('Blood :')
print(bloodInfer3)
print(bloodInfer3["probabilities"])

#%%
# 6.3 - Audio application of Bayesian networks

# 
# This exercise is an open style application of Bayesian networks
# - Try to find a fit audio application
# - Establish your model and prior probabilities
# - Model this network based on your assumptions
# - Perform inference on the network
#