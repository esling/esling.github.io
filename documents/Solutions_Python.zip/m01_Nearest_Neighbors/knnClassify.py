import numpy as np

#
# function [probas, winnerClass] = knnClassify(dataStruct, testSample, k, normalize, useL1dist);
# 
# This function is used for classifying an uknown sample using the kNN
# algorithm, in its multi-class form.
#
# Arguments :
# - dataStruct  : the data structure
# - testSample  : the input sample id to be classified
# - k           : the k (number of neighbors) parameter
# - distType    : type of distance ['Euclidean', 'Manhattan', 'Cosine'] (optional)
# - normalize   : use class priors to weight results (optional)
#
# Returns :
# - probas      : an array that contains the classification probabilities for each class
# - winnerClass : the label of the winner class
#
def knnClassify(dataStruct, testSample, usedFeatures, k=1, distType='Euclidean', normalize=0):
    # Keep the number of classes
    numOfClasses = len(dataStruct["classNames"]);
    # Initialization of class properties
    numOfDims = np.zeros(numOfClasses)
    numOfTrainSamples = np.zeros(numOfClasses)
    classFeats = [];
    # Create a data matrix with the features of all data
    dataMatrix = np.zeros((len(dataStruct["filenames"]), len(usedFeatures)))
    for f in range(len(usedFeatures)):
        dataMatrix[:, f] = dataStruct[usedFeatures[f]];
        # Remove NaN and Inf
        dataMatrix[:, f] = np.nan_to_num(dataMatrix[:, f])
        dataMatrix[:, f] = dataMatrix[:, f] / np.max(dataMatrix[:, f])
    # Retrieve the features of the test samples
    testFeatures = dataMatrix[testSample, :]
    # dist{i} will the vector of distance of the testing sample to all the samples of i-th class
    dist = []
    # We create a vector of "inf" distances for each class and a cell of features
    for i in range(numOfClasses):
        # Retrieve the class points
        curPoints = np.linspace(0, len(dataStruct["classes"])-1, len(dataStruct["classes"]), dtype=int)[dataStruct["classes"] == i]
        # Eventually remove the current sample
        curPoints = curPoints[curPoints != testSample];
        numOfTrainSamples[i] = len(curPoints);
        numOfDims[i] = len(usedFeatures);
        # Fill the dist cell with "inf" values
        dist.append(np.inf * np.ones(int(np.max(numOfTrainSamples))));
        # Keep the cell of class features
        classFeats.append(dataMatrix[curPoints, :])
        classFeats[i] = np.nan_to_num(classFeats[i])
    # Compute the distance vectors for each class
    for i in range(numOfClasses):
        #################
        # YOUR CODE GOES HERE
        # Q 1.2.1
        # Q 1.2.4 (switch distType)
        #################
        
        ######################
        # Solution:

        if distType == 'L1':
            dist[i] = np.sum(np.abs(testSample - classFeats[i].transpose()), axis=1); # L1
        elif distType == 'Euclidean':
            dist[i] = np.sum((testSample - classFeats[i].transpose()) ** 2, axis=1); # L2
        dist[i] = np.sort(dist[i])
        dist[i][len(dist[i]):int(np.max(numOfTrainSamples))] = np.inf;  
                                                  
        ######################        

    kAll = np.zeros((numOfClasses, 1))
    # Compute the mean distance value for k neighbors
    for j in range(k):
        #################
        # YOUR CODE GOES HERE
        # Q 1.2.1
        #################
        
        ######################
        # Solution:

        curArray = np.zeros((numOfClasses, 1));
        for i in range(numOfClasses):
            curArray[i] = dist[i][int(kAll[i])]
        imin = np.argmin(curArray)
        kAll[imin] = kAll[imin] + 1;

        ######################
       
    # Normalize the class probabilities
    
    #################
    # YOUR CODE GOES HERE
    # Q 1.2.6
    #################
    
    ######################
    # Solution:

    if (normalize == 0):
        probas = (kAll / k);
    else:
        probas = kAll / numOfTrainSamples.transpose();
        probas = probas / np.sum(probas);

    ######################
        
    # Retrieve the winning class
    
    #################
    # YOUR CODE GOES HERE
    # Q 1.2.1
    #################
    
    ######################
    # Solution:

    winnerClass = np.argmax(probas)

    ######################

    return probas, winnerClass