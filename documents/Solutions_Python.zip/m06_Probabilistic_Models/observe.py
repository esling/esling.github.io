def observe(network, varName, observation):
    """
    Observes a given variable in our network.  This just deletes all entries not consistent
    with the observation
    
    Args:
        :param network: (list pandas.dataframe) list of the cpts in the network
        :param var_name: (list string) name of the observed variables
        :param observation: (list string) values that are observed 
    
    Returns:
        :return: (pandas.dataframe) 
    
    """
    observed_network = []
    
    ######################
    # Solution :
    
    for cpt in network:
        for var,obs in zip(var_name, observation):
            if var in cpt.columns:
                cpt = cpt[cpt[var] == obs]
        observed_network.append(cpt)
    
    ######################
    
    return observed_network

