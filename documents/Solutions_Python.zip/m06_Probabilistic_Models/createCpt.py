import pandas as pd
import itertools

def createCpt(var_names, probs, levels_list):
    """
    This method generates a pandas dataframe as a conditional probability table
    
    Args:
        :param var_names: (list string) list of variable names
        :param probs: (list double) vector of probabilities for the flattened probability table
        :param levels_list: (list string tuples) list of outcomes for each variable i.e. high or low
        
    Returns:
        :return cpt: (pandas.DatFrame) The conditional probability table
    """
    
    # Create the data frame
    cpt = pd.DataFrame(columns=["probs"] + var_names)
    
    # Fill in the probabilities
    cpt["probs"] = probs
    
    # Step through and set the levels of each variable
    levels_table = list(itertools.product(*(levels_list)))
    
    if not len(levels_table) == len(probs):
        print "ERROR:: Incorrect probability dimensions"
        return None
    
    cpt[var_names] = levels_table
    return cpt