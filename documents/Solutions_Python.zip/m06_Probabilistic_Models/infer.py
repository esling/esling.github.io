from .observe import observe
from .factorProduct import factorProduct
from .marginalizeFactor import marginalizeFactor

def infer(network, marg_vars, obs_vars, obs_vals):
#
#    This function performs inference on a bayesian network
#    
#    Args:
#        network    : Original network onto which perform inference
#        marg_vars  : Marginalized variables
#        obs_vars   : Observed variables
#        obs_vals   : Observed values
#    
#    Returns:
#        :returns: The new network
#
    
    ######################
    # Solution
    
    # Observe variables
    network = observe(network, obs_vars, obs_vals)
    
    # while there are still variables to be marginalized
    for marg_var in marg_vars:
        marg_net = []
        rm_nodes = []
        for i, node in enumerate(network):
            if marg_var in node.columns:
                marg_net.append(node)
                rm_nodes.append(i)
                
        # Check to see if marg_vars is present
        if not len(marg_net) == 0:
            table = marg_net[0]
            
            # delete marginalized nodes from network
            rm_nodes.reverse()
            for rm in rm_nodes:
                del network[rm]
                
            # marginalize out variables
            for cpt in marg_net[1:]:
                table = factorProduct(table, cpt)
                
            marginalized_table = marginalizeFactor(table, marg_var)
            network.append(marginalized_table)            
    
    # When all variables have been marginalized product the table together
    product = network[0]
    for node in network[1:]:
        product = factorProduct(product, node)
        
    # Normalize
    product["probs"] = product["probs"] / sum(product["probs"])
    
    ######################
    
    return product

