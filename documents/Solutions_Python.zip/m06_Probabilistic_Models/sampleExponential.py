import numpy as np

def sampleExponential(mu, n, m):
    
    ######################
    # Solution

    samples = np.random.exponential(scale=mu, size=(m,n))
    
    ######################
    
    return samples