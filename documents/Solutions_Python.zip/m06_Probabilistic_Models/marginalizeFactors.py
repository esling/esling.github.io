def marginalizeFactors(cpt, factors):
#
#    Marginalizes out a list of factors from a single cpt
#    
#    Args:
#        :param cpt: CPT structure
#        :param factors: (list string)
#    
#    Returns:
#        :return cpt: (pandas.DataFrame)

    for i in range(len(factors)):
        cpt = marginalizeFactor(cpt, factor);
    return cpt

