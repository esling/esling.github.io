import numpy as np

def sampleBeta(a, b, M, N):
    
    ######################
    # Solution

    samples = np.random.beta(a, b, size=(M, N))
    
    ######################
    
    return samples