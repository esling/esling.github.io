#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 8 - Gaussian Mixtures
#
# <https://esling.github.io/ [...]>
# <esling@ircam.fr>
#

# Load all files in sub-directories
from m08_Gaussian_Mixtures import emGMMFit as em
from m08_Gaussian_Mixtures import emGMM3D as em3d
from m08_Gaussian_Mixtures import expectedValue as ev
from matplotlib import pyplot as plt
import numpy as np
import time

#%%
# 8.1 - Generate data with known parameters

def normpdf(x, mu, sigma):
    fact = 1 / np.sqrt(2 * np.pi * sigma);
    expo = - np.power((x - mu), 2) / (2 * sigma)
    return fact * np.exp(expo)

nbPatterns = 2000
# Generate 200 random patterns for class 1
mu1 = 4.2
sigma1 = 1
x1samples = (np.random.randn(nbPatterns) * sigma1) + mu1
# Generate 200 random patterns for class 2
mu2 = 6.8
sigma2 = 1
x2samples = (np.random.randn(nbPatterns) * sigma2) + mu2
# Plot the corresponding data
nbBins = 50
X1 = np.linspace(np.min(x1samples), np.max(x1samples), (np.max(x1samples) - np.min(x1samples)) * 10)
y1 = normpdf(X1, mu1, sigma1) * (nbPatterns / nbBins) * np.max(x1samples);
X2 = np.linspace(np.min(x2samples), np.max(x2samples), (np.max(x2samples) - np.min(x2samples)) * 10)
y2 = normpdf(X2, mu2, sigma2) * (nbPatterns / nbBins) * np.max(x1samples);
# Display both
plt.figure(figsize=(12, 8))
plt.hist(x1samples, bins=nbBins);
plt.hist(x2samples, bins=nbBins);
plt.plot(X1, y1, ls='--', c='r', linewidth=2);
plt.plot(X2, y2, ls='-.', c='g', linewidth=2);
plt.legend({'Samples c.1', 'Samples c.2', 'PDF c.1', 'PDF c.2'});
plt.title('Training Dataset');


#%%
# 8.2 - Generate data with known parameters

# Create a mixed set of samples (to not know their origin)
fullSamples = np.concatenate((x1samples, x2samples))
nbSamples = fullSamples.shape[0]
fullSamples = fullSamples[np.random.choice(nbSamples, nbSamples)]

nbIterations = 20
mu1guess = np.random.rand(1,1) * 10
mu2guess = np.random.rand(1,1) * 10
likelihoods = np.zeros((nbIterations, 1))
mus = np.zeros((nbIterations, 2))
plt.figure(figsize=(12,8))
for i in range(nbIterations):
    
    ######################
    # YOUR CODE GOES in 08_Gaussian_Mixtures/expectedValue.m
    ######################
    # Expected value of Z-variable
    tau = ev.expectedValue(fullSamples, mu1guess, mu2guess);
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    # Save incomplete likelihood value (should be monotone)
    # Compute new MLE estimates of mus
    # Save the current guessed values;
    mus[i, 0] = mu1guess
    mus[i, 1] = mu2guess
    # Plot the corresponding guesses
    nbBins = 50
    Xs = np.linspace(np.min(fullSamples), np.max(fullSamples), (np.max(fullSamples) - np.min(fullSamples)) * 10)
    y1guess = normpdf(Xs, mu1guess[0], 1) * (nbPatterns / nbBins) * np.max(x1samples)
    y2guess = normpdf(Xs, mu2guess[0], 1) * (nbPatterns / nbBins) * np.max(x2samples)
    # Display both 
    plt.plot(Xs, y1guess, ls='--', c='r', linewidth=2, label='Samples c.1')
    plt.plot(Xs, y2guess, ls='-.', c='g', linewidth=2, label='Samples c.2')
    plt.plot(X1, y1 * 0.9, ls='--', c='k', linewidth=2, label='PDF c.1')
    plt.plot(X2, y2 * 0.9, ls='-.', c='k', linewidth=2, label='PDF c.2')
    plt.title('Training Dataset')
    time.sleep(0.2)

#%%
# 8.3 - 3-dimensionnal GMM
em3d.emGMM3D()

######################
# YOUR CODE GOES in 08_Gaussian_Mixtures/emGMMFit.m
######################

