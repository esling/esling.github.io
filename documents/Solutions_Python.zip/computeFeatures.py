import numpy as np
import librosa as librosa
import yaafelib as y
#
# Main features computation function
#
def computeFeatures(dataStruct):
    # Window sizes
    wSize = 1024
    hSize = wSize / 4
    # Number of files
    nbFiles = len(dataStruct["filenames"])
    # Set of spectral features we will compute
    featuresYAAFE = ['SpectralVariation','SpectralFlux',
        'SpectralDecrease','SpectralFlatness','PerceptualSharpness',
        'SpectralRolloff','SpectralSlope', 'MFCC']
    featuresLibrosa = ['Loudness', 'SpectralCentroid', 'SpectralContrast', 'SpectralRolloff'] 
    dataStruct["featuresSpectral"] = featuresLibrosa + featuresYAAFE
    # Initialize structure for spectral features
    for f in dataStruct["featuresSpectral"]:
        dataStruct[f] = []
        dataStruct[f + 'Mean'] = []
        dataStruct[f + 'Std'] = []
    print('    - Performing features.');
    # Computing the set of features
    for curFile in range(nbFiles):
        print('      * %s' % dataStruct["filenames"][curFile])
        curSignal = dataStruct["signal"][curFile]
        curSRate = dataStruct["sRate"][curFile]
        # Create YAAFE extraction engine
        fp = y.FeaturePlan(sample_rate=curSRate)
        for f in featuresYAAFE:
            fp.addFeature(f+': '+f+' blockSize='+str(wSize)+' stepSize='+str(hSize))
        engine = y.Engine()
        engine.load(fp.getDataFlow())
        features = engine.processAudio(curSignal.astype('float64').reshape((1, curSignal.shape[0])))
        for key, val in sorted(features.items()):
            dataStruct[key].append(val)
            dataStruct[key + 'Mean'].append(np.mean(val))
            dataStruct[key + 'Std'].append(np.std(val))
        # Add the specific features from Librosa
        dataStruct["Loudness"].append(librosa.feature.rmse(curSignal))
        # Compute the spectral centroid. [y, sr, S, n_fft, ...]
        dataStruct["SpectralCentroid"].append(librosa.feature.spectral_centroid(curSignal))
        # Compute spectral contrast [R16] , sr, S, n_fft, ...])	
        dataStruct["SpectralContrast"].append(librosa.feature.spectral_contrast(curSignal))
        # Compute roll-off frequency
        dataStruct["SpectralRolloff"].append(librosa.feature.spectral_rolloff(curSignal))
        for f in featuresLibrosa:
            val = dataStruct[f][-1]
            dataStruct[f + 'Mean'].append(np.mean(val))
            dataStruct[f + 'Std'].append(np.std(val))
    return dataStruct

