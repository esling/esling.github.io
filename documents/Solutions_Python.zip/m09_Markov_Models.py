#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 9 - Markov Models.
#
# In this tutorial, we will see the use of Hidden Markov Models (HMM) in
# order to perform sequence likelihood, parsing and model inference. Most
# of the tutorial will be devoted to the implementation of the
# forward-backward algorithm for performing the EM learning of the HMM
# models. Then, we will apply this algorithm to a problem of audio
# segmentation.
#
# <https://esling.github.io/atiam-ml-9-markov-models/>
# <esling@ircam.fr>
#

# Load all files in sub-directories
from m09_Markov_Models import hmmViterbiMain as hvm
from m09_Markov_Models import hmmEM as he
import numpy as np

#%%
# 9.0 - Setup our prior Hidden Markov Model


# Define the model states
states = ['Onset', 'Mid', 'End'];
emissions = ['C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7']
# Import the input data
with open('m09_Markov_Models/phone.train') as f:
    lines = f.read().splitlines()
inputSequences = len(lines) * [None]
symSequences = len(lines) * [None]
for i in range(len(lines)):
    curSeq = lines[i].split(' ');
    inSeq = np.zeros((len(curSeq), 1))
    for c in range(len(inSeq)):
        inSeq[c] = emissions.index(curSeq[c])
    symSequences[i] = curSeq;
    inputSequences[i] = inSeq.transpose();
# Set an arbitrary initial model (priors)
transProbas = np.array(
    [[0.3, 0.0, 0.0],
     [0.7, 0.9, 0.1],
     [0.0, 0.1, 0.4]]
    ).transpose()
# Arbitrary emission priors
emitProbas = np.array(
    [[0.5, 0.0001, 0.0001],     # Emission C1
     [0.2, 0.0001, 0.0001],     # Emission C2
     [0.3, 0.2, 0.0001],        # Emission C3
     [0.0001, 0.7, 0.1],        # Emission C4
     [0.0001, 0.1, 0.0001],     # Emission C5
     [0.0001, 0.0001, 0.5],     # Emission C6
     [0.0001, 0.0001, 0.4]]     # Emission C7
    ).transpose()
# Arbitrary start priors
startProbas = [1, 0, 0]
# Create our prior model
model = {}
model["A"] = transProbas;
model["E"] = emitProbas;
model["s"] = startProbas;
model["d"] = len(emissions);
print(model);

#%%
# 9.1 - Viterbi decoding algorithm

########################################################
# YOUR CODE GOES IN 
# - 09_Markov_Models/hmmViterbi.m
########################################################

# Evaluate the sequences of hidden states with the Viterbi algorithm
for s in range(len(inputSequences)):
    curSeq = symSequences[s];
    z, p = hvm.hmmViterbiMain(inputSequences[s], model);
    print('Sequence %d - Likelihood %f\n' % (s, p * (2 ** len(curSeq))))
    for c in range(len(curSeq)):
        print('[%s](%s) ' % (states[int(z[c])], curSeq[c]))

#%%
# 9.1 - Viterbi decoding algorithm

########################################################
# YOUR CODE GOES IN 
# - 09_Markov_Models/hmmEM.m
# - 09_Markov_Models/hmmForwardBackward.m
########################################################

# Update the model based on the EM, algorithm
for s in range(len(inputSequences)):
    model = he.hmmEM(inputSequences[s], model)
print('Final model :')
print(model["A"])
print(model["E"])

# Use first a completely random model
model = he.hmmEM(inputSequences[1], 3, 7);
# Then update it based on other sequences
for s in range(len(inputSequences) - 1):
    model = he.hmmEM(inputSequences[s + 1], model)
print('Final model :')
print(model["A"])
print(model["E"])

## 
