import numpy as np

def init(X, m):
    d = X.shape[0]
    n = X.shape[1]
    if (type(m) == int or len(m) == 1):                           # random initialization
        mu = X[:, np.random.choice(n, m)]
        label = np.argmin(np.dot(mu.transpose(), X).transpose(), axis=1)
    elif all(m.shape == [1,n]):               # init with labels
        label = m
    elif m.shape[0] == d:                     # init with seeds (centers)
        label = np.argmin(np.dot(m, m, 1).transpose() / 2 - np.dot(m.transpose(), X))
    return label

def kmeans(X, k):
    # X: d x n data matrix
    # k: number of seeds

    ######################
    # Solution
    print(X.shape)
    label = init(X, k);
    n = label.size
    idx = np.linspace(1, n, n)
    last = np.zeros((1, n))
    mu = np.zeros((X.shape[0], k))
    it = 0
    while (np.sum((label != last) * 1) > 0) and (it < 10):
        # remove empty clusters
        last = label
        for i in range(k):
            mu[:, i] = np.mean(X[:, label==i])
        label = np.argmin(np.dot(mu.transpose(), X).transpose(), axis=1)
        val = np.min(np.dot(mu.transpose(), X).transpose(), axis=1)
        it = it + 1
    energy = 2 * np.sum(val)

    ######################
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return label
