import numpy as np
import scipy.linalg as sl
from matplotlib import pyplot as plt
import emGMMFit as egf
import dirrand as di
import time

# 3D visualization of EM for GMMs
# function X = EM_GMM_3d(c,wk,N,movie,Y,D,Cv)
#
# Inputs: c      - # clusters (default: 5)
#         wk     - array of # gaussians to fit (default: 1:10)
#         N      - # GMM samples (default: 200)
#         movie  - string: writes .avi for each k (default: [])
#         Y      - NxD data matrix (default: generate new data)
#         D      - data dimensionality (default: 3)
#         Cv     - covariance type (0: diag, 1: full) (default: full)
# Output: X      - NxD data matrix
#
# How it works:
#   For each value of k in 'wk':
#    - Fit GMM with EM
#    - Interpolate model params between EM iterations
#    - Coloring: Gaussians - transparency = GMM mixing weights
#                data      - color blend = posterior probs
#    - Play movie of EM learning
#    - (optional) Save movie to .avi file
#
# Author: Johannes Traa, UIUC, Nov-Dec '11
# 
# Revised Mar '13 (cleaned up code, added full covariance capability)

def emGMM3D(c=5,wk=None,N=200,movie=None,Y=None,D=3,Cv=1):
    # check input args
    if movie is None:
        m_val = 0;
    else:
        m_val = 1;
    # Get data
    if Y is None:
        # GMM params
        m = 10 * np.random.randn(c,D) # means
        C = np.zeros((D,D,c)); # covariance matrices
        for j in range(c):
            Cj = np.random.randn(D,10);
            C[:,:,j] = np.dot(Cj, Cj.transpose())
        w = di.dirrand(3 * np.ones((1,c)),1) # mixing weights
        # sample from GMM
        X = np.zeros((N,D));
        for i in range(N):
            r = np.random.multinomial(1, w)
            j = np.linspace(1, w, w)[r != 0]
            X[i, :] = m[j, :] + np.random.randn(1,D) * sl.sqrtm(C[:, :, j]);
    else:
        X = Y;
        N, D = X.shape
    # get GMM and show movie for different k
    # initialize figure window
    fh = plt.figure(figsize=(12, 8))

    for k in wk:
        # ----- fit k-gaussian GMM -----
        M, C, P, ii = egf.emGMMFit(X, k, Cv)  
        # ----- interpolate params between iterations -----
        fps = 35; # frames per second
        f = fps * ii +1; # # frames
        m = np.zeros((k,D,f)) # interpolated means
        Cm = np.zeros((D,D,k,f)) # interpolated covars
        Pi = np.zeros((N,k,f)) # interpolated posteriors
        # set anchor frames (true values of model at each iteration)
        for i in range(ii):
            m[:, :, i * fps + 1] = M[i]
            Cm[:, :, :, i * fps] = C[i]
            Pi[:, :, i * fps] = P[i]
      
        # correct last frame
        m[:, :, ii * fps] = m[:, :, ii * fps]
        Cm[:, :, :, ii * fps] = Cm[:, :, :, ii * fps]
        Pi[:, :, ii * fps] = Pi[:, :, ii * fps]
        
        # interpolate missing frames for continuity
        mix = np.linspace(0, 1, fps) # mixing weights for interpolation
        for i in range(ii):
            # get anchor values
            m1 = m[:, :, i * fps]
            m2 = m[:, :, i * fps]
            c1 = Cm[:, :, :, i * fps]
            c2 = Cm[:, :, :, (i + 1) * fps];
            p1 = Pi[:, :, i * fps]
            p2 = Pi[:, :, (i + 1) * fps]
            # interpolate
            for j in range(fps - 1):
                m[:, :, i * fps + j] = m1 * mix[fps - j + 1] + m2 * mix[j]
                Cm[:, :, :, i * fps + j] = c1 * mix[fps - j + 1] + c2 * mix[j]
                Pi[:, :, i * fps + j] = p1 * mix[fps - j + 1] + p2 * mix[j]
        # fills (2D) or ellipsoids (3D)
        rr = 20; # resolution
        theta = np.linspace(0, 2 * np.pi, rr);
        if D == 2:
            E = np.zeros((rr, D, k, f)); # fill boundaries
            v = np.hstack(np.cos(theta), np.sin(theta)).transpose()
        else:
            E = np.zeros((rr, rr, D, k, f)) # surf contours
            phi = np.linspace(0, np.pi, rr)
            v = np.hstack(np.kron(np.cos(theta),np.sin(phi)), np.kron(np.sin(theta),np.sin(phi)), np.repeat(np.cos(phi),[1,rr])).transpose()
        for i in range(f):
            for j in range(k):
                E_ij = m[j, :, i] + v * sl.sqrtm(Cm[:, :, j, i])
                if D == 2:
                    E[:, :, j, i] = E_ij
                else:
                    for d in range(3):
                        E[:, :, d, j, i] = np.reshape(E_ij[:,d],[rr,rr]);

        # ----- coloring -----
        # posterior = color
        cc = plt.cm.magma.colors
        C = np.zeros((N,3,f))
        for i in range(f):
            C[:, :, i] = Pi[:, :, i] * cc
        # mixing weight = transparency
        w = np.sum(Pi, axis=0) / N;         # mixing weights
        w = np.reshape(w,[k,f]).transpose() # (frames x Gaussians)
        w = w / np.max(w, axis=1)           # normalize rows
        w = w + np.linspace(0.2,0.6,f).transpose() # fade in ellipsoids

  
        # ----- set up for movie -----
        # set up to write frames to avi object/set frame skip rate
        if (m_val == 0): # don't write movie, skip frames for speed
            fi = 5;
        else: # write frames for movie
            aviobj = avifile([movie, num2str(k)])
            fi = 1
  
        # axis handles (means, fills/ellipsoids, data)
        eh = np.zeros((k,1)) # fills/ellipsoids
        if D == 2:
            mmh = plt.scatter(m[:,1,1],m[:,2,1],200,'+k'); # means
            for g in range(k): # fills
                eh[g] = plt.fill(E[:,1,g,1],E[:,2,g,1],cc[g,:],'FaceAlpha',w[1,g],'EdgeColor','none')
            Xh = plt.scatter(X[:,1],X[:,2],30,C[:,:,1],'filled'); # data
        else:
            mmh = plt.scatter3(m[:,1,1],m[:,2,1],m[:,3,1],200,'+k'); # means
            for g in range(k): # ellipsoids
                eh[g] = plt.surf(E[:,:,1,g,1],E[:,:,2,g,1],E[:,:,3,g,1], 'FaceColor',cc[g,:],'FaceAlpha',w[1,g],'EdgeColor','none');
            Xh = plt.scatter(X[:,1],X[:,2],X[:,3],30,C[:,:,1],'filled'); # data
        # figure details
        if D == 3:
            plt.axis(vis3d)
        plt.grid()
        rot = 0;
        set(plt.gca(),'Color','w')
        # ----- play movie showing evolution of GMM -----
        for i in np.linspace(1, f-1)[1:fi:f-1]:
            it = 1+np.floor((i-1)/fps); # iteration #                
            # update data coloring
            set(Xh,'CData',C[:,:,i]);                
            # update interpolated means ('+')
            set(mmh,'XData',m[:,1,i]);
            set(mmh,'YData',m[:,2,i]);
            if D == 3:
                set(mmh,'ZData',m[:,3,i]);
            # update ellipsoids
            for g in range(k):
                if D == 2:
                    set(eh(g),'XData',E[:,1,g,i])
                    set(eh(g),'YData',E[:,2,g,i])
                else:
                    set(eh(g),'XData',E[:,:,1,g,i])
                    set(eh(g),'YData',E[:,:,2,g,i])
                    set(eh(g),'ZData',E[:,:,3,g,i])
                set(eh(g),'FaceAlpha',w[i,g])
            # figure details
            plt.xlabel('iteration: ' + str(it))
            if D == 3:
                plt.view(-50+rot,30)
                rot = rot + 0.4;
            # add frame to .avi object
            if m_val:
                F = getframe(fh);
                aviobj = addframe(aviobj,F);
            time.sleep(1/fps);
        # ----- clean up for next k -----
        plt.xlabel('iteration: ' + str(ii))
        # write out video
        if m_val:
            for i in range(fps):
                aviobj = addframe(aviobj,F);
            aviobj = close(aviobj);
            clf
        elif k != wk[-1]:
            time.sleep(2)
        # new figure
        if k < wk[end] and m_val == 0:
            plt.figure(figsize=(12, 8))