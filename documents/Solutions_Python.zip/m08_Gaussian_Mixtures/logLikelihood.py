def logLikelihood(x, mu1, mu2):
    
    ######################
    # YOUR CODE GOES HERE
    ######################

    return logL