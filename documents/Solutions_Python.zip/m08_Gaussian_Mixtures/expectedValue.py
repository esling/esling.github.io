import numpy as np

def expectedValue(x, mu1, mu2):
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    def normpdf(x, mu, sigma):
        fact = 1 / np.sqrt(2 * np.pi * sigma);
        expo = - np.power((x - mu), 2) / (2 * sigma)
        return fact * np.exp(expo)
    
    vals = (normpdf(x, mu1, 1) / (normpdf(x, mu1, 1) + normpdf(x, mu2, 1)))
    print(vals)
    return vals

