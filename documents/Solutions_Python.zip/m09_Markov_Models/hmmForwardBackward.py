import numpy as np
from .normalize import normalize

def hmmForwardBackward(E, A, s):
    # Implmentation function HMM smoothing alogrithm.
    # Unlike the method described in the slides, the alpha returned is the normalized version: gamma(t)=p(z_t|x_{1:T})
    # Computing unnormalized version gamma(t)=p(z_t,x_{1:T}) is numerical unstable, which grows exponential fast to infinity.
    # Input:
    #   M: k x n emission data matrix M=E*X
    #   A: k x k transition matrix
    #   s: k x 1 start prior probability
    # Output:
    #   gamma: k x n matrix of posterior gamma(t)=p(z_t,x_{1:T})
    #   alpha: k x n matrix of posterior alpha(t)=p(z_t|x_{1:T})
    #   beta: k x n matrix of posterior beta(t)=gamma(t)/alpha(t)
    #   c: loglikelihood
    # Written by Mo Chen (sth4nth@gmail.com).
    K, T = E.shape
    At = A.transpose()
    c = np.zeros(T) # normalization constant
    alpha = np.zeros((K, T))

    ######################
    # YOUR CODE GOES HERE
    ######################

    ######################
    # Solution:
    print(E)    
    alpha[:, 0], c[0] = normalize(s * E[:, 0], 0)
    for t in range(1, T, 1):
        alpha[:,t], c[t] = normalize(np.dot(At, alpha[:, t - 1]) * E[:, t], 0)
    beta = np.ones((K,T));
    for t in range(T-2, 0, -1):
        beta[:, t] = np.dot(A, beta[:,t+1]) * E[:, t+1] / c[t+1]
    gamma = alpha * beta
    
    ######################

    return gamma, alpha, beta, c