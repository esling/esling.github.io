import numpy as np

def normalize(X, dim=None):
# Normalize the vectors to be summing to one
#   By default dim = 1 (columns).
# Written by Michael Chen (sth4nth@gmail.com).
    if dim is None:
        # Determine which dimension sum will use
        for i in range(X.ndim):
            if (X.shape[i] != 1):
                dim = i
                break;
        if dim is None:
            dim = 1
    s = np.sum(X, axis=dim)
    Y = X * 1/s
    return Y, s