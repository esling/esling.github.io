import numpy as np

def hmmViterbi(M, A, s):
# Implmentation function of Viterbi algorithm. 
# Input:
#   M: k x n emision data matrix M=E*X
#   A: k x k transition matrix
#   s: k x 1 starting probability (prior)
# Output:
#   z: 1 x n latent state
#   p: 1 x n probability
# Written by Mo Chen (sth4nth@gmail.com).
    k, n = M.shape
    Z = np.zeros((k,n))
    A = np.log(A);
    M = np.log(M);

    ######################
    # YOUR CODE GOES HERE
    ######################

    return z, p