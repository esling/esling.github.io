import numpy as np

def hmmViterbi(M, A, s):
# Implmentation function of Viterbi algorithm. 
    # Input:
    #   M: k x n emision data matrix M=E*X
    #   A: k x k transition matrix
    #   s: k x 1 starting probability (prior)
    # Output:
    #   z: 1 x n latent state
    #   p: 1 x n probability
    # Written by Mo Chen (sth4nth@gmail.com).
    k, n = M.shape
    Z = np.zeros((k,n))
    A = np.log(A);
    M = np.log(M);

    ######################
    # YOUR CODE GOES HERE
    ######################

    ######################
    # Solution:
    
    Z[:, 1] = np.linspace(1, k, k);
    v = np.log(s[:]) + M[:, 1];
    for t in range(n):
        v = np.max(A + v, axis=0)
        idx = np.argmax(A + v, axis=0)
        v = v[:] + M[:, t];
        Z = Z[idx, :];
        Z[:, t] = np.linspace(1, k, k);
    v = np.max(v)
    idx = np.argmax(v)
    z = Z[idx, :]
    p = np.exp(v);
    
    ######################

    return z, p