import normalize as no
import scipy.sparse as sps
import hmmForwardBackward as hfb
import numpy as np

def hmmEM(x, init, d=None):
    # EM algorithm to fit the parameters of HMM model (a.k.a Baum-Welch algorithm)
    # Input:
    #   x: 1 x n integer vector which is the sequence of observations
    #   init: model or k
    # Output:s
    #   model: trained model structure
    #   llh: loglikelihood
    # Written by Mo Chen (sth4nth@gmail.com).
    
    if isinstance(init, dict):
        A = init["A"]
        E = init["E"]
        s = init["s"]
        d = init["d"]
    else:  # random init with latent k
        k = init
        A = no.normalize(np.random.rand(k,k), 1)
        E = no.normalize(np.random.rand(k,d), 1)
        s = no.normalize(np.random.rand(k,1), 0)
    n = x.shape[1]
    X = sps.csr_matrix(x, shape=(d, n)).eliminate_zeros().todense()
    M = np.dot(E, X)
    tol = 1e-4
    maxIter = 2
    llh = -np.inf((1,maxIter))
    for iterV in range(maxIter):
        # E-step
        gamma, alpha, beta, c = hfb.hmmForwardBackward(M, A, s)
        llh[iterV] = np.sum(np.log(c[c > 0]))
        # check likelihood for convergence
        if llh[iterV] - llh[iterV - 1] < tol * np.abs(llh[iterV - 1]):
            break
        # M-step 
        
        ######################
        # YOUR CODE GOES HERE
        ######################
                                          
    llh = llh[1:iterV]
    model = {}
    model["A"] = A;
    model["E"] = E;
    model["s"] = s;
    model["d"] = d;
    return model, llh 