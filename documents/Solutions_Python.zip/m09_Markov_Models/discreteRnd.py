import numpy as np

def discreteRnd(p, n=1):
    # Generate samples from a discrete distribution (multinomial).
    # Input:
    #   p: k dimensional probability vector
    #   n: number of samples
    # Ouput:
    #   x: k x n generated samples x~Mul(p)
    # Written by Mo Chen (sth4nth@gmail.com).
    r = np.random.rand(1,n);
    p = np.cumsum(p[:]);
    x = np.digitize(r,[0, p / p[-1]]);
    return x