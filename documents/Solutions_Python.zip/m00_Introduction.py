# ---------------
# ATIAM - Music machine learning tutorial
#
# Part 0 - Introduction
# Import data, pre-process and compute features
#
# In this tutorial, we will cover basic Music Information Retrieval (MIR)
# interactions, in which we process a dataset of sound files and try to
# observe the properties of their various spectral features
#
# <https://esling.github.io/atiam-ml-0-intro/>
# <esling@ircam.fr>
#

#%% Import useful modules
#import m00_Features
#import m00_Introduction
#import m00_Preprocessing
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import gridspec
from mpl_toolkits.mplot3d import Axes3D
#%% Path to the classification dataset
classPath = 'm00_Datasets/classification';

#%%
import importDataset as imp
# 0.1 - Import the classification dataset
dataStruct = imp.importDataset(classPath, 'classification');

#%% Q-0.1.2 - Count function to print the number of examples

######################
# YOUR CODE GOES HERE
######################

######################
# Solution:
n_classes = len(dataStruct["classNames"]);
for ind1 in range(n_classes):
    temp = dataStruct["classes"][dataStruct["classes"] == ind1]
    print('%18s \t : %d files' % (dataStruct["classNames"][ind1], len(temp)))
print('%18s \t : %d files' % ('total', len(dataStruct["classes"])))
######################

#%%
# 0.2 - Pre-process the audio to obtain spectral transforms 
# (may take around a minute)
import computeTransforms as cpt
dataStruct = cpt.computeTransforms(dataStruct);

#%% Q-0.2.2 - Plot the various transforms 

######################
# YOUR CODE GOES HERE
######################

######################
# Solution
for ind1 in range(n_classes):
    temp = np.linspace(0, len(dataStruct["classes"])-1, len(dataStruct["classes"]))[dataStruct["classes"] == ind1]
    transforms = ['Power', 'Mel', 'Chroma', 'CQT'];
    fig = plt.figure(figsize=(12, 8))
    fig.subplots(nrows=2,ncols=2,gridspec_kw={'width_ratios':[1, 1], 'height_ratios':[1, 1]})
    for ind2 in range(len(transforms)):
        ax = plt.subplot(2, 2, ind2 + 1)
        ax.imshow(np.flipud(dataStruct["spectrum" + transforms[ind2]][int(temp[1])]), interpolation='nearest', aspect='auto')
        plt.title(transforms[ind2] + ' spectrum from class ' + dataStruct["classNames"][ind1])
        ax.set_adjustable('box-forced')
    fig.tight_layout()
######################
        
#%%
# 0.3 - Compute a set of temporal and spectral features
# (may take around 1-2 minutes)
import computeFeatures as cft
dataStruct = cft.computeFeatures(dataStruct);

#%% Q-0.3.2 - Plot the various features 

######################
# YOUR CODE GOES HERE
######################

######################
# Solution
for ind1 in range(n_classes):
    temp = np.linspace(0, len(dataStruct["classes"])-1, len(dataStruct["classes"]))[dataStruct["classes"] == ind1]
    #features = ['SpectralVariation','SpectralFlux',
    #    'SpectralDecrease','SpectralFlatness','PerceptualSharpness',
    #    'SpectralRolloff','SpectralSlope']
    features = ['Loudness', 'SpectralCentroid', 'SpectralContrast', 'SpectralRolloff'] 
    fig = plt.figure(figsize=(12, 8))
    fig.subplots(nrows=len(features),ncols=2,gridspec_kw={'width_ratios':[3, 1]})
    for ind2 in range(len(features)):
        plt.subplot(len(features), 2, (2 * ind2) + 1)
        for ind3 in range(len(temp)):
            plt.plot(dataStruct[features[ind2]][int(temp[ind3])])
        plt.title(features[ind2] + ' of class ' + dataStruct["classNames"][ind1])
        featM = dataStruct[features[ind2] + 'Mean']
        featS = dataStruct[features[ind2] + 'Std']
        featCat = np.column_stack((featM, featS))
        plt.subplot(len(features), 2, (2 * ind2) + 2)
        plt.boxplot(featCat)
        plt.title('Boxplots of mean and std')
######################

#%% Q-0.3.4 - Observe the distribution of classes for different features

plt.figure(figsize=(12,8))
# Create a vector of random colors for each class
colorVect = np.zeros((3, len(dataStruct["classNames"])));
for c in range(len(dataStruct["classNames"])):
    colorVect[:,c] = np.random.rand(3);

######################
# YOUR CODE GOES HERE
######################
    
######################
# Solution
#features = ['SpectralCentroidMean','LoudnessMean', 'SpectralSlopeMean'];
features = ['Loudness', 'SpectralCentroid', 'SpectralContrast', 'SpectralRolloff']
fig = plt.figure(figsize=(15, 15))
ax = fig.add_subplot(111, projection='3d')
for ind1 in range(n_classes):
    temp = (np.linspace(0, len(dataStruct["classes"])-1, len(dataStruct["classes"]), dtype=int)[dataStruct["classes"] == ind1])
    X = [dataStruct[features[0]][i] for i in temp]
    Y = [dataStruct[features[1]][i] for i in temp]
    Z = [dataStruct[features[2]][i] for i in temp]
    ax.scatter(X,Y,Z,s=50,c=colorVect[:,ind1])
ax.set_xlabel(features[0])
ax.set_ylabel(features[1])
ax.set_zlabel(features[2])
plt.show()
######################