import numpy as np

def weakClassifierError(t, dim, sign, data, labels, weights=None):
    # Handle uniform weights case
    if weights is None:
        weights = np.ones((data.shape[0], 1))
    # Compute the predictions
    errorSum = 0;
    errors = [];
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    ######################
    # Solution
    
    if (sign > 0):
        y = (data[:, dim] >= t) * 1
    else:
        y = (data[:, dim] < t) * 1
    y[y == 0] = -1
    errors = weights * ((labels != y) * 1)
    errorSum = np.sum(((labels != y) * 1))
    ######################
    
    return errorSum, errors

