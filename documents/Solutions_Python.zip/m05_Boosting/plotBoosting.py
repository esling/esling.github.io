from matplotlib import pyplot as plt
from .weakClassifierError import weakClassifierError
import numpy as np

def plotBoosting(classifiers, patterns, labels, it, weights, alpha):
    plt.figure()
    plt.scatter(patterns[labels == -1, 0], patterns[labels == -1, 1], s=10, c='r');
    plt.scatter(patterns[labels == 1, 0], patterns[labels == 1, 1], s=10, c='g');
    tempSum = np.zeros(labels.shape[0])
    for i in range(it+1):
        errSum, errors = weakClassifierError(classifiers[i, 0], int(classifiers[i, 1]), int(classifiers[i, 2]), patterns, labels, weights)
        # Plot the classifier and corresponding errors
        if (classifiers[i, 1] == 1):
            plt.plot([classifiers[i, 0], classifiers[i, 0]], [np.min(patterns[:, 1]), np.max(patterns[:, 1])], ls='--', linewidth=2, c='b')
        else:
            plt.plot([np.min(patterns[:, 0]), np.max(patterns[:, 0])], [classifiers[i, 0], classifiers[i, 0]], ls='--', linewidth=2, c='b')
        th = classifiers[i, 0] 
        dim = int(classifiers[i, 1])
        sig = int(classifiers[i, 2])
        if (sig == 1):
            temp = (patterns[:, dim] >= th) * 1
        else: 
            temp = (patterns[:, dim] < th) * 1
        temp[temp == 0] = -1;
        tempSum = (tempSum + alpha[i] * temp);
        final_label = (tempSum > 0) * 1;
        final_label[final_label == 0] = -1;
        misses = np.sum((final_label != labels) * 1) / patterns.shape[0]
    plt.scatter(patterns[final_label != labels, 0], patterns[final_label != labels, 1], s=20, c='k');#, 'LineWidth', 3);
    plt.title('Errors : %d' % (misses))

