import numpy as np

def init(X, m):
    d = X.shape[0]
    n = X.shape[1]
    if (type(m) == int or len(m) == 1):                           # random initialization
        mu = X[:, np.random.choice(n, m)]
        label = np.argmin(np.dot(mu, mu).transpose() / 2 - np.dot(mu, X).transpose())
    elif all(m.shape == [1,n]):               # init with labels
        label = m
    elif m.shape[0] == d:                     # init with seeds (centers)
        label = np.argmin(np.dot(m, m, 1).transpose() / 2 - np.dot(m.transpose(), X))
    return label

def kmeans(X, k):
    # X: d x n data matrix
    # k: number of seeds

    ######################
    # Solution
    
    label = init(X, k);
    n = label.size
    idx = np.linspace(1, n, n)
    last = np.zeros((1, n))
    while any(label != last):
        last[:] = np.unique(label)                        # remove empty clusters
        mu = np.dot(X, np.normalize(sparse(idx, last, 1), 1))   # compute cluster centers 
        label = np.argmin(np.dot(mu, mu, 1).transpose() / 2 - np.dot(mu.transpose(), X))          # assign sample labels
        val = np.min(np.dot(mu, mu, 1).transpose() / 2 - np.dot(mu.transpose(), X))          # assign sample labels
    energy = np.dot(X[:], X[:], 1) + 2 * np.sum(val)

    ######################
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    return label,energy
