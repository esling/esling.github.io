import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def spread(X, label=None):
    # Plot samples of different labels with different colors.
    # Written by Michael Chen (sth4nth@gmail.com).
    d = X.shape[0]
    n = X.shape[1]
    if label is None:
        label = np.ones((n, 1))
    assert(n == label.size)
    color = 'brgmcyk'
    m = color.size
    c = np.max(label);
    # Create figure
    fig = plt.figure(figsize=(12, 8))
    if (d == 2):
        plt.view(2);
        for i in range(c):
            idc = (label == i)
            plt.scatter(X[1, idc], X[2, idc], s=36, c=color[(i-1) % m]);
    elif (d == 3):
        ax = fig.add_subplot(111, projection='3d')
        for i in range(c):
            idc = (label == i)
            ax.scatter(X[1, idc], X[2, idc], X[3, idc], s=36, c=color[(i-1) % m]);
    else:
        raise Exception('ERROR: only support data of 2D or 3D.');
    ax.legend()
    ax.grid(True)
    fig.tight_layout()
    plt.show()