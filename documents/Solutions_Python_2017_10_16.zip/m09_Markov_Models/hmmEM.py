function [model, llh] = hmmEM(x, init, d)
% EM algorithm to fit the parameters of HMM model (a.k.a Baum-Welch algorithm)
% Input:
%   x: 1 x n integer vector which is the sequence of observations
%   init: model or k
% Output:s
%   model: trained model structure
%   llh: loglikelihood
% Written by Mo Chen (sth4nth@gmail.com).

if isstruct(init)   % init with a model
    A = init.A;
    E = init.E;
    s = init.s;
    d = init.d;
elseif numel(init) == 1  % random init with latent k
    k = init;
    A = normalize(rand(k,k),2);
    E = normalize(rand(k,d),2);
    s = normalize(rand(k,1),1);
end

n = size(x,2);
X = sparse(x,1:n,1,d,n);
M = E*X;

tol = 1e-4;
maxIter = 2;
llh = -inf(1,maxIter);
for iter = 2:maxIter
%     E-step
    [gamma,alpha,beta,c] = hmmForwardBackward(M,A,s);
    llh(iter) = sum(log(c(c>0)));
    % check likelihood for convergence
    if llh(iter)-llh(iter-1) < tol*abs(llh(iter-1)); break; end   
%     M-step 
    
    %%%%%%%%%%%%%%%%%%%%%%
    % YOUR CODE GOES HERE
    %%%%%%%%%%%%%%%%%%%%%%
                                      
end
llh = llh(2:iter);
model.A = A;
model.E = E;
model.s = s;
model.d = d;
end