import numpy as np

def svmPredict(model, X):
#SVMPREDICT returns a vector of predictions using a trained SVM model
#(svmTrain). 
#   pred = SVMPREDICT(model, X) returns a vector of predictions using a 
#   trained SVM model (svmTrain). X is a mxn matrix where there each 
#   example is a row. model is a svm model returned from svmTrain.
#   predictions pred is a m x 1 column of predictions of {0, 1} values.
#

    # Check if we are getting a column vector, if so, then assume that we only
    # need to do prediction for a single example
    if X.shape[1] == 1:
        # Examples should be in rows
        X = X.transpose()
    
    # Dataset 
    m = X.shape[0]
    p = np.zeros((m, 1))
    pred = np.zeros((m, 1))
    
    if model["kernel"] == 'linear':
        ######################
        # Code for the linear kernel
        ######################
        print('Selecting linear kernel')
        
        ######################
        # Solution 
        
        p = np.dot(X, model["w"]) + model["b"]
        
        ######################
        
    elif model["kernel"] == 'gaussian':
        ######################
        # Code for the gaussian kernel
        ######################
        print('Selecting gaussian kernel')
        
        ######################
        # Solution 
        
        X1 = np.sum(X ^ 2, 2)
        X2 = np.sum(model["X"] ^ 2, 2).transpose()
        K = X1, + (X2 - 2 * np.dot(X, model["X"].transpose()))
        K = model.kernelFunction(1, 0) ^ K
        K = model["y"] * K
        K = model["alphas"] * K
        p = np.sum(K, 2);
        
        ######################
        
    elif kernel == 'polynomial':
        ######################
        # Code for the polynomial kernel
        ######################
        print('Selecting polynomial kernel')
    elif kernel == 'sigmoid':
        ######################
        # Code for the sigmoid kernel
        ######################
        print('Selecting sigmoid kernel')
    else:
        ######################
        # Code for eventual other kernels
        ######################
        print('Selecting other kernel')
        
        ######################
        # Solution 
        
        ######################
    
    # Convert predictions into 0 / 1
    pred[p >= 0] =  1;
    pred[p <  0] =  0;
    return pred

