from matplotlib import pyplot as plt

def plotData(X, y):
    #PLOTDATA Plots the data points X and y into a new figure 
    #   PLOTDATA(x,y) plots the data points with + for the positive examples
    #   and o for the negative examples. X is assumed to be a Mx2 matrix.
    #
    # Note: This was slightly modified such that it expects y = 1 or y = 0
    
    # Find Indices of Positive and Negative Examples
    pos = (y == 1)[:, 0] 
    neg = (y == 0)[:, 0]
    # Plot Examples
    plt.scatter(X[pos, 0], X[pos, 1], marker='x', linewidths=2, s=17, c=[0, 0.5, 0])
    plt.scatter(X[neg, 0], X[neg, 1], marker='o', linewidths=2, s=17, c=[1, 0, 0])
