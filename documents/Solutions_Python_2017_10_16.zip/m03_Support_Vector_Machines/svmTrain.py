import numpy as np

def svmTrain(X, Y, C, kernel, tol=1e-3, maxIter=5):
#SVMTRAIN Trains an SVM classifier using a simplified version of the SMO 
# X       : m x n matrix of m training examples (with n-dimensional features).
# Y       : column vector of class identifiers
# C       : standard SVM regularization parameter
# tol     : tolerance value used for determining equality of floating point numbers. 
# maxIter : number of iterations over the dataset before the algorithm stops.

    # Data parameters
    m = X.shape[0]
    n = X.shape[1]
    
    # Map 0 to -1
    Y[Y == 0] = -1
    
    # Variables
    alphas = np.zeros((m, 1))
    b = 0
    E = np.zeros((m, 1))
    passes = 0
    eta = 0
    L = 0
    H = 0
    
    # Pre-compute the Kernel Matrix since our dataset is small
    # (in practice, optimized SVM packages that handle large datasets
    #  gracefully will _not_ do this)
    # 
    if kernel == 'linear':
        ######################
        # Code for the linear kernel
        ######################
        
        ######################
        # Solution 
        
        K = np.dot(X, X.transpose())
        
        ######################
        
        print('Selecting linear kernel')
    elif kernel == 'gaussian':
        ######################
        # Code for the gaussian kernel
        ######################
        
        ######################
        # Solution 
        
        X2 = np.sum(X ^ 2, 2)
        K = X2 + (X2.transpose() - 2 * np.dot(X, X.transpose()))
        K = kernel ^ K
        
        ######################
        
        print('Selecting gaussian kernel')
    elif kernel == 'polynomial':
        ######################
        # Code for the polynomial kernel
        ######################
        print('Selecting polynomial kernel')
    elif kernel == 'sigmoid':
        ######################
        # Code for the sigmoid kernel
        ######################
        print('Selecting sigmoid kernel')
    else:
        ######################
        # Code for eventual other kernels
        ######################
        print('Selecting other kernel')
    # Train
    print('Training ...')
    while passes < maxIter:
        # Check that some alphas changed
        num_changed_alphas = 0;
        # Iterative over all alpha_i
        for i in range(m):
                
            print('Remove this print')
                
            ######################
            # YOUR CODE GOES HERE
            # => Perform one pass of the SMO algorithm for each alpha_i
            ######################
        
        
            ######################
            # Solution 
            E[i] = b + np.sum(alphas * Y * K[:, i]) - Y[i]
            if ((np.dot(Y[i], E[i]) < -tol and alphas[i] < C) or (np.dot(Y[i], E[i]) > tol and alphas[i] > 0)):
                # In practice, there are many heuristics one can use to select
                # the i and j. In this simplified code, we select them randomly.
                j = int(np.floor(m * np.random.rand()))
                while j == i:  # Make sure i \neq j
                    j = int(np.floor(m * np.random.rand()))
                # Calculate Ej = f(x(j)) - y(j) using (2).
                E[j] = b + np.sum(alphas * Y * K[:, j]) - Y[j]
                # Save old alphas
                alpha_i_old = alphas[i]
                alpha_j_old = alphas[j]
                # Compute L and H by (10) or (11). 
                if (Y[i] == Y[j]):
                    L = np.max([0, alphas[j] + alphas[i] - C])
                    H = np.min([C, alphas[j] + alphas[i]])
                else:
                    L = np.max([0, alphas[j] - alphas[i]])
                    H = np.min([C, C + alphas[j] - alphas[i]])
                if (L == H):
                    # Continue to next i. 
                    continue    
                # Compute eta by (14).
                eta = 2 * K[i, j] - K[i, i] - K[j, j];
                if (eta >= 0):
                    # continue to next i. 
                    continue;                
                # Compute and clip new value for alpha j using (12) and (15).
                alphas[j] = alphas[j] - (Y[j] * (E[i] - E[j])) / eta
                # Clip
                alphas[j] = np.min([H, alphas[j]])
                alphas[j] = np.max([L, alphas[j]])
                # Check if change in alpha is significant
                if (np.abs(alphas[j] - alpha_j_old) < tol):
                    # continue to next i and replace anyway
                    alphas[j] = alpha_j_old
                    continue                
                # Determine value for alpha i using (16). 
                alphas[i] = alphas[i] + Y[i]*Y[j]*(alpha_j_old - alphas[j])
                
                # Compute b1 and b2 using (17) and (18) respectively. 
                b1 = b - E[i] - Y[i] * (alphas[i] - alpha_i_old) *  K[i, j].transpose() - Y[j] * (alphas[j] - alpha_j_old) *  K[i, j].transpose()
                b2 = b - E[j] - Y[i] * (alphas[i] - alpha_i_old) *  K[i, i].transpose() - Y[j] * (alphas[j] - alpha_j_old) *  K[j, j].transpose()
                # Compute b by (19). 
                if (0 < alphas[i] and alphas[i] < C):
                    b = b1
                elif (0 < alphas[j] and alphas[j] < C):
                    b = b2
                else:
                    b = (b1+b2)/2;    
                num_changed_alphas = num_changed_alphas + 1;
        
            ######################
            
        if (num_changed_alphas == 0):
            passes = passes + 1
        else: 
            passes = 0
    print(' Done !');
    # Save the model
    idx = (alphas > 0).transpose()[0];
    print(idx)
    model = {} 
    model["X"] = X[idx, :]
    print(model["X"])
    model["y"] = Y[idx]
    model["kernel"] = kernel
    model["b"] = b
    model["alphas"] = alphas[idx]
    model["w"] = np.dot((alphas * Y).transpose(), X).transpose()
    return model
