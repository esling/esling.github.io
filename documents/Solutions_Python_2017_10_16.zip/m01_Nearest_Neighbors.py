#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 1 - Nearest neighbors
#
# In this tutorial, we will cover the simplest classification algorithm
# known as the k-Nearest Neighbor algorithm.
#
# <esling@ircam.fr>
#

# Load all files in sub-directories
from m01_Nearest_Neighbors import *
import numpy as np
from matplotlib import pyplot as plt
# Path to the classification dataset
classPath = '00_Datasets/classification'

import importDataset as imp
import computeTransforms as cpt
import computeFeatures as cft
# 0.1 - Import the classification dataset
dataStruct = imp.importDataset(classPath, 'classification')
# 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = cpt.computeTransforms(dataStruct)
# 0.3 - Compute a set of temporal and spectral features
dataStruct = cft.computeFeatures(dataStruct)

#%%
# 1.1 - K-Nearest Neighbor querying
usedFeatures = ['SpectralCentroidMean', 'SpectralSlopeMean', 'PerceptualSharpnessMean']
# Create a data matrix only from selected features
dataMatrix = np.zeros((len(dataStruct["filenames"]), len(usedFeatures)))
for f in range(len(usedFeatures)):
    dataMatrix[:, f] = dataStruct[usedFeatures[f]]
# Avoid NaN and inf values
dataMatrix = np.nan_to_num(dataMatrix)
# Normalize the matrix (unit-variance)
for f in range(len(usedFeatures)):
    dataMatrix[:,f] = (dataMatrix[:, f] - np.mean(dataMatrix[:, f])) / np.std(dataMatrix[:, f])
# Create a vector of colors
colorVect = plt.cm.inferno_r.colors[1::10]
# Q 1.1.1 - Perform some 10-NN queries and plot the result
for test in range(10):
    selectID = int(np.random.randint(low=0, high=len(dataStruct["filenames"]), size=1))
    selectMask = [True] * len(dataStruct["filenames"])
    selectMask[selectID] = False
    tmpCopy = dataMatrix[selectMask]
    tmpClass = dataStruct["classes"][selectMask]
    
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    ######################
    # Solution:
    valsTemp = dataMatrix[selectID,:]
    distTemp = np.sqrt((valsTemp - tmpCopy) ** 2);
    dist = np.mean(distTemp, axis=1);
    nnIDs = np.argsort(dist);
    ######################
    
    fig = plt.figure(figsize=(12,8))
    ax = fig.add_subplot(111, projection='3d')
    for c in range(len(dataStruct["classNames"])):
        curPoints = (dataStruct["classes"] == c);
        curColor = colorVect[c]
        s = ax.scatter(xs=dataMatrix[curPoints, 0], ys=dataMatrix[curPoints, 1], zs=dataMatrix[curPoints, 2], s=80, c=curColor);
    s = ax.scatter(tmpCopy[nnIDs[:10], 0], tmpCopy[nnIDs[:10], 1], tmpCopy[nnIDs[:10], 2], s=100, linewidths=6);
    s.set_edgecolors = s.set_facecolors = lambda *args:None
    s = ax.scatter(dataMatrix[selectID, 0], dataMatrix[selectID, 1], dataMatrix[selectID, 2], s=200, linewidths=6);
    s.set_edgecolors = s.set_facecolors = lambda *args:None
    for t in range(10):
        fD = (tmpCopy[nnIDs[t], :] - dataMatrix[selectID, :]) * 4;
        s = ax.text(tmpCopy[nnIDs[t], 0] + fD[0], tmpCopy[nnIDs[t], 1] + fD[1], tmpCopy[nnIDs[t], 2] + fD[2], dataStruct["classNames"][tmpClass[nnIDs[t]]], fontsize=14, fontweight='bold', horizontalalignment='center');
        s.set_edgecolors = s.set_facecolors = lambda *args:None
        ax.plot([tmpCopy[nnIDs[t], 0], tmpCopy[nnIDs[t], 0] + (fD[0] * 0.8)], [tmpCopy[nnIDs[t], 1], tmpCopy[nnIDs[t], 1] + (fD[1] * 0.8)], [tmpCopy[nnIDs[t], 2], tmpCopy[nnIDs[t], 2] + (fD[2] * 0.8)], linewidth=2, c='k')
    ax.set_xlabel('Centroid'); 
    ax.set_ylabel('Slope'); 
    ax.set_zlabel('Sharpness');
    ax.set_title('True class : ' + dataStruct["classNames"][dataStruct["classes"][selectID]]);
    plt.show()
#%%
# 1.2 - K-Nearest Neighbors classification based on static properties
#
nbClasses = len(dataStruct["classNames"])
nbFiles = len(dataStruct["filenames"])
correctElements1NN = 0
correctElements5NN = 0
confusionMatrix1NN = np.zeros((nbClasses, nbClasses))
confusionMatrix5NN = np.zeros((nbClasses, nbClasses))
probasMatrix1NN = np.zeros((nbFiles, nbClasses))
probasMatrix5NN = np.zeros((nbFiles, nbClasses))
# Import your code
from m01_Nearest_Neighbors import knnClassify as kn
reload(kn)
# Q 1.2.1 Perform 1-NN and 5-NN classification
for f in range(nbFiles):
    
    ########################################################
    # YOUR CODE GOES IN 01_Nearest_Neighbors/knnClassify.py
    ########################################################
    
    # Perform 1-NN classification
    probas, winClass = kn.knnClassify(dataStruct, f, ['SpectralCentroidMean', 'SpectralFlatnessMean', 'SpectralSlopeMean'], 1)
    if (winClass == dataStruct["classes"][f]):
        correctElements1NN = correctElements1NN + 1
    confusionMatrix1NN[dataStruct["classes"][f], winClass] = confusionMatrix1NN[dataStruct["classes"][f], winClass] + 1;
    probasMatrix1NN[f, :] = probas[:, 0];
    # Perform 5-NN classification
    [probas, winClass] = kn.knnClassify(dataStruct, f, ['SpectralCentroidMean', 'SpectralFlatnessMean', 'SpectralSlopeMean'], 5);
    if (winClass == dataStruct["classes"][f]):
        correctElements5NN = correctElements5NN + 1;
    confusionMatrix5NN[dataStruct["classes"][f], winClass] = confusionMatrix5NN[dataStruct["classes"][f], winClass] + 1;
    probasMatrix5NN[f, :] = probas[0, :];

# Q 1.2.3 - Plotting the confusion matrices
plt.figure(figsize=(12,8))
plt.subplot(1,2,1)
plt.imshow(confusionMatrix1NN)
plt.set_cmap(plt.cm.jet)
plt.title('1-NN Confusion')
for c in range(confusionMatrix1NN.shape[0]):
    plt.text(c, c, str(confusionMatrix1NN[c, c] / np.sum(confusionMatrix1NN[c, :])), fontsize=16, fontweight='bold', color=[1, 0, 0], horizontalalignment='center');
plt.yticks(range(len(dataStruct["classNames"])), dataStruct.classNames)
plt.xticks(range(len(dataStruct["classNames"])), dataStruct.classNames)
#set(gca, 'XTickLabelRotation', 90);
plt.subplot(1,2,2)
plt.imshow(confusionMatrix5NN)
plt.set_cmap(plt.jet)
plt.title('1-NN Confusion')
for c in range(confusionMatrix5NN.shape[0]):
    plt.text(c, c, str(confusionMatrix5NN[c, c] / np.sum(confusionMatrix5NN[c, :])), fontsize=16, fontweight='bold', color=[1, 0, 0], horizontalalignment='center');
plt.yticks(range(len(dataStruct["classNames"])), dataStruct.classNames)
plt.xticks(range(len(dataStruct["classNames"])), dataStruct.classNames)
#set(gca, 'XTickLabelRotation', 90);

# Q 1.2.4 - Repeat the classification process for various K and features

######################
# YOUR CODE GOES HERE
######################

#%%
# 1.3 - Evaluating classification accuracy with various measures
#
# Type of normalization
normalizationMode = 2
# number of classes
nClasses = confusionMatrix1NN.shape[0]
# confusion matrix normalization:
######################
# YOUR CODE GOES HERE
######################
if (normalizationMode == 1): 
    print('Standard normalization')
elif (normalizationMode == 2): 
    print('Row-wise normalization')
else:         
    print('No normalization')

######################
# YOUR CODE GOES HERE
######################

# compute overal accuracy
# compute class precision
# compute class recall
# compute class F1 measure

maxK = 10
classPrecisions = np.zeros((maxK, nClasses))
classRecalls = np.zeros((maxK, nClasses))
# Q 1.3.4 - Evaluate per-class precisions and recalls for various K
for k in range(maxK):
    confusionMatrix = np.zeros(nbClasses)
    
    ######################
    # YOUR CODE GOES HERE
    ######################
   

#%% Q 1.3.5 - Plot the evaluations for different K

######################
# YOUR CODE GOES HERE
######################
