function [ observedNetwork ] = observe(network, varName, observation)
%
%    Observes a given variable in our network.  This just deletes all entries not consistent
%    with the observation
%    
%    Args:
%        :param network: (list CPT) a list of the cpts in the network
%        :param var_name: (list string) name of the observed variables
%        :param observation: (list string) values that are observed 
%    
%    Returns:
%        :return: CPT structure
%    
    observedNetwork = cell(length(network), 1);
    
end

