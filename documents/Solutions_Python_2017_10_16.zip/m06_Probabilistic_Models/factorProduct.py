function [ cpt ] = factorProduct(cpt1, cpt2)
%
%    This method takes the factor product of two cpts by multiplying where the variables overlap
%    
%    Args:
%        cpt1: First probability table
%        cpt2: Second probability table
%        
%    Returns:
%        cpt: Factored probability table
%
    
end

