function [ marginalizedNetwork ] = marginalize(network, factors)
%
%    Marginalizes out a list of factors from a network of cpts
%    
%    Args:
%        :param network: (list pandas.DataFrame)
%        :param factors: (list string)
%    
%    Returns:
%        :return marginalized_network: (list pandas.DataFrame)
%
    marginalizedNetwork = cell(length(network), 1);
    for c = 1:length(network)
        cpt = network{c};
        cpt = marginalizeFactors(cpt, factors);
        marginalizedNetwork{c} = cpt;
    end
end

