function [ cpt ] = marginalizeFactors(cpt, factors)
%
%    Marginalizes out a list of factors from a single cpt
%    
%    Args:
%        :param cpt: CPT structure
%        :param factors: (list string)
%    
%    Returns:
%        :return cpt: (pandas.DataFrame)
%
    for i = 1:length(factors)
        cpt = marginalizeFactor(cpt, factor);
    end
end

