function [ marginalizedCpt ] = marginalizeFactor(cpt, factor)
%
%    This method marginalizes out a single factor by summing over all possible value combinations for that factor
%
    
end

