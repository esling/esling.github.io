def createCpt(varNames, probs, levelsList):
#
#    This method generates a conditional probability table structure
#    
#    Args:
#        var_names      : (list string) list of variable names
#        probs          : (list double) vector of probabilities for the flattened probability table
#        levels_list    : (list string tuples) list of outcomes for each variable i.e. high or low
#        
#    Returns:
#        cpt            : The conditional probability table
#
    # Create the CPT structure
    cpt = {};
    cpt["variables"] = varNames;
    cpt["probabilities"] = probs;
    cpt["levelsList"] = levelsList;
    # Create the combinatorial rows
    levelsTable = allcomb(levelsList[:]);
    if (len(levelsTable) != length(probs)):
        error('Values combinations does not fit probabilities table');
    cpt["valuesList"] = levelsTable;
    return cpt

