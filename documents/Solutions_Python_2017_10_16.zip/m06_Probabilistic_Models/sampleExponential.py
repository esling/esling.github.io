def sampleExponential(mu, n, m):
    
    return samples