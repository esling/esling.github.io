def sampleBeta(a, b, M, N):
    
    return samples