#%% ---------------
# ATIAM - Music machine learning tutorial
#
# Part 3 - Support Vector Machines
#
# In this tutorial, we will cover a more advanced classification algorithm
# through the use of Support Vector Machines. The goal is to gain an 
# intuition of how SVMs works and how to use Gaussian kernel with SVMs to 
# find out the decision doundary.
#
# <esling@ircam.fr>
#
#     gaussianKernel.m & linearKernel.m
#     example3parameters.m
#     svmTrain.m
#     svmPredict.m
#     DecsionBoundary.m
#     DecisionBoundaryLinear.m
#     plotData.m
#     

# Load all files in sub-directories
from m03_Support_Vector_Machines import svmTrain as st
from m03_Support_Vector_Machines import svmPredict as sp
from m03_Support_Vector_Machines import visualizeBoundary as vb
from m03_Support_Vector_Machines import visualizeBoundaryLinear as vbl
from m03_Support_Vector_Machines import plotData as pd
reload(st)
reload(sp)
reload(vb)
reload(vbl)
reload(pd)
from matplotlib import pyplot as plt
from scipy import io as sio
import numpy as np
# Path to the classification dataset
classPath = 'm00_Datasets/classification'

#%% 0.1 - Import the classification dataset
import importDataset as imp
import computeTransforms as cpt
import computeFeatures as cft
dataStruct = imp.importDataset(classPath, 'classification')
# 0.2 - Pre-process the audio to obtain spectral transforms 
dataStruct = cpt.computeTransforms(dataStruct)
# 0.3 - Compute a set of temporal and spectral features
dataStruct = cft.computeFeatures(dataStruct)
 
#%%
# 3.1.1 - Computing the prediction of a random SVM

########################################################
# YOUR CODE GOES IN 03_Support_Vector_Machines/svmPredict.m
########################################################

# Loading and Visualizing training dataset.
print('Loading and Visualizing Data ...')
# Loading dataset from example1.mat (X and y) are in the environment
struct = sio.loadmat('m03_Support_Vector_Machines/example1.mat')
dataX = struct["X"]
datay = struct["y"]
# Plot training data
pd.plotData(dataX, datay)
plt.title('Traning Dataset')
# Creating a fake (random) model
model = {};
model["X"]            # Values of _support vectors_ in input data
model["y"]            # Classes labels of _support vectors_
model["kernel"]       # Type of kernel
model["b"]            # Value of threshold
model["alphas"]       # Value of alphas
model["w"]            # Value of vectors
# Plot the result
plt.figure(figsize=(12, 8))
# Visualize the boundary (this function calls svmPredict)
vbl.visualizeBoundaryLinear(dataX, datay, model)
plt.title('Decision Boundary')

#%% 
# 3.1.2 - Training a SVM on a linear separation problem

########################################################
# YOUR CODE GOES IN 03_Support_Vector_Machines/svmTrain.m
########################################################
reload(st)
reload(vbl)
# Re-plot the training data
pd.plotData(dataX, datay);
plt.title('Traning Dataset');
# Training Linear SVM 
print('Training Linear SVM ...')
# Parameters of the training
C = 1                  # C regularization value
tolerance = 1e-3       # Tolerance value for thresholds
nbIterations = 20      # Number of iterations
kernel = 'linear'      # Type of kernel
# Perform the training (try to fiddle the previous values to see effect).
model = st.svmTrain(dataX, datay, C, kernel, tolerance, nbIterations);
# Plot the result
plt.figure(figsize=(12, 8))
vbl.visualizeBoundaryLinear(dataX, datay, model)
plt.title('Decision Boundary')
 
#%%
# 3.2.1 - Training a SVM with Gaussian kernel on non-linear problem

########################################################
# YOUR CODE GOES IN 
# - 03_Support_Vector_Machines/svmPredict.m
# - 03_Support_Vector_Machines/svmTrain.m
########################################################

# Loading the non-linear dataset
print('Loading and Visualizing Data ...')
load('example2.mat') 
# Plot the data
plt.figure(figsize=(12,8))
plotData(X, y)
plt.title('Traning Dataset')
# Parameters of the training
C = 1                  # C regularization value
tolerance = 1e-3       # Tolerance value for thresholds
nbIterations = 20      # Number of iterations
kernel = 'gaussian'    # Type of kernel
sigma = 0.1            # Variance of Gaussian kernel
# Train the SVM with a Gaussian (RBF) kernel
model = svmTrain(X, y, C, 'gaussian', tolerance, nbIterations) 
# Plot the result
plt.figure(figsize=(12, 8))
visualizeBoundary(X, y, model)
plt.title('Decision boundary with RBF kernel')

#%%
# 3.3.1 - Training a SVM with multiple kernels

########################################################
# YOUR CODE GOES IN 
# - 03_Support_Vector_Machines/svmPredict.m
# - 03_Support_Vector_Machines/svmTrain.m
########################################################

# Loading the non-linear dataset
print('Loading and Visualizing Data ...')
load('example2.mat') 
# Plot the data
plt.figure(figsize=(12, 8))
plotData(X, y)
plt.title('Traning Dataset')

# Polynomial kernel learning
C = 1                  # C regularization value
tolerance = 1e-3       # Tolerance value for thresholds
nbIterations = 20      # Number of iterations
kernel = 'polynomial'  # Type of kernel
sigma = 0.1            # Variance of Gaussian kernel
# Train the SVM with a Gaussian (RBF) kernel
model = svmTrain(X, y, C, gaussianKernel(x1, x2, sigma)) 
# Plot the result
plt.figure(figsize=(12, 8))
visualizeBoundary(X, y, model)
plt.title('Decision boundary with polynomial kernel')

# Sigmoid kernel learning
C = 1                  # C regularization value
tolerance = 1e-3       # Tolerance value for thresholds
nbIterations = 20      # Number of iterations
kernel = 'sigmoid'     # Type of kernel
sigma = 0.1            # Variance of Gaussian kernel
# Train the SVM with a Gaussian (RBF) kernel
model = svmTrain(X, y, C, gaussianKernel(x1, x2, sigma))
# Plot the result
plt.figure(figsize=(12, 8))
visualizeBoundary(X, y, model)
plt.title('Decision boundary with polynomial kernel')

#%% 
# 3.4.1 - Multi-class audio application

# First we will construct the data features matrix
usedFeatures = ['SpectralCentroidMean', 'SpectralFlatnessMean', 'SpectralSkewnessMean']
dataMatrix = np.zeros((len(dataStruct["filenames"]), len(usedFeatures)))
for f in range(len(usedFeatures)):
    dataMatrix[:, f] = dataStruct[usedFeatures[f]];
dataMatrix = np.nan_to_num(dataMatrix)
patterns = dataMatrix / np.max(dataMatrix)
# Construct a binary vector of outputs (class indicators)
n_values = np.max(dataStruct["classes"]) + 1
desired = np.eye(n_values)[dataStruct["classes"]]
nbTrain = desired.shape[0]
# Number of classes to evaluate
nbClasses = len(dataStruct["classNames"])
for i in range(len(nbClasses)):
    print('Evaluating class ' + str(i))
    ######################
    # YOUR CODE GOES HERE
    ######################
    
    # Define a binary classification problem for the current class
    # Define the parameters of the SVM
    # Train the SVM
    # Plot the results

######################
# YOUR CODE GOES HERE
######################

# Evaluate the overall classification accuracy of your model
# Change the parameters of the training procedure and re-evaluate
