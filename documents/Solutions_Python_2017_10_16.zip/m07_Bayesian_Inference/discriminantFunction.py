import numpy as np

def discriminantFunction(x_vec, mu_vec, cov_mat):
# Calculates the value of the discriminant function for a dx1 dimensional
# sample given the covariance matrix and mean vector.
#
#   x_vec: A dx1 dimensional numpy array representing the sample.
#   cov_mat: numpy array of the covariance matrix.
#   mu_vec: dx1 dimensional numpy array of the sample mean.
#
#   Returns a float value g as result of the discriminant function.

    ######################
    # YOUR CODE GOES HERE
    ######################
    
    ######################
    # Solution
    
    W_i = (-1/2) * np.linalg.inv(cov_mat)
    assert(W_i.shape[0] > 1 and W_i.shape[1] > 1), 'W_i must be a matrix'
    
    w_i = np.linalg.inv(cov_mat).dot(mu_vec)
    assert(w_i.shape[0] > 1 and w_i.shape[1] == 1), 'w_i must be a column vector'
    
    omega_i_p1 = (((-1/2) * (mu_vec).T).dot(np.linalg.inv(cov_mat))).dot(mu_vec)
    omega_i_p2 = (-1/2) * np.log(np.linalg.det(cov_mat))
    omega_i = omega_i_p1 - omega_i_p2
    assert(omega_i.shape == (1, 1)), 'omega_i must be a scalar'
    
    g = ((x_vec.T).dot(W_i)).dot(x_vec) + (w_i.T).dot(x_vec) + omega_i

    ######################
    
    return float(g)