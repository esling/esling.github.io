from matplotlib import pyplot as plt
import numpy as np

def plotGaussianEllipsoid(m, C, sdwidth=1, npts=None, axh=None):
# PLOT_GAUSSIAN_ELLIPSOIDS plots 2-d and 3-d Gaussian distributions
#
# H = PLOT_GAUSSIAN_ELLIPSOIDS(M, C) plots the distribution specified by 
#  mean M and covariance C. The distribution is plotted as an ellipse (in 
#  2-d) or an ellipsoid (in 3-d).  By default, the distributions are 
#  plotted in the current axes. 
    
# PLOT_GAUSSIAN_ELLIPSOIDS(M, C, SD) uses SD as the standard deviation 
#  along the major and minor axes (larger SD => larger ellipse). By 
#  default, SD = 1. 
# PLOT_GAUSSIAN_ELLIPSOIDS(M, C, SD, NPTS) plots the ellipse or 
#  ellipsoid with a resolution of NPTS 
#
# PLOT_GAUSSIAN_ELLIPSOIDS(M, C, SD, NPTS, AX) adds the plot to the
#  axes specified by the axis handle AX.
#
# Examples: 
# -------------------------------------------
#  # Plot three 2-d Gaussians
#  figure; 
#  h1 = plot_gaussian_ellipsoid([1 1], [1 0.5; 0.5 1]);
#  h2 = plot_gaussian_ellipsoid([2 1.5], [1 -0.7; -0.7 1]);
#  h3 = plot_gaussian_ellipsoid([0 0], [1 0; 0 1]);
#  set(h2,'color','r'); 
#  set(h3,'color','g');
# 
#  # "Contour map" of a 2-d Gaussian
#  figure;
#  for sd = [0.3:0.4:4],
#    h = plot_gaussian_ellipsoid([0 0], [1 0.8; 0.8 1], sd);
#  end
#
#  # Plot three 3-d Gaussians
#  figure;
#  h1 = plot_gaussian_ellipsoid([1 1  0], [1 0.5 0.2; 0.5 1 0.4; 0.2 0.4 1]);
#  h2 = plot_gaussian_ellipsoid([1.5 1 .5], [1 -0.7 0.6; -0.7 1 0; 0.6 0 1]);
#  h3 = plot_gaussian_ellipsoid([1 2 2], [0.5 0 0; 0 0.5 0; 0 0 0.5]);
#  set(h2,'facealpha',0.6);
#  view(129,36); set(gca,'proj','perspective'); grid on; 
#  grid on; axis equal; axis tight;
# -------------------------------------------
# 
#  Gautam Vallabha, Sep-23-2007, Gautam.Vallabha@mathworks.com

#  Revision 1.0, Sep-23-2007
#    - File created
#  Revision 1.1, 26-Sep-2007
#    - NARGOUT==0 check added.
#    - Help added on NPTS for ellipsoids
    
    if axh is None:
        axh = plt.gca()
    if m.size != len(m): 
        raise Exception('M must be a vector'); 
    if (m.size == 2):
        h = show2d(m[:], C, sdwidth, npts, axh)
    elif (m.size == 3):
        h = show3d(m[:], C, sdwidth, npts, axh)
    else:
        raise Exception('Unsupported dimensionality');
    return h

#-----------------------------
def show2d(means, C, sdwidth, npts=None, axh=None):
    if (npts is None):
        npts = 50
    # plot the gaussian fits
    tt = np.linspace(0, 2 * np.pi, npts).transpose()
    x = np.cos(tt);
    y = np.sin(tt);
    ap = np.concatenate((x[:], y[:])).transpose()
    v, d = np.eigvals(C)
    d = sdwidth * np.sqrt(d) # convert variance to sdwidth*sd
    bp = (v * d * ap) + repmat(means, 1, ap.shape[1]); 
    h = axh.plot(bp[0, :], bp[1, :], ls='-')
    return h

#-----------------------------
def show3d(means, C, sdwidth, npts=None, axh=None):
    if (npts is None):
        npts = 20
    x, y, z = sphere(npts);
    ap = np.concatenate((x[:], y[:], z[:])).transpose()
    v, d = eigvals(C)
    if any(d[:] < 0):
       print('warning: negative eigenvalues')
       d = np.max(d, 0)
    d = sdwidth * np.sqrt(d); # convert variance to sdwidth*sd
    bp = (v * d * ap) + repmat(means, 1, size(ap,2)); 
    xp = reshape(bp[0,:], size(x));
    yp = reshape(bp[1,:], size(y));
    zp = reshape(bp[2,:], size(z));
    h = axh.surf(xp, yp, zp);
    return h